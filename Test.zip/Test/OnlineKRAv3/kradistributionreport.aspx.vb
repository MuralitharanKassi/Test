Imports MySql.Data.MySqlClient
Imports System.Text

Partial Class kradistributionreport
    Inherits System.Web.UI.Page
    Dim fromdate, todate As Integer
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String
    Dim DS As New DataSet
    Dim DA As New MySqlDataAdapter
    Dim DT As dataTable
    Dim DV As dataView
    Dim Appraiser As Integer
    Dim Project As String


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim objControl As New Support.DataControl
            lblStatus.Visible = False
            lblError.Visible = False
            Connection.Open()
            If Not IsPostBack Then
                If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Then
                    ddlProject.Items.Clear()
                    ddlProject.Items.Add(New ListItem("All Project", "0"))
                    objControl.FillDropDown(Connection, ddlProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                ElseIf Session("UserCurRole") = "Project Admin" Then
                    strSQL = "select EmpID, name, AppraiserID, Appraiser, ProjectID, Project from userinfo where Month=" & Session("Month") & " and Year=" & Session("Year")
                    DA = New MySqlDataAdapter(strSQL, Connection)
                    DA.Fill(DS)
                    DV = New DataView(DS.Tables(0))
                    Appraiser = Session("UserID")
                    DV.RowFilter = "EmpID = '" & Appraiser & "'"
                    Project = ","
                    'Project = Project & DV(0)("ProjectID") & ","
                    DV.RowFilter = "AppraiserID = '" & Appraiser & "'"
                    For i As Integer = 0 To DV.Count - 1
                        If InStr(Project, "," & DV(0)("ProjectID") & ",") <= 0 Then
                            Project = Project & DV(0)("ProjectID") & ","
                            ddlProject.Items.Add(New ListItem(DV(0)("Project"), DV(0)("ProjectID")))
                        End If
                        recurseSubordinateList(DV(i)("EmpID"), 2)
                        DV.RowFilter = "AppraiserID = '" & Appraiser & "'"
                    Next
                    DV = Nothing
                End If
                objControl.FillDropDown(Connection, ddlTitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlMonth1, Session("Month"), Session("Year"))
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlMonth2, Session("Month"), Session("Year"))
                ddlMonth1.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
                ddlMonth2.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
                pnlChart.Visible = False
            End If
            Connection.Close()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub
    Sub RecurseSubOrdinateList(ByVal EmpID As String, ByVal Level As Integer)
        Try
            DV.RowFilter = "AppraiserID =" & EmpID
            For i As Integer = 0 To DV.Count - 1
                If InStr(Project, "," & DV(0)("ProjectID") & ",") <= 0 Then
                    Project = Project & DV(0)("ProjectID") & ","
                    ddlProject.Items.Add(New ListItem(DV(0)("Project"), DV(0)("ProjectID")))
                End If
                RecurseSubOrdinateList(DV(i)("EmpID"), Level + 1)
                DV.RowFilter = "AppraiserID =" & EmpID
            Next
        Catch ex As Exception
            'Error message
        End Try
    End Sub
    Private Sub BindGrid()
        Dim myDataset As New DataSet

        Dim totalRows, totalColumns As Integer
        Dim encoding As New ASCIIEncoding
        'Dim encoding As New UTF8Encoding
        Try
            Connection.Open()
            Dim objSupport As New Support.Common
            fromdate = 100 * objSupport.GetYear(ddlMonth1.SelectedValue) + objSupport.GetMonth(ddlMonth1.SelectedValue)
            todate = 100 * objSupport.GetYear(ddlMonth2.SelectedValue) + objSupport.GetMonth(ddlMonth2.SelectedValue)
            objSupport = Nothing
            If fromdate <= todate Then
                strSQL = "call RatingDistribution(" & ddlProject.SelectedValue & "," & ddlTitle.SelectedValue & "," & fromdate & "," & todate & ")"
                Dim myData As New MySqlDataAdapter(strSQL, Connection)
                myData.Fill(myDataset)
                totalRows = myDataset.Tables(0).Rows.Count
                totalColumns = myDataset.Tables(0).Columns.Count
                Dim Rating(12, totalColumns - 2) As String
                Dim rowCounter As Integer
                Dim colCounter As Integer
                For rowCounter = 0 To 12
                    For colCounter = 0 To totalColumns - 2
                        Rating(rowCounter, colCounter) = "0"
                    Next
                Next
                Dim rowValue As Integer
                For rowCounter = 0 To totalRows - 1
                    rowValue = rowCounter
                    If rowValue <> 0 Then

                        If myDataset.Tables(0).Rows(rowCounter).Item(0).GetType().ToString().Equals("System.Byte[]") Then
                            rowValue = 2 * CInt(encoding.GetString(myDataset.Tables(0).Rows(rowCounter).Item(0))) - 1
                        Else
                            rowValue = 2 * CInt(myDataset.Tables(0).Rows(rowCounter).Item(0)) - 1
                        End If
                    End If
                    For colCounter = 1 To totalColumns - 1
                        If myDataset.Tables(0).Rows(rowCounter).Item(colCounter).GetType().ToString().Equals("System.Byte[]") Then
                            Rating(rowValue, colCounter - 1) = encoding.GetString(myDataset.Tables(0).Rows(rowCounter).Item(colCounter))
                        Else
                            Rating(rowValue, colCounter - 1) = myDataset.Tables(0).Rows(rowCounter).Item(colCounter).ToString()
                        End If
                    Next
                Next
                Dim objControl As New Support.DataControl
                grdReport.DataSource = New Mommo.Data.ArrayDataView(objControl.TransposeArray(Rating))
                grdReport.DataBind()
                objControl = Nothing
                Dim GridItem As DataGridItem
                Dim strMonth As String
                Dim i As Integer
                For Each GridItem In grdReport.Items
                    strMonth = GridItem.Cells(0).Text
                    'Added to hide the percentage columns
                    GridItem.Cells(2).Visible = False
                    GridItem.Cells(4).Visible = False
                    GridItem.Cells(6).Visible = False
                    GridItem.Cells(8).Visible = False
                    GridItem.Cells(10).Visible = False
                    GridItem.Cells(12).Visible = False
                    If strMonth <> "Overall" And strMonth <> "&nbsp;" Then GridItem.Cells(0).Text = MonthName(Mid(strMonth, 5, 2), True) & "-" & Mid(strMonth, 3, 2)
                    If GridItem.Cells(11).Text <> "&nbsp;" Then GridItem.Cells(9).Text = CInt(GridItem.Cells(11).Text) - (CInt(GridItem.Cells(1).Text) + CInt(GridItem.Cells(3).Text) + CInt(GridItem.Cells(5).Text) + CInt(GridItem.Cells(7).Text))
                    For i = 1 To 11 Step 2
                        If GridItem.Cells(i).Text <> "&nbsp;" Then
                            If GridItem.Cells(i).Text = "0" Or GridItem.Cells(11).Text = "0" Then
                                GridItem.Cells(i + 1).Text = "0%"
                            Else
                                GridItem.Cells(i + 1).Text = CStr(Math.Round(100 * (CInt(GridItem.Cells(i).Text) / CInt(GridItem.Cells(11).Text)))) & "%"
                            End If
                        End If
                    Next
                Next
                For Each GridItem In grdReport.Items
                    strMonth = GridItem.Cells(0).Text
                    If strMonth = "Overall" Then
                        For i = 0 To 12
                            GridItem.Cells(i).Text = "<b>" & GridItem.Cells(i).Text & "</b>"
                            'Added to hide the Overall row
                            GridItem.Cells(i).Visible = False
                        Next
                    End If
                Next

                Connection.Close()
                LinkButton1.Visible = True
            End If
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
        pnlChart.Visible = True
    End Sub

    Public Function RatingChart() As String
        If grdReport.Items.Count <= 0 Then
            Return ""
            Exit Function
        End If
        Dim GridItem As DataGridItem
        Dim xmlData As String
        xmlData = "<chart palette='3' bgColor='FFFFFF,EEEEEE' bgSWFAlpha='0' xAxisName='Month' yAxisName='Count' rotateLabels='1' slantLabels='1' shownames='1' showvalues='0' maxColWidth='32' showSum='1' overlapColumns='1' legendPosition='BOTTOM' formatNumberScale='0'>"
        xmlData = xmlData & "<categories>"
        For Each GridItem In grdReport.Items
            If GridItem.Cells(0).Text <> "<b>Overall</b>" And GridItem.Cells(0).Text <> "&nbsp;" Then
                xmlData = xmlData & "<category label='" & GridItem.Cells(0).Text & "' />"
            End If
        Next
        xmlData = xmlData & "</categories>"
        Dim title As String
        For i As Integer = 1 To 5
            If i = 5 Then
                title = "Not Done"
            Else
                title = "PL" & i
            End If
            xmlData = xmlData & "<dataset seriesName='" & title & "'>"
            For Each GridItem In grdReport.Items
                If GridItem.Cells(0).Text <> "<b>Overall</b>" And GridItem.Cells(0).Text <> "&nbsp;" Then
                    xmlData = xmlData & "<set value='" & GridItem.Cells(2 * i - 1).Text & "' toolText='" & title & "," & GridItem.Cells(2 * i - 1).Text & "(" & Replace(GridItem.Cells(2 * i).Text, "%", "%25") & ")" & "' />"
                End If
            Next
            xmlData = xmlData & "</dataset>"
        Next
        xmlData = xmlData & "</chart>"
        Return FusionCharts.RenderChart("Charts/MSLine.swf", "", xmlData, "divrating", "380", "220", False, False)
    End Function

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        grdReport.CurrentPageIndex = 0
        BindGrid()
    End Sub

    Private Sub grdReport_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdReport.PageIndexChanged
        grdReport.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        KRAClass.ExportDataGrid(grdReport, "KRA_Rating_Distribution.xls")
    End Sub

    Private Sub grdReport_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdReport.ItemDataBound
        e.Item.Cells(13).Visible = False
        If e.Item.ItemType = ListItemType.Header Then
            'e.Item.Cells(0).Text = "Month"
            'e.Item.Cells(1).Text = "PL1"
            'e.Item.Cells(2).Text = "PL1(%)"
            'e.Item.Cells(3).Text = "PL2"
            'e.Item.Cells(4).Text = "PL2(%)"
            'e.Item.Cells(5).Text = "PL3"
            'e.Item.Cells(6).Text = "PL3(%)"
            'e.Item.Cells(7).Text = "PL4"
            'e.Item.Cells(8).Text = "PL4(%)"
            'e.Item.Cells(9).Text = "Not Done"
            'e.Item.Cells(10).Text = "Not Done(%)"
            'e.Item.Cells(11).Text = "Total"
            'e.Item.Cells(12).Text = "Total(%)"

            'Added to hide the percentage columns
            e.Item.Cells(0).Text = "Month"
            e.Item.Cells(1).Text = "PL1"
            e.Item.Cells(2).Visible = False
            e.Item.Cells(3).Text = "PL2"
            e.Item.Cells(4).Visible = False
            e.Item.Cells(5).Text = "PL3"
            e.Item.Cells(6).Visible = False
            e.Item.Cells(7).Text = "PL4"
            e.Item.Cells(8).Visible = False
            e.Item.Cells(9).Text = "Not Done"
            e.Item.Cells(10).Visible = False
            e.Item.Cells(11).Text = "Total"
            e.Item.Cells(12).Visible = False


        End If
    End Sub

End Class
