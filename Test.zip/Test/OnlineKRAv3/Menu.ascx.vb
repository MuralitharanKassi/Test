Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Xml
Imports System.Xml.Xsl
Imports System.Xml.XPath
Imports System.IO
Imports System.Text

Partial Class Menu
    Inherits System.Web.UI.UserControl
    Private xmlFile As String = String.Empty
    Private xslFile As String = "menu/menubuild.xsl"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub GetXMLFile()
        Try
            Dim userType As String
            Dim ApprDetails As String
            Dim clsAppraiser As New clsGeneral
            userType = Session("CurRole")
            If userType = "" Then userType = "user"
        xmlFile = "menu\" & LCase(userType.Replace(" ", "")) & ".xml"
        Catch ex As Exception
            'error msg
        End Try
    End Sub
    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        GetXMLFile()
        Dim XmlSystemFileName As String = Server.MapPath(xmlFile)
        Dim XslSystemFileName As String = Server.MapPath(xslFile)
        Dim xslt As XslTransform = New XslTransform
        xslt.Load(XslSystemFileName)
        Dim xpathdocument As XPathDocument = New XPathDocument(XmlSystemFileName)
        Dim sb As StringBuilder = New StringBuilder
        Dim sw As StringWriter = New StringWriter(sb)
        xslt.Transform(xpathdocument, Nothing, sw, Nothing)
        MenuPlaceHolder.Text = sb.ToString()
    End Sub

End Class
