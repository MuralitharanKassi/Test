Imports MySql.Data.MySqlClient

Partial Class krareportdisplay
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String
    Dim Command As New MySqlCommand
    Dim Reader As MySqlDataReader
    
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblError.Text = ""
        Try
            If (Session("ReportUserID").ToString = "" Or Session("ReportMonth").ToString = "" Or Session("ReportYear").ToString = "") And Session("UserCurRole").ToString <> "Administrator" Then
                Session("ReportUserID") = Session("UserID")
                Session("ReportMonth") = Session("Month")
                Session("ReportYear") = Session("Year")
            End If
            If Not IsPostBack Then
                If Session("ReportUserID").ToString <> "" And Session("ReportMonth").ToString <> "" And Session("ReportYear").ToString <> "" Then
                    Connection.Open()
                    FillMonth(Connection, Session("ReportUserID"), "User", ddlMonth, Session("ReportMonth"), Session("ReportYear"))
                    Connection.Close()
                    ddlMonth.SelectedValue = 100 * CInt(Session("ReportYear")) + CInt(Session("ReportMonth"))
                    btnReport_Click(sender, e)
                    'Else
                    '    Response.Redirect("krareport.aspx")
                End If
            End If
            'If Session("UserCurRole") = "Administrator" Then txt_params.Visible = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReport.Click
        Connection.Open()
        Try
            'Dim Parameters() As String
            Dim i As Integer
            'Label1.Visible = False
            'ddlMonth.Visible = False
            btnReport.Visible = True
            lbltime.Visible = False
            btnReset.Visible = False
            btnEdit.Visible = False
            lblresult.Visible = False
            lnkPrint.Visible = False
            'If Session("ReportUserID") = "" And Session("UserCurRole") <> "Administrator" Then
            '    Session("ReportUserID") = Session("UserID")
            'End If
            'Dim objSupport As New Support.Common
            'Session("ReportMonth") = objSupport.GetMonth(ddlMonth.SelectedValue)
            'Session("ReportYear") = objSupport.GetYear(ddlMonth.SelectedValue)

            'Dim chkRights As New clsGeneral
            Dim canView As Boolean = False
            If (Session("ReportUserID") = Session("UserID")) Or Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Director" Or Session("UserCurRole") = "Super Admin" Then
                canView = True
            ElseIf isManager(Connection, Session("ReportUserID"), Session("UserID"), Session("ReportMonth"), Session("ReportYear")) Then
                canView = True
            End If
            If canView = False Then
                lblError.Text = "You are not authorized to view this report"
                Exit Sub
            End If
            'Dim clsStatus As New clsGeneral
            Dim KRAStatus As String
            Dim isCompleted As Boolean = False
            strSQL = "CALL KRACompletionReport('" & Session("ReportUserID") & "','','','','','','" & Session("ReportMonth") & "','" & Session("ReportYear") & "','','')"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Reader.Read()
            KRAStatus = Reader("KRAStatus")
            Reader.Close()
            Select Case LCase(KRAStatus)
                Case "pending with appraiser", "kra not eligible", "goalsheet not available"
                    btnReset.Visible = False
                    btnEdit.Visible = False
                    pnlReport.Visible = False
                    lnkPrint.Visible = False
                    lblError.Text = "KRA Not Completed <br>" & KRAStatus
                Case "pending with reviewer", "pending signoff"
                    btnReset.Visible = False
                    btnEdit.Visible = False
                    'pnlReport.Visible = False
                    lnkPrint.Visible = False
                    lblError.Text = "KRA Not Completed <br>" & KRAStatus
                    isCompleted = True
                Case "completed"
                    btnReset.Visible = False
                    btnEdit.Visible = False
                    lblError.Text = ""
                    isCompleted = True
            End Select
            If isCompleted Then
                KRAReport(Session("ReportUserID"), Session("ReportMonth"), Session("ReportYear"))
                txt_params.Text = FeedbackParam(pnlParam, Session("ReportUserID"), Session("ReportMonth"), Session("ReportYear"), , , True)
                strSQL = "select * from tb_tran_paramfeedback where M_PFEEDBACK_MONTH='" & Session("ReportMonth") & "' and M_PFEEDBACK_YEAR='" & Session("ReportYear") & "' and M_PFEEDBACK_EMPID='" & Session("ReportUserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Dim ParamList() As String
                Dim Parameter() As String

                ParamList = Split(txt_params.Text, ";")
                While Reader.Read()
                    For i = 0 To ParamList.Length - 2
                        Parameter = Split(ParamList(i), ",")
                        If Parameter(1) = Reader("M_PFEEDBACK_PARAM") Then
                            CType(pnlParam.FindControl(Parameter(0)), TextBox).Text = Reader("M_PFEEDBACK_COMMENT")
                        End If
                    Next
                End While
                Reader.Close()

                strSQL = "select * from tb_tran_empfeedback where M_FEEDBACK_MONTH='" & Session("ReportMonth") & "' and M_FEEDBACK_YEAR='" & Session("ReportYear") & "' and M_FEEDBACK_EMPID='" & Session("ReportUserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                While Reader.Read()
                    If Not IsDBNull(Reader("M_FEEDBACK_APPCOMM")) Then txt_appcomm.Text = Reader("M_FEEDBACK_APPCOMM")
                    If Not IsDBNull(Reader("M_FEEDBACK_REVCOMM")) Then txt_revcomm.Text = Reader("M_FEEDBACK_REVCOMM")
                    If Not IsDBNull(Reader("M_FEEDBACK_EMPCOMM")) Then txt_empcomm.Text = Reader("M_FEEDBACK_EMPCOMM")
                    If Not IsDBNull(Reader("M_FEEDBACK_SUP_DONT")) Then txtrevdont.Text = Reader("M_FEEDBACK_SUP_DONT")
                    If Not IsDBNull(Reader("M_FEEDBACK_SUP_DO")) Then txtrevdo.Text = Reader("M_FEEDBACK_SUP_DO")
                    If Not IsDBNull(Reader("M_FEEDBACK_IDENT_TECH")) Then txtidtec.Text = Reader("M_FEEDBACK_IDENT_TECH")
                    If Not IsDBNull(Reader("M_FEEDBACK_IDENT_CERT")) Then txtidcer.Text = Reader("M_FEEDBACK_IDENT_CERT")
                    If Not IsDBNull(Reader("M_FEEDBACK_IDENT_SKILL")) Then txtidskill.Text = Reader("M_FEEDBACK_IDENT_SKILL")
                    If Not IsDBNull(Reader("M_FEEDBACK_REL_EMP")) Then lblrelemp.Text = Reader("M_FEEDBACK_REL_EMP")
                    If Not IsDBNull(Reader("M_FEEDBACK_REL_SUP")) Then lblrelsup.Text = Reader("M_FEEDBACK_REL_SUP")
                    If Not IsDBNull(Reader("M_FEEDBACK_COMP")) Then lblcomp.Text = Reader("M_FEEDBACK_COMP")
                End While
                Reader.Close()
                Connection.Close()
                If Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Administrator" Then
                    btnReset.Visible = True
                    btnEdit.Visible = True
                End If
            Else
                PanelFeedback.Visible = False
            End If
        Catch ex As Exception
            'lblError.Text = "Error displaying kra score"
            If Session("UserCurRole") = "Administrator" Then
                lblError.Text = "Error Occured in Main Function. Error: " & ex.Message
            End If
        End Try
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        Response.Redirect("kra_reset.aspx")
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Response.Redirect("kraadminedit.aspx")
    End Sub

    Public Sub KRAReport(ByVal EmpID As String, ByVal Month As String, ByVal Year As String, Optional ByVal Role As String = "")
        Try
            Dim Info As String = ""
            Dim Adapter As MySqlDataAdapter
            'Connection.Open()
            strSQL = "select Name,Project,Title from userinfo where EmpID='" & EmpID & "' and Month='" & Month & "' and Year='" & Year & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Reader.Read()
            Info &= "EmpID : " & EmpID & " | Name : " & Reader("Name") & " | Month : " & MonthName(Month, True) & "-" & Year
            Info &= " | Project : " & Reader("Project") & " | Title : " & Reader("Title")
            divInfo.InnerHtml = Info
            Reader.Close()

            strSQL = "select tran_empid as EmpID,tran_month as Month,tran_year as Year,tran_param as Parameter,tran_weightage as Parameter_Weightage,tran_keydeter as KeyItem,tran_weight as KeyItem_Weightage,tran_goal as Goal,tran_actual as Actual,tran_apprating as App_Rating,tran_appscore as App_Score,tran_revrating as Rev_Rating,tran_revscore as Rev_Score from tb_tran_storerating where tran_empid='" & EmpID & "' and tran_month='" & Month & "' and tran_year='" & Year & "' order by tran_param"
            Command = New MySqlCommand(strSQL, Connection)
            Dim myDataset As New DataSet
            Adapter = New MySqlDataAdapter(strSQL, Connection)
            Adapter.Fill(myDataset)
            gvKRA.DataSource = myDataset.Tables(0).DefaultView
            gvKRA.DataBind()

            Dim gvItem As GridViewRow
            Dim Weight As Double = 0
            Dim Weight_Total As Double = 0
            Dim Rating_SubTotal As Double = 0
            Dim Rating_Total As Double = 0
            Dim Parameter As String = ""
            For Each gvItem In gvKRA.Rows
                Weight = CDbl(Replace(gvItem.Cells(3).Text, "%", ""))
                Weight_Total += Weight
                'Rating_SubTotal += CDbl(gvItem.Cells(9).Text)
                Rating_Total += (Weight / 100) * CDbl(gvItem.Cells(8).Text)
            Next
            gvKRA.FooterRow.Cells(2).Text = "<b>Total</b>"
            gvKRA.FooterRow.Cells(3).Text = "<b>" & Weight_Total & "%</b>"
            gvKRA.FooterRow.Cells(8).Text = "<b>" & Math.Round(Rating_Total, 1) & "</b>"
        Catch ex As Exception
            '"Error Occured in Main Function. Error: " & ex.Message
        End Try
    End Sub

End Class