Imports MySql.Data.MySqlClient

Partial Class krareportprint
    Inherits System.Web.UI.Page
    Dim totloop As Integer
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Response.CacheControl = "no-cache"
        Response.AddHeader("Pragma", "no-cache")
        Response.Expires = -1
        If Session("UserID") = "" Then
            Response.Redirect("index.aspx")
        End If
        Try
            Connection.Open()
            Dim i As Integer
            Session("pageid") = Request.QueryString("eid")
            Session("rptMonth") = Request.QueryString("m")
            Session("rptYear") = Request.QueryString("y")
            Session("ReportEmpNo") = Session("pageid")
            Dim isCompleted As Boolean = False
            Dim canView As Boolean = False
            If (Session("pageid") = Session("UserID")) Or Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Director" Or Session("UserCurRole") = "Super Admin" Then
                canView = True
            ElseIf isManager(Connection, Session("pageid"), Session("UserID"), Session("rptMonth"), Session("rptYear")) Then
                canView = True
            End If
            If canView Then
                strSQL = "CALL KRACompletionReport('" & Session("pageid") & "','','','','','','" & Session("rptMonth") & "','" & Session("rptYear") & "','','')"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Reader.Read()
                If Reader("KRAStatus") <> "Completed" Then
                    PanelFeedback.Visible = False
                Else
                    isCompleted = True
                End If
                Reader.Close()
                If isCompleted Then
                    KRAScore(Session("pageid"), Session("rptMonth"), Session("rptYear"))
                    Try
                        txt_params.Text = FeedbackParam(pnlParam, Session("pageid"), Session("rptMonth"), Session("rptYear"), , , True)
                    Catch ex1 As Exception
                        If Session("UserCurRole") = "Administrator" Then
                            Response.Write("Main Function1: " & ex1.Message)
                        End If
                    End Try
                    strSQL = "select * from tb_tran_paramfeedback where M_PFEEDBACK_MONTH='" & Session("rptMonth") & "' and M_PFEEDBACK_YEAR='" & Session("rptYear") & "' and M_PFEEDBACK_EMPID='" & Session("pageid") & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    Dim ParamList() As String
                    Dim Parameter() As String

                    ParamList = Split(txt_params.Text, ";")
                    Try
                        While Reader.Read()
                            For i = 0 To ParamList.Length - 1
                                Parameter = Split(ParamList(i), ",")
                                'add below condtion checked by suresh p
                                If Parameter(0).ToString <> "" Then
                                    If Parameter(1).ToUpper().ToString().Trim() = Reader("M_PFEEDBACK_PARAM").ToUpper().ToString().Trim() Then
                                        CType(pnlParam.FindControl(Parameter(0)), TextBox).Text = Reader("M_PFEEDBACK_COMMENT")
                                    End If
                                End If
                            Next
                        End While
                    Catch ex2 As Exception
                        If Session("UserCurRole") = "Administrator" Then
                            Response.Write("Main Function2: " & ex2.Message)
                        End If
                    End Try
                    Reader.Close()
                    strSQL = "select * from tb_tran_empfeedback where M_FEEDBACK_MONTH='" & Session("rptMonth") & "' and M_FEEDBACK_YEAR='" & Session("rptYear") & "' and M_FEEDBACK_EMPID='" & Session("pageid") & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    Try
                        While Reader.Read()
                            If Not IsDBNull(Reader("M_FEEDBACK_APPCOMM")) Then txt_appcomm.Text = Reader("M_FEEDBACK_APPCOMM")
                            If Not IsDBNull(Reader("M_FEEDBACK_REVCOMM")) Then txt_revcomm.Text = Reader("M_FEEDBACK_REVCOMM")
                            If Not IsDBNull(Reader("M_FEEDBACK_EMPCOMM")) Then txt_empcomm.Text = Reader("M_FEEDBACK_EMPCOMM")
                            If Not IsDBNull(Reader("M_FEEDBACK_SUP_DONT")) Then txtrevdont.Text = Reader("M_FEEDBACK_SUP_DONT")
                            If Not IsDBNull(Reader("M_FEEDBACK_SUP_DO")) Then txtrevdo.Text = Reader("M_FEEDBACK_SUP_DO")
                            If Not IsDBNull(Reader("M_FEEDBACK_IDENT_TECH")) Then txtidtec.Text = Reader("M_FEEDBACK_IDENT_TECH")
                            If Not IsDBNull(Reader("M_FEEDBACK_IDENT_CERT")) Then txtidcer.Text = Reader("M_FEEDBACK_IDENT_CERT")
                            If Not IsDBNull(Reader("M_FEEDBACK_IDENT_SKILL")) Then txtidskill.Text = Reader("M_FEEDBACK_IDENT_SKILL")
                            If Not IsDBNull(Reader("M_FEEDBACK_REL_EMP")) Then lblrelemp.Text = Reader("M_FEEDBACK_REL_EMP")
                            If Not IsDBNull(Reader("M_FEEDBACK_REL_SUP")) Then lblrelsup.Text = Reader("M_FEEDBACK_REL_SUP")
                            If Not IsDBNull(Reader("M_FEEDBACK_COMP")) Then lblcomp.Text = Reader("M_FEEDBACK_COMP")
                        End While
                    Catch ex3 As Exception
                        If Session("UserCurRole") = "Administrator" Then
                            Response.Write("Main Function3: " & ex3.Message)
                        End If
                    End Try
                    Reader.Close()
                    Connection.Close()
                    pnlTxtPanel.Visible = True
                    pnlOutter.Visible = True
                    PanelFeedback.Visible = True
                End If
            Else
                pnlTxtPanel.Visible = False
                pnlOutter.Visible = False
                errLabel.Text = "You are not authorized to view this report"
            End If
        Catch ex As Exception
            If Session("UserCurRole") = "Administrator" Then
                Response.Write("Main Function4: " & ex.Message)
            End If
        End Try

    End Sub

    Public Sub KRAScore(ByVal EmpID As String, ByVal Month As String, ByVal Year As String)

        Dim Name As String
        Dim Project As String
        Dim Title As String
        Dim Info As String = ""
        Try
            strSQL = "select EmpID, Name, Project, Title from userinfo where EmpID='" & EmpID & "' and Month='" & Month & "' and Year='" & Year & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Reader.Read()
            Name = Reader("Name")
            Project = Reader("Project")
            Title = Reader("Title")
            Reader.Close()
            'Employee Information Start
            Info &= "Name : " & Name & " | Emp ID : " & EmpID & " | Project : " & Project & " | Title : " & Title & " | Month : " & MonthName(Month) & " '" & Year
            divInfo.InnerHtml = Info
            'Employee Information End

            strSQL = "select tran_empid as EmpID,tran_month as Month,tran_year as Year,tran_param as Parameter,tran_weightage as Parameter_Weightage,tran_keydeter as KPI,tran_weight as KPI_Weightage,tran_goal as Goal,tran_actual as Actual,tran_revrating as Rev_Rating,tran_revscore as Rev_Score from tb_tran_storerating where tran_empid='" & EmpID & "' and tran_month='" & Month & "' and tran_year='" & Year & "' and tran_signofftime<>'' order by tran_param"
            Dim myDataset As New DataSet
            Dim Adapter As New MySqlDataAdapter(strSQL, Connection)
            Adapter.Fill(myDataset)
            If Not myDataset Is Nothing Then
                If myDataset.Tables(0).Rows.Count > 0 Then
                    gvKRA.Visible = True
                    gvKRA.DataSource = myDataset
                    gvKRA.DataBind()
                End If
            Else
                gvKRA.Visible = False
            End If


            Dim WeightTotal As Double = 0
            Dim ScoreTotal As Double = 0
            Dim gridItem As GridViewRow
            For Each gridItem In gvKRA.Rows
                WeightTotal += CDbl(Replace(gridItem.Cells(3).Text, "%", ""))
                ScoreTotal += CDbl(gridItem.Cells(7).Text)
            Next
            gvKRA.FooterRow.Cells(2).Text = "Total"
            gvKRA.FooterRow.Cells(3).Text = WeightTotal
            gvKRA.FooterRow.Cells(7).Text = ScoreTotal

        Catch ex As Exception
            If Session("UserCurRole") = "Administrator" Then
                Response.Write("Sub Function3: " & ex.Message)
            End If
        End Try
    End Sub

End Class