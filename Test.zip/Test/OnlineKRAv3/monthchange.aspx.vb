Imports System.Data.Odbc

Partial Class monthchange
    Inherits System.Web.UI.Page
    Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    Dim kraCommand As New OdbcCommand
    Dim kraReader As OdbcDataReader
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim monthyear, month, year As Integer
        Dim curRole As String = Session("CurRole")
        Try
            monthyear = CInt(Request.QueryString("month"))
            Session("month") = monthyear - (100 * Math.Round(monthyear / 100))
            Session("year") = Math.Round(monthyear / 100)
            Session("CurMonthKRA") = ""
            Session("LastMonthKRA") = ""
            If Session("curRole") <> "Administrator" Then
                kraConnection.Open()
                strSQL = "select ProjectID, Project, TitleID, Title, AppraiserID, Appraiser from userInfo where EmpID='" & Session("UserEmpNo") & "' and Month='" & Session("month") & "' and Year='" & Session("year") & "'"
                kraCommand.CommandText = strSQL
                kraCommand.Connection = kraConnection
                kraReader = kraCommand.ExecuteReader()
                kraReader.Read()
                Session.Item("Project") = ""
                Session.Item("Title") = ""
                Session.Item("Appraiser") = ""
                Session.Item("ProjectName") = ""
                Session.Item("TitleName") = ""
                Session.Item("AppraiserName") = ""
                If kraReader.HasRows Then
                    If Not IsDBNull(kraReader("ProjectID")) Then Session("Project") = kraReader("ProjectID")
                    If Not IsDBNull(kraReader("TitleID")) Then Session("Title") = kraReader("TitleID")
                    If Not IsDBNull(kraReader("AppraiserID")) Then Session("Appraiser") = kraReader("AppraiserID")
                    If Not IsDBNull(kraReader("Project")) Then Session("ProjectName") = kraReader("Project")
                    If Not IsDBNull(kraReader("Title")) Then Session("TitleName") = kraReader("Title")
                    If Not IsDBNull(kraReader("Appraiser")) Then Session("AppraiserName") = kraReader("Appraiser")
                End If
                kraReader.Close()

                strSQL = "call isAppraiser('" & Session("UserEmpNo") & "','" & Session("month") & "','" & Session("year") & "')"
                kraCommand = New OdbcCommand(strSQL, kraConnection)
                kraReader = kraCommand.ExecuteReader()
                kraReader.Read()
                Session("Role") = Replace(Session("Role"), "Appraiser,", "")
                Session("Role") = Replace(Session("Role"), "Reviewer,", "")
                If kraReader(0) <> "0" Then
                    Session("Role") = Session("Role") & "Appraiser,"
                    Session("CurRole") = "Appraiser"
                Else
                    Session("CurRole") = "User"
                End If
                kraReader.Close()
                strSQL = "call isReviewer('" & Session("UserEmpNo") & "','" & Session("month") & "','" & Session("year") & "')"
                kraCommand = New OdbcCommand(strSQL, kraConnection)
                kraReader = kraCommand.ExecuteReader()
                kraReader.Read()
                If kraReader(0) <> "0" Then
                    Session("Role") = Session("Role") & "Reviewer,"
                End If
                kraReader.Close()
                kraConnection.Close()
                Session("CurRole") = curRole
            End If
            If Request.QueryString("page") = "" Then
                Response.Redirect("krahome.aspx")
            Else
                Response.Redirect(Request.QueryString("page"))
            End If
        Catch ex As Exception
            'Error message
        End Try
    End Sub

End Class
