Imports System.Data.Odbc

Module clsQuerySet

    Public Function SelectDataset(ByRef Connection As OdbcConnection, ByVal strFieldName As String, ByVal strTableName As String, Optional ByVal strWhereCondition As String = "", Optional ByVal strOrderBy As String = "", Optional ByVal strGroupBy As String = "") As DataSet
        If Connection.State = ConnectionState.Closed Then
            Exit Function
        End If
        Dim strSQL As String = " SELECT " & strFieldName & " FROM " & strTableName
        If strWhereCondition <> "" Then strSQL = strSQL & " WHERE " & strWhereCondition
        If strGroupBy <> "" Then strSQL = strSQL & " GROUP BY " & strGroupBy
        If strOrderBy <> "" Then strSQL = strSQL & " ORDER BY " & strOrderBy
        Dim datKRA As New OdbcDataAdapter(strSQL, Connection)
        Dim ds As New DataSet
        datKRA.Fill(ds, strTableName)
        Return ds
    End Function

    Public Function SelectReader(ByRef Connection As OdbcConnection, ByVal strFieldName As String, ByVal strTableName As String, Optional ByVal strWhereCondition As String = "") As OdbcDataReader
        If Connection.State = ConnectionState.Closed Then
            Exit Function
        End If
        Dim strSQL As String = " SELECT " & strFieldName & " FROM " & strTableName
        If strWhereCondition <> "" Then strSQL = strSQL & " WHERE " & strWhereCondition
        Dim Command As New OdbcCommand(strSQL, Connection)
        Dim Reader As OdbcDataReader = Command.ExecuteReader()
        Return Reader
    End Function

    Public Function SelectAValue(ByRef Connection As OdbcConnection, ByVal strFieldName As String, ByVal strTableName As String, Optional ByVal strWhereCondition As String = "", Optional ByVal strOrderBy As String = "", Optional ByVal strGroupBy As String = "") As String
        If Connection.State = ConnectionState.Closed Then
            Exit Function
        End If
        Dim strSQL As String = "SELECT " & strFieldName & " FROM " & strTableName
        If strWhereCondition <> "" Then strSQL = strSQL & " WHERE " & strWhereCondition
        If strGroupBy <> "" Then strSQL = strSQL & " GROUP BY " & strGroupBy
        If strOrderBy <> "" Then strSQL = strSQL & " ORDER BY " & strOrderBy
        Dim Command As New OdbcCommand(strSQL, Connection)
        Dim Reader As OdbcDataReader = Command.ExecuteReader()
        If Reader.HasRows Then
            Reader.Read()
            If Not IsDBNull(Reader(0)) Then Return CStr(Reader(0))
        Else
            Return ""
        End If
        Reader.Close()
    End Function

    Public Function SelectArrayList(ByRef Connection As OdbcConnection, ByVal strFieldName As String, ByVal strTableName As String, Optional ByVal strWhereCondition As String = "", Optional ByVal strOrderBy As String = "", Optional ByVal strGroupBy As String = "") As String
        If Connection.State = ConnectionState.Closed Then
            Exit Function
        End If
        Dim strSQL As String = "SELECT " & strFieldName & " FROM " & strTableName
        If strWhereCondition <> "" Then strSQL = strSQL & " WHERE " & strWhereCondition
        If strGroupBy <> "" Then strSQL = strSQL & " GROUP BY " & strGroupBy
        If strOrderBy <> "" Then strSQL = strSQL & " ORDER BY " & strOrderBy
        Dim Command As New OdbcCommand(strSQL, Connection)
        Dim Reader As OdbcDataReader = Command.ExecuteReader()
        Dim ResultList As String = ""
        While Reader.Read()
            ResultList = ResultList & "," & Reader.GetString(0)
        End While
        If ResultList <> "" Then
            Return Mid(ResultList, 2, Len(ResultList) - 1)
        Else
            Return ""
        End If
        Reader.Close()
    End Function

    Public Sub InsertValue(ByRef Connection As OdbcConnection, ByVal strTableName As String, ByVal strFieldList As String, ByVal strValueList As String)
        If Connection.State = ConnectionState.Closed Then
            Exit Sub
        End If
        Dim strSQL As String = "INSERT INTO " & strTableName & "(" & strFieldList & ") VALUE(" & strValueList & ")"
        Dim Command As New OdbcCommand(strSQL, Connection)
        Command.ExecuteNonQuery()
    End Sub

    Public Sub UpdateValue(ByRef Connection As OdbcConnection, ByVal strTableName As String, ByVal strFieldValueList As String, Optional ByVal strWhereCondition As String = "")
        If Connection.State = ConnectionState.Closed Then
            Exit Sub
        End If
        Dim strSQL As String = "UPDATE " & strTableName & " SET " & strFieldValueList
        If strWhereCondition <> "" Then strSQL = strSQL & " WHERE " & strWhereCondition
        Dim Command As New OdbcCommand(strSQL, Connection)
        Command.ExecuteNonQuery()
    End Sub

    Public Sub DeleteValue(ByRef Connection As OdbcConnection, ByVal strTableName As String, ByVal strWhereCondition As String)
        If Connection.State = ConnectionState.Closed Then
            Exit Sub
        End If
        Dim strSQL As String = "DELETE FROM " & strTableName & " WHERE " & strWhereCondition
        Dim Command As New OdbcCommand(strSQL, Connection)
        Command.ExecuteNonQuery()
    End Sub

    Public Sub Truncate(ByRef Connection As OdbcConnection, ByVal strtable As String)
        If Connection.State = ConnectionState.Closed Then
            Exit Sub
        End If
        Dim strSQL As String = "Truncate " & strtable
        Dim Command As New OdbcCommand(strSQL, Connection)
        Command.ExecuteNonQuery()
    End Sub

End Module
