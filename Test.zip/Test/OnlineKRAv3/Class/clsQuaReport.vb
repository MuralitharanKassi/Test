Imports System.Data.Odbc

Public Class clsQuaReport

    Public Function DisplayQuaParam(ByVal pnlTxtPnl As Panel, ByVal intQuarter As String, ByVal strYear As String, ByVal empid As String) As Integer
        'Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        'kraConnection.Open()
        'Dim strSQL As String = "select tran_empid,M_EMPL_NAME,tran_month,tran_year,PROJ_NAME,TITL_NAME,tran_param,tran_weightage,tran_keydeter,tran_weight,tran_goal,tran_actual,tran_emprating,tran_empscore,tran_apprating ,tran_appscore,tran_revrating,tran_revscore from tb_tran_storerating,tb_mast_employee,tb_master_project,tb_master_title where TITL_ID_PK=tran_title and tran_proj =PROJ_ID_PK and M_EMPL_ID_PK=tran_empid and tran_empid='" & empid & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'"
        'Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
        'Dim kraReader As OdbcDataReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
        'Dim conn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        'conn.Open()
        'Dim totalrow As Integer = 0
        'Dim intHrrating As String
        'Dim rs As OdbcDataReader
        'Dim strSQL_sum As String
        'Dim kraCommand_sum As OdbcCommand
        'Dim kraReader_sum As OdbcDataReader
        'Dim weightsum As Double = 0.0
        'Dim empsum As Double = 0.0
        'Dim appsum As Double = 0.0
        'Dim revsum As Double = 0.0
        'Dim hrsum As Double = 0.0
        'Dim intLoop As Integer = 0
        'Dim strParameter As String = ""
        'Dim strWeightage As String = ""

        'While kraReader.Read()
        '    intLoop = intLoop + 1
        '    If intLoop = 1 Then
        '        Dim txtHemprate As New Label
        '        Dim txtHempscore As New Label
        '        Dim txtHapprate As New Label
        '        Dim txtHappscore As New Label
        '        Dim txtHRevrate As New Label
        '        Dim txtHRevscore As New Label
        '        Dim txtHrrate As New Label
        '        Dim txtHtitle As New Label
        '        Dim txtHtitlevalue As New Label
        '        Dim txtHproject As New Label
        '        Dim txtHprojectvalue As New Label
        '        Dim txtHmonthyear As New Label
        '        Dim txtHmonthyearvalue As New Label
        '        Dim txtHname As New Label
        '        Dim txtHnamevalue As New Label
        '        Dim txtHempid As New Label
        '        Dim txtHempidvalue As New Label
        '        Dim txtHParameterWeight1 As New Label
        '        Dim txtHParameter As New Label
        '        Dim txtHParameter1 As New Label
        '        Dim txtHParameter2 As New Label
        '        Dim txtHParameter3 As New Label
        '        Dim txtHParameterWeight As New Label
        '        Dim txtHKeyDeter As New Label
        '        Dim txtHKeyDeterWeight As New Label
        '        Dim txtHKeyDeterGoal As New Label
        '        Dim txtHKeyDeterActual As New Label

        '        pnlTxtPnl.Controls.Add(txtHParameter2)
        '        txtHParameter2.CssClass = "kravalueslabel"
        '        txtHParameter2.Text = " "

        '        pnlTxtPnl.Controls.Add(txtHempid)
        '        txtHempid.CssClass = "kraHeadvalueslabel"
        '        txtHempid.Text = "Empid :"


        '        pnlTxtPnl.Controls.Add(txtHempidvalue)
        '        txtHempidvalue.CssClass = "kravaluesweightlabel"
        '        txtHempidvalue.Text = kraReader.GetString(0)

        '        pnlTxtPnl.Controls.Add(txtHname)
        '        txtHname.CssClass = "kraHeadvalueslabel"
        '        txtHname.Text = "| EmpName :"

        '        pnlTxtPnl.Controls.Add(txtHnamevalue)
        '        txtHnamevalue.CssClass = "kravaluesweightlabel"
        '        txtHnamevalue.Text = kraReader.GetString(1)

        '        pnlTxtPnl.Controls.Add(txtHmonthyear)
        '        txtHmonthyear.CssClass = "kraHeadvalueslabel"
        '        txtHmonthyear.Text = "| Month & Year :"

        '        pnlTxtPnl.Controls.Add(txtHmonthyearvalue)
        '        txtHmonthyearvalue.CssClass = "kravaluesweightlabel"
        '        txtHmonthyearvalue.Text = kraReader.GetString(2) & "-" & kraReader.GetString(3)


        '        pnlTxtPnl.Controls.Add(txtHproject)
        '        txtHproject.CssClass = "kraHeadvalueslabel"
        '        txtHproject.Text = "| Project :"

        '        pnlTxtPnl.Controls.Add(txtHprojectvalue)
        '        txtHprojectvalue.CssClass = "kravaluesweightlabel"
        '        txtHprojectvalue.Text = kraReader.GetString(4)

        '        pnlTxtPnl.Controls.Add(txtHtitle)
        '        txtHtitle.CssClass = "kraHeadvalueslabel"
        '        txtHtitle.Text = "| Title :"

        '        pnlTxtPnl.Controls.Add(txtHtitlevalue)
        '        txtHtitlevalue.CssClass = "kravaluesweightlabel"
        '        txtHtitlevalue.Text = kraReader.GetString(5)

        '        pnlTxtPnl.Controls.Add(txtHParameter1)
        '        txtHParameter1.CssClass = "kravalueslabel"
        '        txtHParameter1.Text = ""


        '        Second Part Starts here

        '        pnlTxtPnl.Controls.Add(txtHParameter)
        '        txtHParameter.Text = "Parameter"
        '        txtHParameter.CssClass = "kravalueslabel"

        '        pnlTxtPnl.Controls.Add(txtHParameterWeight)
        '        txtHParameterWeight.CssClass = "kravaluesweightlabel"
        '        txtHParameterWeight.Text = "Weightage"


        '        pnlTxtPnl.Controls.Add(txtHKeyDeter)
        '        txtHKeyDeter.CssClass = "kravalueskralabel"
        '        txtHKeyDeter.Text = "Key Determinant"

        '        pnlTxtPnl.Controls.Add(txtHKeyDeterWeight)
        '        txtHKeyDeterWeight.CssClass = "kravaluesweightlabel"
        '        txtHKeyDeterWeight.Text = "Weightage"


        '        pnlTxtPnl.Controls.Add(txtHKeyDeterGoal)
        '        txtHKeyDeterGoal.CssClass = "kravaluesweightlabel"
        '        txtHKeyDeterGoal.Text = "Goal"


        '        pnlTxtPnl.Controls.Add(txtHKeyDeterActual)
        '        txtHKeyDeterActual.CssClass = "kravaluesweightlabel"
        '        txtHKeyDeterActual.Text = "Actual"


        '        pnlTxtPnl.Controls.Add(txtHemprate)
        '        txtHemprate.CssClass = "kravaluesweightlabel"
        '        txtHemprate.Text = "Emp Rating"


        '        pnlTxtPnl.Controls.Add(txtHempscore)
        '        txtHempscore.Text = "Emp Score"
        '        txtHempscore.CssClass = "kravaluesweightlabel"
        '        If LCase(empno) = "admin" Then

        '            pnlTxtPnl.Controls.Add(txtHRevrate)
        '            txtHRevrate.Text = "Rev Rating"
        '            txtHRevrate.CssClass = "kravaluesweightlabel"


        '            pnlTxtPnl.Controls.Add(txtHRevscore)
        '            txtHRevscore.Text = "Rev Score"
        '            txtHRevscore.CssClass = "kravaluesweightlabel"
        '        End If

        '        pnlTxtPnl.Controls.Add(txtHrrate)
        '        txtHrrate.Text = "HR Rating"
        '        txtHrrate.CssClass = "kravaluesweightlabel"



        '    End If
        '    Dim txtParameter As New Label
        '    pnlTxtPnl.Controls.Add(txtParameter)
        '    txtParameter.CssClass = "paramhideinput"

        '    If strParameter <> kraReader.GetString(6) Then
        '        txtParameter.CssClass = "paraminput"
        '        txtParameter.ID = "param" & intLoop
        '        txtParameter.Text = kraReader.GetString(6)
        '        strParameter = kraReader.GetString(6)
        '    End If

        '    Dim txtParameterWeight As New Label
        '    pnlTxtPnl.Controls.Add(txtParameterWeight)
        '    txtParameterWeight.CssClass = "weighthideinput"
        '    If strWeightage <> kraReader.GetString(6) Then
        '        txtParameterWeight.CssClass = "weightinput"
        '        txtParameterWeight.Text = kraReader.GetString(7)
        '        strWeightage = kraReader.GetString(6)
        '    End If

        '    Dim txtKeyDeter As New Label
        '    pnlTxtPnl.Controls.Add(txtKeyDeter)
        '    txtKeyDeter.CssClass = "krainput"
        '    txtKeyDeter.Text = kraReader.GetString(8)

        '    Dim txtKeyDeterWeight As New Label
        '    pnlTxtPnl.Controls.Add(txtKeyDeterWeight)
        '    txtKeyDeterWeight.CssClass = "weightinput"
        '    txtKeyDeterWeight.Text = kraReader.GetString(9)
        '    weightsum = weightsum + CDbl(kraReader.GetString(9).Substring(0, Len(kraReader.GetString(9)) - 1)) / 100

        '    Dim txtKeyDeterGoal As New Label
        '    pnlTxtPnl.Controls.Add(txtKeyDeterGoal)
        '    txtKeyDeterGoal.CssClass = "weightinput"
        '    txtKeyDeterGoal.Text = kraReader.GetString(10)

        '    Dim txtKeyDeterActual As New Label
        '    pnlTxtPnl.Controls.Add(txtKeyDeterActual)
        '    txtKeyDeterActual.CssClass = "weightinput"
        '    txtKeyDeterActual.Text = kraReader.GetString(11)

        '    Dim txtEmprating As New Label
        '    pnlTxtPnl.Controls.Add(txtEmprating)
        '    txtEmprating.CssClass = "weightinput"
        '    txtEmprating.Text = kraReader.GetString(12)

        '    Dim txtEmpscore As New Label
        '    pnlTxtPnl.Controls.Add(txtEmpscore)
        '    txtEmpscore.CssClass = "weightinput"
        '    txtEmpscore.Text = Math.Round(CDbl(kraReader.GetString(13)), 1)
        '    empsum = empsum + kraReader.GetString(13)
        '    If LCase(empno) = "admin" Then
        '        Dim txtReviewrating As New Label
        '        pnlTxtPnl.Controls.Add(txtReviewrating)
        '        txtReviewrating.CssClass = "weightinput"
        '        txtReviewrating.Text = kraReader.GetString(16)
        '        Dim txtReviewscore As New Label
        '        pnlTxtPnl.Controls.Add(txtReviewscore)
        '        txtReviewscore.CssClass = "weightinput"
        '        txtReviewscore.Text = Math.Round(CDbl(kraReader.GetString(17)), 1)


        '    End If
        '    revsum = revsum + kraReader.GetString(17)

        '    Dim cmd As New OdbcCommand("select round((sum(tran_revscore)/(tran_weightage/100))) from tb_tran_storerating where tran_param='" & kraReader.GetString(6) & "' and tran_empid='" & empid & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'", conn)
        '    cmd.Connection = conn
        '    rs = cmd.ExecuteReader()
        '    rs.Read()
        '    Dim txtsum As New Label
        '    pnlTxtPnl.Controls.Add(txtsum)
        '    txtsum.CssClass = "weightinput"
        '    If rs.HasRows Then
        '        If intHrrating <> kraReader.GetString(6) Then
        '            txtsum.Text = rs(0)
        '            intHrrating = kraReader.GetString(6)
        '            hrsum = hrsum + rs(0)
        '            totalrow = totalrow + 1
        '        End If
        '    End If
        '    rs.Close()
        'End While
        'hrsum = hrsum / totalrow
        'kraReader.Close()

        'Dim txtblank As New Label
        'pnlTxtPnl.Controls.Add(txtblank)
        'txtblank.CssClass = "kravalueslabel"
        'txtblank.Text = ""

        'Dim txtblank1 As New Label
        'pnlTxtPnl.Controls.Add(txtblank1)
        'txtblank1.CssClass = "kravaluesweightlabel"
        'txtblank1.Text = ""

        'Dim txtweightage As New Label
        'pnlTxtPnl.Controls.Add(txtweightage)
        'txtweightage.CssClass = "kravaluesweightlabel"
        'txtweightage.Text = "Total"

        'Dim txtblank12 As New Label
        'pnlTxtPnl.Controls.Add(txtblank12)
        'txtblank12.CssClass = "kravaluesweightlabel"
        'txtblank12.Text = ""


        'Dim txtblank11 As New Label
        'pnlTxtPnl.Controls.Add(txtblank11)
        'txtblank11.CssClass = "kravaluesweightlabel"
        'txtblank11.Text = ""


        'Dim txtweightsum As New Label
        'pnlTxtPnl.Controls.Add(txtweightsum)
        'txtweightsum.CssClass = "kravaluesweightlabel"
        'txtweightsum.Text = (weightsum * 100) & "%"

        'Dim txtblank2 As New Label
        'pnlTxtPnl.Controls.Add(txtblank2)
        'txtblank2.CssClass = "kravaluesweightlabel"
        'txtblank2.Text = ""

        'Dim txtblank3 As New Label
        'pnlTxtPnl.Controls.Add(txtblank3)
        'txtblank3.CssClass = "kravaluesweightlabel"
        'txtblank3.Text = ""

        'Dim txtblank4 As New Label
        'pnlTxtPnl.Controls.Add(txtblank4)
        'txtblank4.CssClass = "kravaluesweightlabel"
        'txtblank4.Text = ""

        'Dim txtempsum As New Label
        'pnlTxtPnl.Controls.Add(txtempsum)
        'txtempsum.CssClass = "kravaluesweightlabel"
        'txtempsum.Text = empsum

        'Dim txtblank5 As New Label
        'pnlTxtPnl.Controls.Add(txtblank5)
        'txtblank5.CssClass = "kravaluesweightlabel"
        'txtblank5.Text = ""

        'If LCase(empno) = "admin" Then
        '    Dim txtrevsum As New Label
        '    pnlTxtPnl.Controls.Add(txtrevsum)
        '    txtrevsum.CssClass = "kravaluesweightlabel"
        '    txtrevsum.Text = revsum

        'End If

        'Dim txthrsum As New Label
        'pnlTxtPnl.Controls.Add(txthrsum)
        'txthrsum.CssClass = "kravaluesweightlabel"
        'txthrsum.Text = Math.Round((revsum / (weightsum * 100)) * 100, 1)
        'txthrsum.Text = Math.Round(2.5, MidpointRounding.AwayfromZero)

        'DisplayParam = intLoop
    End Function



End Class
