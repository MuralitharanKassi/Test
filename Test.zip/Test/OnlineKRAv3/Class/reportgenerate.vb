'Imports System.Data.Odbc
Imports MySql.Data.MySqlClient
Module reportgenerate
    'Public Function DisplayParam(ByVal pnlTxtPnl As Panel, ByVal strMonth As String, ByVal strYear As String, ByVal empid As String, ByVal empno As String, Optional ByVal Role As String = "") As Integer
    '    Try
    '        Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    '        Dim strSQL As String
    '        Dim kraCommand As New OdbcCommand
    '        Dim kraReader As OdbcDataReader
    '        Dim Name As String
    '        Dim Project As String
    '        Dim Title As String

    '        kraConnection.Open()
    '        strSQL = "select Name,Project,Title from userinfo where EmpID='" & empid & "' and Month='" & strMonth & "' and Year='" & strYear & "'"
    '        kraCommand.CommandText = strSQL
    '        kraCommand.Connection = kraConnection
    '        kraReader = kraCommand.ExecuteReader()
    '        kraReader.Read()
    '        Name = kraReader("Name")
    '        Project = kraReader("Project")
    '        Title = kraReader("Title")
    '        kraReader.Close()

    '        strSQL = "select tran_empid,tran_month,tran_year,tran_param,tran_weightage,tran_keydeter,tran_weight,tran_goal,tran_actual,tran_emprating,tran_empscore,tran_apprating ,tran_appscore,tran_revrating,tran_revscore from tb_tran_storerating where tran_empid='" & empid & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'"
    '        kraCommand.CommandText = strSQL
    '        kraCommand.Connection = kraConnection
    '        kraReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
    '        Dim conn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    '        conn.Open()
    '        Dim totalrow As Integer = 0
    '        Dim intHrrating As String
    '        Dim rs As OdbcDataReader
    '        Dim weightsum As Double = 0.0
    '        Dim empsum As Double = 0.0
    '        Dim appsum As Double = 0.0
    '        Dim revsum As Double = 0.0
    '        Dim hrsum As Double = 0.0
    '        Dim intLoop As Integer = 0
    '        Dim strParameter As String = ""
    '        Dim kraTable As Table
    '        Dim kraRow As TableRow
    '        Dim kraCell As TableCell
    '        If kraReader.HasRows Then
    '            While kraReader.Read()
    '                intLoop = intLoop + 1
    '                If intLoop = 1 Then

    '                    'Employee Information Start
    '                    kraTable = New Table
    '                    kraTable.CellPadding = 2
    '                    kraTable.CellSpacing = 2
    '                    kraTable.Width = Unit.Percentage(100)
    '                    kraTable.CssClass = "datatable"

    '                    kraRow = New TableRow

    '                    AddTableCell(kraRow, "EmpID:", , 3)
    '                    AddTableCell(kraRow, empid, , 1)
    '                    AddTableCell(kraRow, "| Name:", , 3)
    '                    AddTableCell(kraRow, Name, , 1)
    '                    AddTableCell(kraRow, "| Month:", , 3)
    '                    AddTableCell(kraRow, MonthName(kraReader.GetString(1)) & "-" & kraReader.GetString(2), , 1)
    '                    AddTableCell(kraRow, "| Project:", , 3)
    '                    AddTableCell(kraRow, Project, , 1)
    '                    AddTableCell(kraRow, "| Title:", , 3)
    '                    AddTableCell(kraRow, Title, , 1)
    '                    AddTableRow(kraTable, kraRow, "dataTableHeader")
    '                    kraTable.Rows.Add(kraRow)

    '                    pnlTxtPnl.Controls.Add(kraTable)
    '                    'Employee Information End

    '                    'KRA Score Display Start
    '                    kraTable = New Table
    '                    kraRow = New TableRow

    '                    AddTableCell(kraRow, "Parameter")
    '                    'AddTableCell(kraRow, "Weightage")
    '                    AddTableCell(kraRow, "Key Determinant")
    '                    AddTableCell(kraRow, "Weightage")
    '                    AddTableCell(kraRow, "Goal")
    '                    AddTableCell(kraRow, "Actual")
    '                    AddTableCell(kraRow, "Appraiser Rating")
    '                    'AddTableCell(kraRow, "Rev Rating")
    '                    AddTableCell(kraRow, "Final Rating")

    '                    AddTableRow(kraTable, kraRow, "dataTableHeader")
    '                End If

    '                kraRow = New TableRow

    '                'If strParameter <> kraReader.GetString(3) Then
    '                '    strParameter = kraReader.GetString(3)
    '                '    AddTableCell(kraRow, kraReader.GetString(3))
    '                '    AddTableCell(kraRow, kraReader.GetString(4))
    '                'Else
    '                '    AddTableCell(kraRow)
    '                '    AddTableCell(kraRow)
    '                'End If
    '                AddTableCell(kraRow, kraReader.GetString(3))
    '                'AddTableCell(kraRow, kraReader.GetString(4))
    '                AddTableCell(kraRow, kraReader.GetString(5))
    '                AddTableCell(kraRow, kraReader.GetString(6))
    '                weightsum = weightsum + CDbl(kraReader.GetString(6).Substring(0, Len(kraReader.GetString(6)) - 1)) / 100
    '                AddTableCell(kraRow, kraReader.GetString(7))
    '                AddTableCell(kraRow, kraReader.GetString(8))
    '                AddTableCell(kraRow, kraReader.GetString(11))
    '                empsum = empsum + kraReader("tran_appscore")
    '                'AddTableCell(kraRow, kraReader.GetString(13))
    '                revsum = revsum + kraReader("tran_revscore")

    '                strSQL = "select ifnull(round((sum(tran_revscore)/(tran_weightage/100))),0) from tb_tran_storerating where tran_param='" & kraReader.GetString(3) & "' and tran_empid='" & empid & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'"
    '                Dim cmd As New OdbcCommand(strSQL, conn)
    '                cmd.Connection = conn
    '                rs = cmd.ExecuteReader()
    '                rs.Read()
    '                kraCell = New TableCell
    '                kraCell.Text = ""
    '                If rs.HasRows Then
    '                    If intHrrating <> kraReader.GetString(3) Then
    '                        kraCell.Text = rs.GetString(0)
    '                        intHrrating = kraReader.GetString(3)
    '                        hrsum = hrsum + rs(0)
    '                        totalrow = totalrow + 1
    '                    End If
    '                    kraRow.Cells.Add(kraCell)
    '                End If
    '                rs.Close()
    '                If intLoop Mod 2 = 0 Then
    '                    AddTableRow(kraTable, kraRow, "dataTableAlternate")
    '                Else
    '                    AddTableRow(kraTable, kraRow, "dataTableItem")
    '                End If

    '            End While

    '            hrsum = hrsum / totalrow
    '            kraReader.Close()
    '            conn.Close()
    '            kraConnection.Close()
    '            kraRow = New TableRow

    '            'AddTableCell(kraRow)
    '            AddTableCell(kraRow)
    '            AddTableCell(kraRow, "Total")
    '            AddTableCell(kraRow, (weightsum * 100) & "%")
    '            AddTableCell(kraRow)
    '            AddTableCell(kraRow)
    '            AddTableCell(kraRow, Math.Round(empsum, 1))
    '            'AddTableCell(kraRow, Math.Round(revsum, 1))
    '            AddTableCell(kraRow, Math.Round((revsum / (weightsum * 100)) * 100, 1))
    '            AddTableRow(kraTable, kraRow, "dataTableFooter")

    '            kraTable.CellPadding = 4
    '            kraTable.CellSpacing = 0
    '            kraTable.Width = Unit.Percentage(100)
    '            kraTable.CssClass = "datatable"
    '            pnlTxtPnl.Controls.Add(kraTable)
    '            Return intLoop
    '        End If
    '    Catch ex As Exception
    '        '"Error Occured in Main Function. Error: " & ex.Message
    '    End Try
    'End Function

    Public Function KRAReport(ByVal rptPanel As LiteralControl, ByVal EmpID As String, ByVal Month As String, ByVal Year As String, Optional ByVal Role As String = "") As Integer
        Try
            Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
            Dim Connection As New MySqlConnection(conString)
            Dim strSQL As String
            Dim Command As New MySqlCommand
            Dim Reader As MySqlDataReader
            Dim Name As String
            Dim Project As String
            Dim Title As String
            Dim kraTable As Table
            Dim kraRow As TableRow
            Dim kraCell As TableCell
            Dim Info As String = ""

            Connection.Open()
            strSQL = "select Name,Project,Title from userinfo where EmpID='" & EmpID & "' and Month='" & Month & "' and Year='" & Year & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Reader.Read()
            Name = Reader("Name")
            Project = Reader("Project")
            Title = Reader("Title")
            Reader.Close()

            'Employee Information Start
            Info &= "EmpID : " & EmpID & " | Name : " & Name & " | Month : " & MonthName(Reader.GetString(1)) & "-" & Reader.GetString(2)
            Info &= " | Project : " & Project & " | Title : " & Title
            'divInfo.innerHTML = Info
            'Employee Information End

            strSQL = "select tran_empid as EmpID,tran_month as Month,tran_year as Year,tran_param as Parameter,tran_weightage as Parameter_Weightage,tran_keydeter as KeyItem,tran_weight as KeyItem_Weightage,tran_goal as Goal,tran_actual as Actual,tran_apprating as App_Rating,tran_appscore as App_Score,tran_revrating as Rev_Rating,tran_revscore as Rev_Score from tb_tran_storerating where tran_empid='" & EmpID & "' and tran_month='" & Month & "' and tran_year='" & Year & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Dim totalrow As Integer = 0
            Dim intHrrating As String
            Dim rs As MySqlDataReader
            Dim weightsum As Double = 0.0
            'Dim empsum As Double = 0.0
            Dim appsum As Double = 0.0
            Dim revsum As Double = 0.0
            Dim hrsum As Double = 0.0
            Dim intLoop As Integer = 0
            Dim strParameter As String = ""
            If Reader.HasRows Then
                While Reader.Read()
                    intLoop = intLoop + 1
                    If intLoop = 1 Then



                        'KRA Score Display Start
                        kraTable = New Table
                        kraRow = New TableRow

                        AddTableCell(kraRow, "Parameter")
                        'AddTableCell(kraRow, "Weightage")
                        AddTableCell(kraRow, "Key Determinant")
                        AddTableCell(kraRow, "Weightage")
                        AddTableCell(kraRow, "Goal")
                        AddTableCell(kraRow, "Actual")
                        AddTableCell(kraRow, "Appraiser Rating")
                        'AddTableCell(kraRow, "Rev Rating")
                        AddTableCell(kraRow, "Final Rating")

                        AddTableRow(kraTable, kraRow, "dataTableHeader")
                    End If

                    kraRow = New TableRow

                    'If strParameter <> kraReader.GetString(3) Then
                    '    strParameter = kraReader.GetString(3)
                    '    AddTableCell(kraRow, kraReader.GetString(3))
                    '    AddTableCell(kraRow, kraReader.GetString(4))
                    'Else
                    '    AddTableCell(kraRow)
                    '    AddTableCell(kraRow)
                    'End If
                    AddTableCell(kraRow, Reader.GetString(3))
                    'AddTableCell(kraRow, kraReader.GetString(4))
                    AddTableCell(kraRow, Reader.GetString(5))
                    AddTableCell(kraRow, Reader.GetString(6))
                    weightsum = weightsum + CDbl(Reader.GetString(6).Substring(0, Len(Reader.GetString(6)) - 1)) / 100
                    AddTableCell(kraRow, Reader.GetString(7))
                    AddTableCell(kraRow, Reader.GetString(8))
                    AddTableCell(kraRow, Reader.GetString(11))
                    empsum = empsum + Reader("tran_appscore")
                    'AddTableCell(kraRow, kraReader.GetString(13))
                    revsum = revsum + Reader("tran_revscore")

                    strSQL = "select ifnull(round((sum(tran_revscore)/(tran_weightage/100))),0) from tb_tran_storerating where tran_param='" & Reader.GetString(3) & "' and tran_empid='" & EmpID & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    rs = Command.ExecuteReader()
                    rs.Read()
                    kraCell = New TableCell
                    kraCell.Text = ""
                    If rs.HasRows Then
                        If intHrrating <> Reader.GetString(3) Then
                            kraCell.Text = rs.GetString(0)
                            intHrrating = Reader.GetString(3)
                            hrsum = hrsum + rs(0)
                            totalrow = totalrow + 1
                        End If
                        kraRow.Cells.Add(kraCell)
                    End If
                    rs.Close()
                    If intLoop Mod 2 = 0 Then
                        AddTableRow(kraTable, kraRow, "dataTableAlternate")
                    Else
                        AddTableRow(kraTable, kraRow, "dataTableItem")
                    End If

                End While

                hrsum = hrsum / totalrow
                Reader.Close()
                Connection.Close()
                'Connection.Close()
                kraRow = New TableRow

                'AddTableCell(kraRow)
                AddTableCell(kraRow)
                AddTableCell(kraRow, "Total")
                AddTableCell(kraRow, (weightsum * 100) & "%")
                AddTableCell(kraRow)
                AddTableCell(kraRow)
                AddTableCell(kraRow, Math.Round(empsum, 1))
                'AddTableCell(kraRow, Math.Round(revsum, 1))
                AddTableCell(kraRow, Math.Round((revsum / (weightsum * 100)) * 100, 1))
                AddTableRow(kraTable, kraRow, "dataTableFooter")

                kraTable.CellPadding = 4
                kraTable.CellSpacing = 0
                kraTable.Width = Unit.Percentage(100)
                kraTable.CssClass = "datatable"
                pnlTxtPnl.Controls.Add(kraTable)
                Return intLoop
            End If
        Catch ex As Exception
            '"Error Occured in Main Function. Error: " & ex.Message
        End Try
    End Function

    'Public Function CheckRating(ByVal pnlTxtPnl As Panel, ByVal strMonth As String, ByVal strYear As String, ByVal empid As String, ByVal empno As String) As Integer
    '    'Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    '    'kraConnection.Open()
    '    'Dim strSQL As String = "select parameter, weight, key_deter, Weightage, Goal from tb_mast_service where Title='6'"
    '    'Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
    '    'Dim kraReader As OdbcDataReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
    '    Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    '    kraConnection.Open()

    '    Dim strSQL As String
    '    Dim kraCommand As New OdbcCommand
    '    Dim kraReader As OdbcDataReader

    '    strSQL = "select Name,Project,Title from userinfo where EmpID='" & empid & "' and Month='" & strMonth & "' and Year='" & strYear & "'"
    '    kraCommand.CommandText = strSQL
    '    kraCommand.Connection = kraConnection
    '    kraReader = kraCommand.ExecuteReader()
    '    Dim Name As String = kraReader("Name")
    '    Dim Project As String = kraReader("Project")
    '    Dim Title As String = kraReader("Title")
    '    kraReader.Close()

    '    strSQL = "select tran_empid,tran_month,tran_year,tran_param,tran_weightage,tran_keydeter,tran_weight,tran_goal,tran_actual,tran_emprating,tran_empscore,tran_apprating ,tran_appscore,tran_revrating,tran_revscore from tb_tran_storerating where tran_empid='" & empid & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'"

    '    kraCommand.CommandText = strSQL
    '    kraCommand.Connection = kraConnection
    '    kraReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
    '    Dim conn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    '    conn.Open()
    '    Dim totalrow As Integer = 0
    '    Dim intHrrating As String
    '    Dim rs As OdbcDataReader
    '    'Dim strSQL_sum As String
    '    'Dim kraCommand_sum As OdbcCommand
    '    'Dim kraReader_sum As OdbcDataReader
    '    Dim weightsum As Double = 0.0
    '    Dim empsum As Double = 0.0
    '    Dim appsum As Double = 0.0
    '    Dim revsum As Double = 0.0
    '    Dim hrsum As Double = 0.0
    '    Dim intLoop As Integer = 0
    '    Dim strParameter As String = ""
    '    Dim strWeightage As String = ""

    '    Dim kraTable As Table
    '    Dim kraRow As TableRow
    '    Dim kraCell As TableCell

    '    While kraReader.Read()
    '        intLoop = intLoop + 1
    '        If intLoop = 1 Then

    '            'Employee Information Start
    '            kraTable = New Table
    '            kraRow = New TableRow

    '            kraCell = New TableCell
    '            kraCell.Text = "Emp ID:"
    '            kraCell.HorizontalAlign = HorizontalAlign.Right
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = empid
    '            kraCell.HorizontalAlign = HorizontalAlign.Left
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "| Emp Name:"
    '            kraCell.HorizontalAlign = HorizontalAlign.Right
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = Name
    '            kraCell.HorizontalAlign = HorizontalAlign.Left
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "| Month & Year:"
    '            kraCell.HorizontalAlign = HorizontalAlign.Right
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = kraReader.GetString(2) & "-" & kraReader.GetString(3)
    '            kraCell.HorizontalAlign = HorizontalAlign.Left
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "| Project:"
    '            kraCell.HorizontalAlign = HorizontalAlign.Right
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = Project
    '            kraCell.HorizontalAlign = HorizontalAlign.Left
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "| Title:"
    '            kraCell.HorizontalAlign = HorizontalAlign.Right
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = Title
    '            kraCell.HorizontalAlign = HorizontalAlign.Left
    '            kraRow.Cells.Add(kraCell)
    '            kraRow.CssClass = "kravaluesweightlabel"
    '            kraTable.Rows.Add(kraRow)
    '            kraTable.CellPadding = 2
    '            kraTable.CellSpacing = 0
    '            kraTable.Width = Unit.Percentage(100)

    '            pnlTxtPnl.Controls.Add(kraTable)
    '            'Employee Information End

    '            'KRA Score Display Start
    '            kraTable = New Table
    '            kraRow = New TableRow

    '            kraCell = New TableCell
    '            kraCell.Text = "Parameter"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Weightage"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Key Determinant"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Weightage"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Goal"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Actual"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Emp Rating"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Emp Score"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Rev Rating"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Rev Score"
    '            kraRow.Cells.Add(kraCell)
    '            kraCell = New TableCell
    '            kraCell.Text = "Final Rating"
    '            kraRow.Cells.Add(kraCell)
    '            kraRow.CssClass = "kravaluesweightlabel"
    '            kraTable.Rows.Add(kraRow)

    '        End If

    '        kraRow = New TableRow

    '        kraCell = New TableCell
    '        kraCell.Text = ""
    '        If strParameter <> kraReader.GetString(3) Then
    '            strParameter = kraReader.GetString(3)
    '            kraCell.Text = kraReader.GetString(3)
    '        End If
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = ""
    '        If strWeightage <> kraReader.GetString(3) Then
    '            strWeightage = kraReader.GetString(3)
    '            kraCell.Text = kraReader.GetString(4)
    '        End If
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = kraReader.GetString(5)
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = kraReader.GetString(6)
    '        kraRow.Cells.Add(kraCell)
    '        weightsum = weightsum + CDbl(kraReader.GetString(6).Substring(0, Len(kraReader.GetString(6)) - 1)) / 100

    '        kraCell = New TableCell
    '        kraCell.Text = kraReader.GetString(7)
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = kraReader.GetString(8)
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = kraReader.GetString(9)
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = Math.Round(CDbl(kraReader.GetString(10)), 1)
    '        kraRow.Cells.Add(kraCell)
    '        empsum = empsum + kraReader.GetString(10)

    '        'If LCase(empno) = "admin" Then

    '        kraCell = New TableCell
    '        kraCell.Text = kraReader.GetString(13)
    '        kraRow.Cells.Add(kraCell)

    '        kraCell = New TableCell
    '        kraCell.Text = Math.Round(CDbl(kraReader.GetString(14)), 1)
    '        kraRow.Cells.Add(kraCell)

    '        'End If
    '        revsum = revsum + kraReader.GetString(14)

    '        Dim cmd As New OdbcCommand("select round((sum(tran_revscore)/(tran_weightage/100))) from tb_tran_storerating where tran_param='" & kraReader.GetString(3) & "' and tran_empid='" & empid & "' and tran_month='" & strMonth & "' and tran_year='" & strYear & "'", conn)
    '        cmd.Connection = conn
    '        rs = cmd.ExecuteReader()
    '        rs.Read()
    '        kraCell = New TableCell
    '        kraCell.Text = ""
    '        If rs.HasRows Then
    '            If intHrrating <> kraReader.GetString(3) Then
    '                kraCell.Text = rs(0)
    '                intHrrating = kraReader.GetString(3)
    '                hrsum = hrsum + rs(0)
    '                totalrow = totalrow + 1
    '            End If
    '            kraRow.Cells.Add(kraCell)
    '        End If
    '        rs.Close()
    '        kraRow.CssClass = "weightinput"
    '        kraTable.Rows.Add(kraRow)
    '    End While

    '    hrsum = hrsum / totalrow
    '    kraReader.Close()
    '    conn.Close()
    '    kraConnection.Close()
    '    kraRow = New TableRow

    '    kraCell = New TableCell
    '    kraCell.Text = ""
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = ""
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = "Total"
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = (weightsum * 100) & "%"
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = ""
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = ""
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = ""
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = empsum
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = ""
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = revsum
    '    kraRow.Cells.Add(kraCell)
    '    kraCell = New TableCell
    '    kraCell.Text = Math.Round((revsum / (weightsum * 100)) * 100, 1)
    '    'kracell.Text = Math.Round(2.5, MidpointRounding.AwayfromZero)
    '    kraRow.Cells.Add(kraCell)
    '    kraRow.CssClass = "kravaluesweightlabel"

    '    kraTable.Rows.Add(kraRow)

    '    kraTable.CellPadding = 2
    '    'KRA Score Display Start
    '    kraTable.Width = Unit.Percentage(100)
    '    pnlTxtPnl.Controls.Add(kraTable)
    '    Return intLoop
    'End Function

End Module
