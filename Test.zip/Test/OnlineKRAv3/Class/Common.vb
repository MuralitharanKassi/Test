﻿Module Common

    Public Function FormatData(ByVal DataString As String, Optional ByVal ifNull As String = "") As String
        If DataString = "" And ifNull <> "" Then DataString = ifNull
        DataString = Replace(DataString, "'", "\'")
        Return DataString
    End Function

    Public Sub AddTableCell(ByRef Row As TableRow, Optional ByVal Text As String = "", Optional ByVal Css As String = "", Optional ByVal Align As Integer = 0, Optional ByVal Width As Integer = 0, Optional ByVal Style As String = "")
        Dim Cell As New TableCell
        Cell.Text = Text
        Cell.CssClass = Css
        If Style <> "" Then
            Dim stylelist() As String
            Dim styleitem() As String
            Dim i As Integer
            stylelist = Style.Split(";")
            For i = 0 To UBound(stylelist)
                styleitem = stylelist(i).Split(":")
                If styleitem(0) <> "" And styleitem(1) <> "" Then
                    Cell.Style.Add(styleitem(0), styleitem(1))
                End If
            Next
        End If
        Cell.HorizontalAlign = Align 'NotSet-0,Left-1,Center-2,Right-3,Justify-4
        If Width <> 0 Then Cell.Width = Unit.Parse(Width)
        Row.Cells.Add(Cell)
    End Sub

    Public Sub AddTableRow(ByRef Table As Table, ByRef Row As TableRow, Optional ByVal Css As String = "", Optional ByVal Style As String = "")
        Row.CssClass = Css
        If Style <> "" Then
            Dim stylelist() As String
            Dim styleitem() As String
            Dim i As Integer
            stylelist = Style.Split(";")
            For i = 0 To UBound(stylelist)
                styleitem = stylelist(i).Split(":")
                If styleitem(0) <> "" And styleitem(1) <> "" Then
                    Row.Style.Add(styleitem(0), styleitem(1))
                End If
            Next
        End If
        Table.Rows.Add(Row)
    End Sub

    Public Function Encrypt(ByVal Text As String) As String
        If (Text = "") Then
            Return ""
        End If
        Dim cryptkey As String = "themis"
        Dim keyval As String
        Dim kv() As String
        Dim estr As String = ""
        'Dim enc As String
        Dim i As Integer
        Dim e As String
        Dim rndval As Integer
        keyval = keyvalue(cryptkey)
        kv = Split(keyval, "/")
        For i = 0 To Len(Text)
            e = Mid(Text, i + 1)
            e = Microsoft.VisualBasic.Left(e, 1)
            If (e <> "") Then
                e = Asc(e)
                e = Int(Int(e) + Int(kv(0)))
                e = Int(Int(e) * Int(kv(1)))
                Randomize()
                rndval = Int((90 - 65 + 1) * Rnd() + 65)
                estr = estr & Chr(rndval) & e
            End If
        Next
        Return estr
    End Function
    Function Decrypt(ByVal Text As String) As String
        Dim cryptkey As String = "themis"
        Dim keyval As String
        Dim kv() As String
        Dim estr As String
        Dim tmp As String
        'Dim e As String
        Dim i As Integer
        keyval = keyvalue(cryptkey)
        kv = Split(keyval, "/")
        estr = ""
        tmp = ""
        For i = 1 To Len(Text)
            If (Microsoft.VisualBasic.Left(Mid(Text, i), 1) <> "") Then
                If (Asc(Microsoft.VisualBasic.Left(Mid(Text, i), 1)) > 64) And (Asc(Microsoft.VisualBasic.Left(Mid(Text, i), 1)) < 91) Then
                    If (tmp <> "") Then
                        tmp = Int(tmp / Int(kv(1)))
                        tmp = Int(tmp - Int(kv(0)))
                        estr = estr & Chr(tmp)
                        tmp = ""
                    End If
                Else
                    tmp = tmp & Microsoft.VisualBasic.Left(Mid(Text, i), 1)
                End If
            End If
        Next

        tmp = Int(tmp / Int(kv(1)))
        tmp = Int(tmp - Int(kv(0)))
        estr = estr & Chr(tmp)
        Return estr
    End Function
    Public Function keyvalue(ByVal cryptkey As String) As String
        Dim keyval1 As Integer
        Dim keyval2 As Integer
        keyval1 = 0
        keyval2 = 0
        Dim i As Integer
        Dim curchr As String
        i = 1
        For i = 1 To Len(cryptkey)
            curchr = Mid(cryptkey, i + 1)
            curchr = Microsoft.VisualBasic.Left(curchr, 1)
            If curchr <> "" Then
                curchr = Asc(curchr)
                keyval1 = Int(keyval1 + curchr)
                keyval2 = Len(cryptkey)
            End If
        Next
        Return (keyval1 & "/" & keyval2)
    End Function
    Public Function MonthName(ByVal Month As Integer, Optional ByVal ShortName As Boolean = False) As String
        Dim strMonth As String = "January"
        Select Case Month
            Case 1
                strMonth = "January"
            Case 2
                strMonth = "Febuary"
            Case 3
                strMonth = "March"
            Case 4
                strMonth = "April"
            Case 5
                strMonth = "May"
            Case 6
                strMonth = "June"
            Case 7
                strMonth = "July"
            Case 8
                strMonth = "August"
            Case 9
                strMonth = "September"
            Case 10
                strMonth = "October"
            Case 11
                strMonth = "November"
            Case 12
                strMonth = "December"
        End Select
        If ShortName = True Then strMonth = Mid(strMonth, 1, 3)
        Return strMonth
    End Function

    Public Function getMonthEnd(ByVal sDate As Date) As Date
        Dim month As Integer = sDate.Month()
        Dim day As Integer = sDate.Day
        Dim monthCount As Integer
        Select Case month
            Case 1, 3, 5, 7, 8, 10, 12
                monthCount = 31
            Case 4, 6, 9, 11
                monthCount = 30
            Case 2
                If sDate.Year() Mod 4 = 0 Then
                    monthCount = 29
                Else
                    monthCount = 28
                End If
        End Select
        sDate = sDate.AddDays(monthCount - day)
        getMonthEnd = sDate
    End Function

    Function StringFill(ByVal Text As String, ByVal Length As Integer, Optional ByVal FillChar As String = "0") As String
        Dim i As Integer
        If Length > Text.Length Then
            For i = 1 To Length - Text.Length
                Text = FillChar & Text
            Next
        End If
        Return Text
    End Function

    Function MSDateTime(ByVal sdate As String) As String
        Dim idate As Date
        idate = Date.Parse(sdate.Replace("-", "/")).ToString
        MSDateTime = Year(idate) & "-" & StringFill(Month(idate), 2) & "-" & StringFill(Day(idate), 2) & " " & StringFill(Hour(idate), 2) & ":" & StringFill(Minute(idate), 2) & ":" & StringFill(Second(idate), 2)
    End Function

    Function MSDate(ByVal sdate As String) As String
        Dim idate As Date
        idate = Date.Parse(sdate.Replace("-", "/")).ToString
        MSDate = Year(idate) & "-" & StringFill(Month(idate), 2) & "-" & StringFill(Day(idate), 2)
    End Function

    Public Function GetMonth(ByVal MonthYear As Integer) As Integer
        Return (MonthYear - (100 * Math.Round(MonthYear / 100)))
    End Function

    Public Function GetYear(ByVal MonthYear As Integer) As Integer
        Return (Math.Round(MonthYear / 100))
    End Function
End Module
