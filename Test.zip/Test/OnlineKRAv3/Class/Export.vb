﻿Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.html
Imports iTextSharp.text.html.simpleparser

Module Export

    Public Sub Repeater2Excel(ByVal DataRepeater As Repeater, ByVal Filename As String, ByVal PreAppend As String, ByVal PostAppend As String, Optional ByVal CSSFile As String = "")
        With HttpContext.Current.Response
            .Clear()
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/vnd.xls"
            .AddHeader("content-disposition", "attachment;filename=" & Filename & ".xls")

            Dim sw As New System.IO.StringWriter
            Dim htw As New HtmlTextWriter(sw)
            DataRepeater.RenderControl(htw)

            Dim sb1 As New System.Text.StringBuilder
            sb1 = sb1.Append("<html><head>")
            sb1 = sb1.Append("<style> .textmode { mso-number-format:\@; } </style>")
            If CSSFile <> "" Then
                'Appending CSS file
                Dim fi As FileInfo = New FileInfo(System.Web.HttpContext.Current.Server.MapPath(CSSFile))
                Dim sb As New System.Text.StringBuilder
                Dim sr As StreamReader = fi.OpenText()
                Do While sr.Peek() >= 0
                    sb.Append(sr.ReadLine())
                Loop
                sr.Close()
                sb1 = sb1.Append("<style type='text/css'>" & sb.ToString() & "</style>")
                sb.Remove(0, sb.Length)
            End If
            sb1 = sb1.Append("</head><body>" & PreAppend & sw.ToString() & PostAppend & "</body></html>")

            sw = Nothing
            htw = Nothing

            .Write(sb1.ToString())
            sb1.Remove(0, sb1.Length)
            .Flush()
            .End()
        End With
    End Sub

    Public Sub Repeater2Word(ByVal DataRepeater As Repeater, ByVal Filename As String, ByVal PreAppend As String, ByVal PostAppend As String, Optional ByVal CSSFile As String = "")
        With HttpContext.Current.Response
            .Clear()
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/vnd.ms-word"
            .AddHeader("content-disposition", "attachment;filename=" & Filename & ".doc")

            Dim sw As New System.IO.StringWriter
            Dim htw As New HtmlTextWriter(sw)
            DataRepeater.RenderControl(htw)

            Dim sb1 As New System.Text.StringBuilder
            sb1 = sb1.Append("<html><head>")
            'sb1 = sb1.Append("<style> .textmode { mso-number-format:\@; } </style>")
            If CSSFile <> "" Then
                'Appending CSS file
                Dim fi As FileInfo = New FileInfo(System.Web.HttpContext.Current.Server.MapPath(CSSFile))
                Dim sb As New System.Text.StringBuilder
                Dim sr As StreamReader = fi.OpenText()
                Do While sr.Peek() >= 0
                    sb.Append(sr.ReadLine())
                Loop
                sr.Close()
                sb1 = sb1.Append("<style type='text/css'>" & sb.ToString() & "</style>")
                sb.Remove(0, sb.Length)
            End If
            sb1 = sb1.Append("</head><body>" & PreAppend & sw.ToString() & PostAppend & "</body></html>")

            sw = Nothing
            htw = Nothing
            .Write(sb1.ToString())
            sb1.Remove(0, sb1.Length)
            .Flush()
            .End()
        End With
    End Sub

    Public Sub Repeater2PDF(ByVal DataRepeater As Repeater, ByVal Filename As String, ByVal PreAppend As String, ByVal PostAppend As String, Optional ByVal CSSFile As String = "")
        With HttpContext.Current.Response
            .Clear()
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/pdf"
            .AddHeader("content-disposition", "attachment;filename=" & Filename & ".pdf")

            Dim sw As New System.IO.StringWriter
            Dim htw As New HtmlTextWriter(sw)
            DataRepeater.RenderControl(htw)

            Dim sb1 As New System.Text.StringBuilder
            sb1 = sb1.Append("<html><head>")
            'sb1 = sb1.Append("<style> .textmode { mso-number-format:\@; } </style>")
            'If CSSFile <> "" Then
            '    'Appending CSS file
            '    Dim fi As FileInfo = New FileInfo(System.Web.HttpContext.Current.Server.MapPath(CSSFile))
            '    Dim sb As New System.Text.StringBuilder
            '    Dim sr As StreamReader = fi.OpenText()
            '    Do While sr.Peek() >= 0
            '        sb.Append(sr.ReadLine())
            '    Loop
            '    sr.Close()
            '    sb1 = sb1.Append("<style type='text/css'>" & sb.ToString() & "</style>")
            '    sb.Remove(0, sb.Length)
            'End If
            sb1 = sb1.Append("</head><body>" & PreAppend & sw.ToString() & PostAppend & "</body></html>")

            sw = Nothing
            htw = Nothing

            Dim sr1 As New System.IO.StringReader(sb1.ToString())
            Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)
            Dim htmlparser As New HTMLWorker(pdfDoc)
            PdfWriter.GetInstance(pdfDoc, .OutputStream)
            pdfDoc.Open()
            htmlparser.Parse(sr1)
            pdfDoc.Close()
            .Write(pdfDoc)
            sb1.Remove(0, sb1.Length)
            .Flush()
            .End()
        End With
    End Sub

    Public Sub Datagrid2Excel(ByVal DataGrid As DataGrid, ByVal Filename As String, ByVal PreAppend As String, ByVal PostAppend As String, Optional ByVal CSSFile As String = "")
        With HttpContext.Current.Response
            .Clear()
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/vnd.xls"
            .AddHeader("content-disposition", "attachment;filename=" & Filename & ".xls")

            Dim sw As New System.IO.StringWriter
            Dim htw As New HtmlTextWriter(sw)
            DataGrid.RenderControl(htw)

            Dim sb1 As New System.Text.StringBuilder
            sb1 = sb1.Append("<html><head>")
            sb1 = sb1.Append("<style> .textmode { mso-number-format:\@; } </style>")
            If CSSFile <> "" Then
                'Appending CSS file
                Dim fi As FileInfo = New FileInfo(System.Web.HttpContext.Current.Server.MapPath(CSSFile))
                Dim sb As New System.Text.StringBuilder
                Dim sr As StreamReader = fi.OpenText()
                Do While sr.Peek() >= 0
                    sb.Append(sr.ReadLine())
                Loop
                sr.Close()
                sb1 = sb1.Append("<style type='text/css'>" & sb.ToString() & "</style>")
                sb.Remove(0, sb.Length)
            End If
            sb1 = sb1.Append("</head><body>" & PreAppend & sw.ToString() & PostAppend & "</body></html>")

            sw = Nothing
            htw = Nothing

            .Write(sb1.ToString())
            sb1.Remove(0, sb1.Length)
            .Flush()
            .End()
        End With
    End Sub

    Public Sub Datagrid2Word(ByVal DataGrid As DataGrid, ByVal Filename As String, ByVal PreAppend As String, ByVal PostAppend As String, Optional ByVal CSSFile As String = "")
        With HttpContext.Current.Response
            .Clear()
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/vnd.ms-word"
            .AddHeader("content-disposition", "attachment;filename=" & Filename & ".doc")

            Dim sw As New System.IO.StringWriter
            Dim htw As New HtmlTextWriter(sw)
            DataGrid.RenderControl(htw)

            Dim sb1 As New System.Text.StringBuilder
            sb1 = sb1.Append("<html><head>")
            'sb1 = sb1.Append("<style> .textmode { mso-number-format:\@; } </style>")
            If CSSFile <> "" Then
                'Appending CSS file
                Dim fi As FileInfo = New FileInfo(System.Web.HttpContext.Current.Server.MapPath(CSSFile))
                Dim sb As New System.Text.StringBuilder
                Dim sr As StreamReader = fi.OpenText()
                Do While sr.Peek() >= 0
                    sb.Append(sr.ReadLine())
                Loop
                sr.Close()
                sb1 = sb1.Append("<style type='text/css'>" & sb.ToString() & "</style>")
                sb.Remove(0, sb.Length)
            End If
            sb1 = sb1.Append("</head><body>" & PreAppend & sw.ToString() & PostAppend & "</body></html>")

            sw = Nothing
            htw = Nothing
            .Write(sb1.ToString())
            sb1.Remove(0, sb1.Length)
            .Flush()
            .End()
        End With
    End Sub

    Public Sub Datagrid2PDF(ByVal DataGrid As DataGrid, ByVal Filename As String, ByVal PreAppend As String, ByVal PostAppend As String, Optional ByVal CSSFile As String = "")
        With HttpContext.Current.Response
            .Clear()
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/pdf"
            .AddHeader("content-disposition", "attachment;filename=" & Filename & ".pdf")

            Dim sw As New System.IO.StringWriter
            Dim htw As New HtmlTextWriter(sw)
            DataGrid.RenderControl(htw)

            Dim sb1 As New System.Text.StringBuilder
            sb1 = sb1.Append("<html><head>")
            'sb1 = sb1.Append("<style> .textmode { mso-number-format:\@; } </style>")
            'If CSSFile <> "" Then
            '    'Appending CSS file
            '    Dim fi As FileInfo = New FileInfo(System.Web.HttpContext.Current.Server.MapPath(CSSFile))
            '    Dim sb As New System.Text.StringBuilder
            '    Dim sr As StreamReader = fi.OpenText()
            '    Do While sr.Peek() >= 0
            '        sb.Append(sr.ReadLine())
            '    Loop
            '    sr.Close()
            '    sb1 = sb1.Append("<style type='text/css'>" & sb.ToString() & "</style>")
            '    sb.Remove(0, sb.Length)
            'End If
            sb1 = sb1.Append("</head><body>" & PreAppend & sw.ToString() & PostAppend & "</body></html>")

            sw = Nothing
            htw = Nothing

            Dim sr1 As New System.IO.StringReader(sb1.ToString())
            Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)
            Dim htmlparser As New HTMLWorker(pdfDoc)
            PdfWriter.GetInstance(pdfDoc, .OutputStream)
            pdfDoc.Open()
            htmlparser.Parse(sr1)
            pdfDoc.Close()
            .Write(pdfDoc)
            sb1.Remove(0, sb1.Length)
            .Flush()
            .End()
        End With
    End Sub
End Module
