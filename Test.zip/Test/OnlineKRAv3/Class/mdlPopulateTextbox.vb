Imports System.Data.Odbc

Module mdlPopulateTextbox

    Public Function PopulateParam(ByVal pnlTxtPnl As Panel, ByVal strWhereCondValue As String, Optional ByVal strOptCondValue As String = "") As String
        Dim Connection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Connection.Open()
        Dim formvalidation As String
        Dim kraActualCount As New OdbcCommand("Select count(*) from tb_temp_storerating", Connection)
        Dim kraReader As OdbcDataReader = kraActualCount.ExecuteReader(CommandBehavior.Default)
        Dim intLoop As Integer = 0
        If kraReader.HasRows Then
            kraReader.Read()
            intLoop = kraReader(0)
        End If
        kraReader.Close()
        Dim Actuals(intLoop) As String
        Dim kraActual As New OdbcCommand("Select tran_actual from tb_temp_storerating", Connection)
        kraReader = kraActual.ExecuteReader(CommandBehavior.Default)
        intLoop = 0
        If kraReader.HasRows Then
            While kraReader.Read()
                Actuals(intLoop) = kraReader(0)
                intLoop = intLoop + 1
            End While
        End If
        kraReader.Close()
        Dim strSQL As String = "select parameter, weight, key_deter, Weightage, Goal, role_model from tb_mast_service where " & strWhereCondValue & " and Project='" & strOptCondValue & "'"
        Dim kraCommand As New OdbcCommand(strSQL, Connection)
        kraReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)

        intLoop = 0
        Dim strParameter As String = ""
        Dim strWeightage As String = ""

        Dim kraTable As Table
        Dim kraRow As TableRow
        Dim kraCell As TableCell
        If kraReader.HasRows Then
            While kraReader.Read()
                Dim i = 1
                intLoop = intLoop + 1

                If intLoop = 1 Then
                    kraTable = New Table
                    kraRow = New TableRow

                    AddTableCell(kraRow, "Parameter", , , 80)
                    AddTableCell(kraRow, "Weightage", , , 50)
                    AddTableCell(kraRow, "Key Determinant", , , 250)
                    AddTableCell(kraRow, "Weightage", , , 50)
                    AddTableCell(kraRow, "Goal", , , 50)
                    AddTableCell(kraRow, "Actual", , , 50)
                    'AddTableCell(kraRow, "Parameter")
                    'AddTableCell(kraRow)
                    AddTableCell(kraRow, , , , 50)
                    kraRow.CssClass = "kravaluesweightlabel"
                    kraTable.Rows.Add(kraRow)
                End If

                kraRow = New TableRow

                kraCell = New TableCell
                kraCell.Text = ""
                If strParameter <> kraReader.GetString(0) Then
                    strParameter = kraReader.GetString(0)
                    Dim txtParameter As New Label
                    kraCell.Controls.Add(txtParameter)
                    txtParameter.CssClass = "paraminput"
                    txtParameter.ID = "param" & intLoop
                    txtParameter.Text = kraReader.GetString(0)
                End If
                kraRow.Cells.Add(kraCell)

                kraCell = New TableCell
                kraCell.Text = ""
                If strWeightage <> kraReader.GetString(0) Then
                    strWeightage = kraReader.GetString(0)
                    kraCell.Text = kraReader.GetString(1) & "%"
                End If
                kraRow.Cells.Add(kraCell)

                AddTableCell(kraRow, kraReader.GetString(2))
                AddTableCell(kraRow, kraReader.GetString(3) & "%")

                kraCell = New TableCell
                Dim txtKeyDeterGoal As New Label
                kraCell.Controls.Add(txtKeyDeterGoal)
                txtKeyDeterGoal.ID = "goal" & intLoop
                txtKeyDeterGoal.CssClass = "weightinput"

                If (kraReader.GetString(4).LastIndexOf(":") >= 0) Then
                    txtKeyDeterGoal.Text = kraReader.GetString(4)
                Else
                    If (kraReader.GetString(4) < 1 And kraReader.GetString(4) <> 0) Then
                        txtKeyDeterGoal.Text = kraReader.GetString(4) * 100 & "%"
                    ElseIf (kraReader.GetString(4) = 100) And (kraReader.GetString(5) <= 1) Then
                        txtKeyDeterGoal.Text = kraReader.GetString(4) & "%"
                    Else
                        txtKeyDeterGoal.Text = kraReader.GetString(4)
                    End If
                End If
                kraRow.Cells.Add(kraCell)

                kraCell = New TableCell
                Dim txtKeyDeterActual As New TextBox
                kraCell.Controls.Add(txtKeyDeterActual)
                txtKeyDeterActual.ID = "actual" & intLoop
                txtKeyDeterActual.CssClass = "activetxtbox"
                txtKeyDeterActual.Style.Add("width", "80px")
                If UBound(Actuals) > 0 Then
                    Dim actual As String
                    Dim percentagecheck As Integer
                    percentagecheck = Actuals(intLoop - 1).IndexOf("%")
                    If (percentagecheck > -1) Then
                        actual = Actuals(intLoop - 1).Substring(0, Len(Actuals(intLoop - 1)) - 1)
                    Else
                        actual = Actuals(intLoop - 1)
                    End If
                    txtKeyDeterActual.Text = actual
                End If
                kraRow.Cells.Add(kraCell)

                kraCell = New TableCell

                Dim reg_time As New RegularExpressionValidator
                reg_time.ControlToValidate = "actual" & intLoop
                formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','req','Please fill all the fields');" & vbCrLf

                If (kraReader.GetString(4).LastIndexOf(":") >= 0) Then
                    'formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','regexp=^(\d{1,2}):(\d{2}):(\d{2})$','Please enter valid time format');" & vbCrLf
                    reg_time.ValidationExpression = "(\d)?\d:\d\d:\d\d"
                    reg_time.Text = "Improper time format"
                    kraCell.Controls.Add(reg_time)
                    reg_time.ID = "RegularExpressionValidator" & intLoop
                Else
                    If ((kraReader.GetString(4) < 1 And kraReader.GetString(4) <> 0) Or (kraReader.GetString(4) = 100 And kraReader.GetString(5) <= 1)) Then
                        'formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','regexp=^(\d{1,3})(\%)?$','Invalid entry');" & vbCrLf
                        reg_time.ValidationExpression = "[\d\d]\d(%)?"
                        reg_time.Text = "Use goal format"
                        kraCell.Controls.Add(reg_time)
                        reg_time.ID = "RegularExpressionValidator" & intLoop
                    Else
                        'formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','regexp=^(\d)+(\.)?(\d{0,3})$','Invalid entry');" & vbCrLf
                        txtKeyDeterGoal.Text = kraReader.GetString(4)
                        reg_time.ValidationExpression = "[0-9,:,.]+"
                        reg_time.Text = "Invalid entry. Pls avoid spl chars"
                        kraCell.Controls.Add(reg_time)
                        reg_time.ID = "RegularExpressionValidator" & intLoop
                    End If
                End If
                kraRow.Cells.Add(kraCell)

                kraRow.CssClass = "weightinput"
                kraTable.Rows.Add(kraRow)

                i = i + 1
            End While
        End If
        kraReader.Close()
        kraTable.CellPadding = 2
        kraTable.Width = Unit.Percentage(100)
        pnlTxtPnl.Controls.Add(kraTable)
        'PopulateParam = intLoop
        PopulateParam = intLoop & "|" & formvalidation
    End Function
    Public Function PopulateParamActual(ByVal Container As Panel, ByVal Month As Integer, ByVal Year As Integer, ByVal EmpID As Integer, ByVal TitleID As Integer, ByVal ProjectID As Integer, Optional ByVal EditKRA As Boolean = False) As String
        Dim Connection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Dim ActualSet As DataSet
        Dim DataAdapter As OdbcDataAdapter
        Dim Command As OdbcCommand
        Dim Reader As OdbcDataReader
        Dim strSQL As String = ""
        Dim FormValidation As String = ""
        Dim intLoop As Integer = 0
        Dim strParameter As String = ""
        Dim strWeightage As String = ""
        Dim kraTable As Table
        Dim kraRow As TableRow
        Dim kraCell As TableCell

        Connection.Open()
        If EditKRA = True Then
            strSQL = "Select tran_keydeter as KeyItem, tran_actual as Actual from tb_temp_storerating where tran_empid='" & EmpID & "'"
        Else
            strSQL = "Select Key_Deter as KeyItem, actual as Actual from tb_tran_actuals where act_month='" & Month & "' and act_year='" & Year & "' and empid='" & EmpID & "'"
        End If
        DataAdapter = New OdbcDataAdapter(strSQL, Connection)
        DataAdapter.Fill(ActualSet)

        strSQL = "select parameter, weight, key_deter, Weightage, Goal, role_model from tb_mast_service where role_month='" & Month & "' and role_year= '" & Year & "' and Title='" & TitleID & "' and project='" & ProjectID & "'"
        Command = New OdbcCommand(strSQL, Connection)
        Reader = Command.ExecuteReader()

        While Reader.Read()
            intLoop = intLoop + 1

            If intLoop = 1 Then
                kraTable = New Table
                kraRow = New TableRow
                AddTableCell(kraRow, "Parameter", , , 50)
                AddTableCell(kraRow, "Param Weightage", , , 50)
                AddTableCell(kraRow, "Key Determinant", , , 250)
                AddTableCell(kraRow, "Weightage", , , 50)
                AddTableCell(kraRow, "Goal", , , 50)
                AddTableCell(kraRow, "Actual", , , 50)
                AddTableCell(kraRow, , , , 50)
                kraRow.CssClass = "kravaluesweightlabel"
                kraTable.Rows.Add(kraRow)
            End If

            kraRow = New TableRow

            kraCell = New TableCell
            kraCell.Text = ""
            If strParameter <> Reader.GetString(0) Then
                strParameter = Reader.GetString(0)
                Dim txtParameter As New Label
                kraCell.Controls.Add(txtParameter)
                txtParameter.CssClass = "paraminput"
                txtParameter.ID = "param" & intLoop
                txtParameter.Text = Reader.GetString(0)
            End If
            kraRow.Cells.Add(kraCell)

            kraCell = New TableCell
            kraCell.Text = ""
            If strWeightage <> Reader.GetString(0) Then
                strWeightage = Reader.GetString(0)
                kraCell.Text = Reader.GetString(1) & "%"
            End If
            kraRow.Cells.Add(kraCell)

            AddTableCell(kraRow, Reader.GetString(2))
            AddTableCell(kraRow, Reader.GetString(3) & "%")

            kraCell = New TableCell
            Dim txtKeyDeterGoal As New Label
            kraCell.Controls.Add(txtKeyDeterGoal)
            txtKeyDeterGoal.ID = "goal" & intLoop
            txtKeyDeterGoal.CssClass = "weightinput"

            If (Reader.GetString(4).LastIndexOf(":") >= 0) Then
                txtKeyDeterGoal.Text = Reader.GetString(4)
            Else
                If (Reader.GetString(4) < 1 And Reader.GetString(4) <> 0) Then
                    txtKeyDeterGoal.Text = Reader.GetString(4) * 100 & "%"
                ElseIf (Reader.GetString(4) = 100) And (Reader.GetString(5) <= 1) Then
                    txtKeyDeterGoal.Text = Reader.GetString(4) & "%"
                Else
                    txtKeyDeterGoal.Text = Reader.GetString(4)
                End If
            End If
            kraRow.Cells.Add(kraCell)

            kraCell = New TableCell
            Dim txtKeyDeterActual As New TextBox
            kraCell.Controls.Add(txtKeyDeterActual)
            txtKeyDeterActual.ID = "actual" & intLoop
            txtKeyDeterActual.CssClass = "activetxtbox"
            txtKeyDeterActual.Style.Add("width", "80px")
            If UBound(Actuals) > 0 Then
                txtKeyDeterActual.Text = Actuals(intLoop - 1)
            End If
            kraRow.Cells.Add(kraCell)

            kraCell = New TableCell
            Dim reg_time As New RegularExpressionValidator
            reg_time.ControlToValidate = "actual" & intLoop
            FormValidation = FormValidation & "frmvalidator.addValidation('actual" & intLoop & "','req','Please fill all the fields');" & vbCrLf

            If (Reader.GetString(4).LastIndexOf(":") >= 0) Then
                'formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','regexp=^(\d{1,2}):(\d{2}):(\d{2})$','Please enter valid time format');" & vbCrLf
                reg_time.ValidationExpression = "(\d)?\d:\d\d:\d\d"
                reg_time.Text = "Improper time format"
                kraCell.Controls.Add(reg_time)
                reg_time.ID = "RegularExpressionValidator" & intLoop
            Else
                If ((Reader.GetString(4) < 1 And Reader.GetString(4) <> 0) Or (Reader.GetString(4) = 100 And Reader.GetString(5) <= 1)) Then
                    'formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','regexp=^(\d{1,3})(\%)?$','Invalid entry');" & vbCrLf
                    reg_time.ValidationExpression = "[\d\d]\d(%)?"
                    reg_time.Text = "Use goal format"
                    kraCell.Controls.Add(reg_time)
                    reg_time.ID = "RegularExpressionValidator" & intLoop
                Else
                    'formvalidation = formvalidation & "frmvalidator.addValidation('actual" & intLoop & "','regexp=^(\d)+(\.)?(\d{0,3})$','Invalid entry');" & vbCrLf
                    txtKeyDeterGoal.Text = Reader.GetString(4)
                    reg_time.ValidationExpression = "[0-9,:,.]+"
                    reg_time.Text = "Invalid entry. Pls avoid spl chars"
                    kraCell.Controls.Add(reg_time)
                    reg_time.ID = "RegularExpressionValidator" & intLoop
                End If
            End If
            kraRow.Cells.Add(kraCell)

            kraRow.CssClass = "weightinput"
            kraTable.Rows.Add(kraRow)

        End While
        Reader.Close()
        kraTable.CellPadding = 2
        kraTable.CellSpacing = 2
        'kraTable.BorderWidth = Unit.Pixel(1)
        kraTable.Width = Unit.Percentage(100)
        'kraTable.HorizontalAlign = HorizontalAlign.Left
        Container.Controls.Add(kraTable)
        'PopulateParamActual = intLoop
        PopulateParamActual = intLoop & "|" & FormValidation
    End Function
    Public Function ActualValueValidation(ByVal strFieldName As String, ByVal strTablename As String, Optional ByVal strCondition As String = "") As String()
        Dim Connection1 As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Connection1.Open()
        Dim strSQL As String = "select " & strFieldName & " from " & strTablename & " where " & strCondition
        Dim kraCommand1 As New OdbcCommand(strSQL, Connection1)
        Dim kraReader1 As OdbcDataReader = kraCommand1.ExecuteReader(CommandBehavior.CloseConnection)
        Dim strActual() As String
        Dim i As Integer = 0
        ReDim strActual(100)
        While kraReader1.Read()
            strActual(i) = kraReader1(0)
            i = i + 1
        End While
        kraReader1.Close()
        ActualValueValidation = strActual
    End Function


End Module
