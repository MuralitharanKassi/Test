var tmenuItems = [

    ["+General","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Home","javascript:loadPage('home.aspx')", "", "", "", "Home Page", "", "", "", "", ],
    ["Transaction","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Actual Score Template","javascript:loadPage('Kra_builder_templat.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Actual Score Upload","javascript:loadPage('Kra_actual_upload.aspx')", "", "", "", "", "", "", "", "", ],
    ["Reports","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|My KRA Score","javascript:loadPage('krareportdisplay.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Final Rating","javascript:loadPage('rpt_hrscore.aspx')", "", "", "", "", "", "", "", "", ],
];

dtree_init();