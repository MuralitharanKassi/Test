var tmenuItems = [

    ["+General","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Home","javascript:loadPage('home.aspx')", "", "", "", "Home Page", "", "", "", "", ],
    ["Transaction","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Actual Score Template","javascript:loadPage('Kra_builder_templat.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Actual Score Upload","javascript:loadPage('Kra_actual_upload.aspx')", "", "", "", "", "", "", "", "", ],
    ["Reports","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|My KRA Score","javascript:loadPage('krareportdisplay.aspx')", "", "", "", "", "", "", "", "", ],
        ["|KRA Report","javascript:loadPage('krareport.aspx')", "", "", "", "", "", "", "", "", ],
        //["|Final Rating","javascript:loadPage('rpt_hrscore.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Completion Status","javascript:loadPage('kracompletionreport.aspx')", "", "", "", "", "", "", "", "", ],
        //["|Rating Distribution","javascript:loadPage('kradistributionreport.aspx')", "", "", "", "", "", "", "", "", ],
];

dtree_init();