Imports MySql.Data.MySqlClient
Imports System.Data.OleDb
Imports System.Text
Imports System.IO

Partial Class kraupdate
    Inherits System.Web.UI.Page
    Dim ApplicationPath As String
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim oleConnection As OleDbConnection
    Dim oleCommand As OleDbCommand
    Dim oleReader As OleDbDataReader
    Dim strSQL As String
    Dim dsTitle As DataSet
    Dim dsProject As DataSet
    Dim dsParameter As DataSet
    Dim dsStatus As DataSet
    Dim dsKRASheet As DataSet
    Dim DataAdapter As MySqlDataAdapter
    Dim dataRow() As DataRow
    Dim SaveFolder As String = "files"
    Dim EmpSaveFile As String = "KRA_Data.xls"
    Dim EmpErrorFile As String = "KRA_Data_Error.csv"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblMonth As System.Web.UI.WebControls.Label
    Protected WithEvents comboMonth As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtYear As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        lblError.Text = ""
        lblStatus.Text = ""
        btnUpload.Enabled = False
        Try
            ApplicationPath = Server.MapPath(SaveFolder)
            'lnkUploadEmployee.Attributes.Add("onclick", "return confirm('This will delete the Employee Database.\nYou cannot revert back this.\nAre you sure you want to proceed?');")
            If Not IsPostBack Then
                lnkEmpTemplate.HRef = SaveFolder & "/KRA_Data_Template.xls"
                'lnkEmpError.HRef = SaveFolder & "/" & EmpErrorFile
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Error Occured", Connection, Session("CurUserRole"))
        End Try
    End Sub

    Private Sub btnEmployee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
        UploadEmployeeData()
        'lnkErrorEmployee.Visible = False
    End Sub

    Private Sub UploadEmployeeData()
        Dim Month As String = ""
        Dim Year As String = ""
        Dim EmpID As String = ""
        Dim Flag As String = ""
        Dim objQuery As New Support.QuerySet
        Dim objSupport As New Support.Common
        Dim objCrypto As New Support.Crypto
        Dim ProjectID As String = ""
        Dim TitleID As String = ""
        Dim StatusID As String = ""
        'Dim NestingDate As String = ""
        'Dim curupdated As Integer
        'Dim curinserted As Integer
        'Dim gloupdated As Integer
        'Dim gloinserted As Integer
        Dim curProject As String = ""
        Dim curTitle As String = ""
        Dim curStatus As String = ""
        Dim curMonth As String = ""
        Dim curYear As String = ""
        Dim curKRA As String = ""
        Dim Actual As String = ""
        Dim KRA_Fin_Res(5) As String
        Dim KRA_Cus_Man(8) As String
        Dim KRA_Peo_Exc(3) As String
        Dim KRA_Pro_Exc(10) As String
        Dim count As Integer = 0
        Dim Rating As Double
        Dim Score As Double
        Dim ParamList As String = ""

        Try
            oleConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & EmpSaveFile & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
            Connection.Open()
            Command = New MySqlCommand("select * from tb_master_project", Connection)
            dsProject = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsProject)
            Command = New MySqlCommand("select * from tb_master_title", Connection)
            dsTitle = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsTitle)
            Command = New MySqlCommand("select * from tb_mast_empstatus", Connection)
            dsStatus = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsStatus)

            oleConnection.Open()
            strSQL = "select * from [KRA_Data$] order by Project, Title, Month, Year"
            oleCommand = New OleDbCommand(strSQL, oleConnection)
            oleReader = oleCommand.ExecuteReader()
            While (oleReader.Read())
                Month = oleReader(0)
                Year = oleReader(1)
                EmpID = oleReader(2)
                If curProject <> oleReader("Project").Trim Then
                    dataRow = dsProject.Tables(0).Select("PROJ_NAME='" & oleReader("Project").Trim & "'")
                    If dataRow.Length > 0 Then ProjectID = dataRow(0).Item(0)
                End If
                If curTitle <> oleReader("Title").Trim Then
                    dataRow = dsTitle.Tables(0).Select("TITL_NAME='" & oleReader("Title").Trim & "'")
                    If dataRow.Length > 0 Then TitleID = dataRow(0).Item(0)
                End If
                If curStatus <> oleReader("Status").Trim Then
                    dataRow = dsStatus.Tables(0).Select("empstat_name='" & oleReader("Status").Trim & "'")
                    If dataRow.Length > 0 Then StatusID = dataRow(0).Item(0)
                End If
                If TitleID = "" Then TitleID = 0
                If StatusID = "" Then StatusID = 0
                Flag = objQuery.SelectAValue(Connection, "count(*)", "tb_mast_employee", "M_EMPL_ID_PK='" & EmpID & "'")
                If Flag = "0" Then
                    objQuery.InsertValue(Connection, "tb_mast_employee", "M_EMPL_ID_PK,M_EMPL_NAME", "'" & EmpID & "', '" & objSupport.FormatData(oleReader("Name")) & "'")
                End If
                Flag = objQuery.SelectAValue(Connection, "count(*)", "tb_tran_employee", "M_EMPL_ID_PK='" & EmpID & "' and M_EMPL_MONTH='" & Month & "' and M_EMPL_YEAR='" & Year & "'")
                If Flag = "0" Then
                    objQuery.InsertValue(Connection, "tb_tran_employee", "M_EMPL_ID_PK,M_EMPL_PROJECT,M_EMPL_TITLE,M_APPRAISER_ID,M_EMPL_MODE,M_EMPL_MONTH,M_EMPL_YEAR", "'" & EmpID & "', '" & ProjectID & "', '" & TitleID & "', '" & oleReader("Appraiser ID") & "', '" & StatusID & "', '" & Month & "', '" & Year & "'")
                End If

                If curProject <> ProjectID Or curTitle <> TitleID Or curMonth <> Month Or curYear <> Year Then
                    Command = New MySqlCommand("SELECT project AS 'Project',Title AS 'Title',Parameter AS 'KRA',weight AS 'KRA_Weight',Key_Deter AS 'KPI',Weightage AS 'KPI_Weight',Goal,Does_not_meet AS 'PL1',Meets_Expectation AS 'PL2',Exceeds_Expectation AS 'PL3',Role_Model AS 'PL4',PL5,CONVERT(CONCAT(opr1,'|',opr2,'|',opr3,'|',opr4,'|',opr5) USING utf8) AS 'Opr',role_month AS 'Month',role_year AS 'Year' FROM tb_mast_service WHERE project='" & ProjectID & "' AND Title='" & TitleID & "' AND role_month='" & Month & "' AND role_year='" & Year & "'", Connection)
                    dsKRASheet = New DataSet
                    DataAdapter = New MySqlDataAdapter(Command)
                    DataAdapter.Fill(dsKRASheet)
                End If
                For count = 8 To 12
                    KRA_Fin_Res(count - 8) = oleReader(count)
                Next
                For count = 13 To 20
                    KRA_Cus_Man(count - 13) = oleReader(count)
                Next
                For count = 21 To 23
                    KRA_Peo_Exc(count - 21) = oleReader(count)
                Next
                For count = 24 To 33
                    KRA_Pro_Exc(count - 24) = oleReader(count)
                Next
                count = -1
                For Each row As DataRow In dsKRASheet.Tables(0).Rows
                    If curKRA <> row(2) Then
                        count = -1
                        ParamList &= row(2) & ","
                    End If
                    count += 1
                    If row(2) = "Financial Results" Then
                        Actual = KRA_Fin_Res(count)
                    ElseIf row(2) = "Customer Management" Then
                        Actual = KRA_Cus_Man(count)
                    ElseIf row(2) = "People Excellence" Then
                        Actual = KRA_Peo_Exc(count)
                    ElseIf row(2) = "Process Excellence" Then
                        Actual = KRA_Pro_Exc(count)
                    End If
                    curKRA = row(2)
                    Rating = KeyRating(Actual, row(6), row(12), row(7) & "|" & row(8) & "|" & row(9) & "|" & row(10) & "|" & row(11))
                    Score = (Rating * CInt(Replace(row(5), "%", ""))) / 100
                    strSQL = "insert into tb_tran_storerating( " & _
                                 "tran_empid " & _
                                 ",tran_proj " & _
                                 ",tran_title " & _
                                 ",tran_param " & _
                                 ",tran_weightage " & _
                                 ",tran_keydeter " & _
                                 ",tran_weight " & _
                                 ",tran_goal " & _
                                 ",tran_opt " & _
                                 ",tran_doesnotmeet " & _
                                 ",tran_meetexpectation " & _
                                 ",tran_exceeds " & _
                                 ",tran_rolemodel " & _
                                 ",tran_PL5 " & _
                                 ",tran_actual " & _
                                 ",tran_emprating " & _
                                 ",tran_empscore " & _
                                 ",tran_apprating " & _
                                 ",tran_appscore " & _
                                 ",tran_revrating " & _
                                 ",tran_revscore " & _
                                 ",tran_month " & _
                                 ",tran_year " & _
                                 ",tran_appid " & _
                                 ",tran_apptime " & _
                                 ",tran_revid " & _
                                 ",tran_revtime " & _
                                 ",tran_signofftime " & _
                                 ",tran_alt_appid " & _
                                 ",tran_alt_revid " & _
                                 ",tran_alt_signoff " & _
                                 ") values( " & _
                                 "'" & oleReader(2) & "' " & _
                                 ",'" & ProjectID & "' " & _
                                 ",'" & TitleID & "' " & _
                                 ",'" & row(2) & "' " & _
                                 ",'" & row(3) & "' " & _
                                 ",'" & row(4) & "' " & _
                                 ",'" & row(5) & "' " & _
                                 ",'" & row(6) & "' " & _
                                 ",'" & row(12) & "' " & _
                                 ",'" & row(7) & "' " & _
                                 ",'" & row(8) & "' " & _
                                 ",'" & row(9) & "' " & _
                                 ",'" & row(10) & "' " & _
                                 ",'" & row(11) & "' " & _
                                 ",'" & Actual & "' " & _
                                 ",'" & Rating & "' " & _
                                 ",'" & Score & "' " & _
                                 ",'" & Rating & "' " & _
                                 ",'" & Score & "' " & _
                                 ",'" & Rating & "' " & _
                                 ",'" & Score & "' " & _
                                 ",'" & oleReader(0) & "' " & _
                                 ",'" & oleReader(1) & "' " & _
                                 ",'" & oleReader(4) & "' " & _
                                 ",Now() " & _
                                 ",'0' " & _
                                 ",Now() " & _
                                 ",Now() " & _
                                 ",'0' " & _
                                 ",'0' " & _
                                 ",'0')"
                    Command = New MySqlCommand(strSQL, Connection)
                    Command.ExecuteNonQuery()
                Next

                strSQL = "insert into tb_tran_empfeedback (" & _
                                "M_FEEDBACK_EMPID, " & _
                                "M_FEEDBACK_REL_EMP, " & _
                                "M_FEEDBACK_REL_SUP, " & _
                                "M_FEEDBACK_COMP, " & _
                                "M_FEEDBACK_IDENT_TECH, " & _
                                "M_FEEDBACK_IDENT_CERT, " & _
                                "M_FEEDBACK_IDENT_SKILL, " & _
                                "M_FEEDBACK_MONTH, " & _
                                "M_FEEDBACK_YEAR, " & _
                                "M_FEEDBACK_APPCOMM, " & _
                                "M_FEEDBACK_REVCOMM, " & _
                                "M_FEEDBACK_EMPCOMM " & _
                                ") values(" & _
                                "'" & oleReader(2) & "', " & _
                                "'NA', " & _
                                "'NA', " & _
                                "'NA', " & _
                                "'NA', " & _
                                "'NA', " & _
                                "'NA', " & _
                                "'" & oleReader(0) & "', " & _
                                "'" & oleReader(1) & "', " & _
                                "'NA', " & _
                                "'NA', " & _
                                "'NA')"
                Command = New MySqlCommand(strSQL, Connection)
                Command.ExecuteNonQuery()

                Dim Parameter() As String
                Parameter = Split(ParamList, ",")
                For count = 0 To Parameter.Length - 2
                    If Parameter(count) <> "" Then
                        strSQL = "insert into tb_tran_paramfeedback (" & _
                                "M_PFEEDBACK_EMPID, " & _
                                "M_PFEEDBACK_PARAM," & _
                                "M_PFEEDBACK_COMMENT," & _
                                "M_PFEEDBACK_MONTH," & _
                                "M_PFEEDBACK_YEAR" & _
                                ") values(" & _
                                "'" & oleReader(2) & "', " & _
                                "'" & Parameter(count) & "', " & _
                                "'NA', " & _
                                "'" & oleReader(0) & "', " & _
                                "'" & oleReader(1) & "')"
                        Command = New MySqlCommand(strSQL, Connection)
                        Command.ExecuteNonQuery()
                    End If
                Next
               
                curProject = oleReader("Project").Trim
                curTitle = oleReader("Title").Trim
                curStatus = oleReader("Status").Trim
                curMonth = Month
                curYear = Year
                lblStatus.Text = EmpID
            End While
            objCrypto = Nothing
            objSupport = Nothing
            objQuery = Nothing
            oleConnection.Dispose()
            Connection.Close()
            UpdateEmployeeEmail()
            lblStatus.Text = "DB Transfer done successfully. " ' & curinserted & " records added and " & curupdated & " records updated for selected month. " & gloinserted & " new records added."
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload terminated: Error while uploading data", Connection, Session("CurUserRole"))
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Private Sub UpdateEmployeeEmail()
        Dim objQuery As New Support.QuerySet
        Dim dsEmail As New DataSet
        Dim cdmConnection As New MySqlConnection(ConfigurationManager.ConnectionStrings("cdm_connection").ConnectionString.ToString())
        cdmConnection.Open()
        Command = New MySqlCommand("SELECT Emp_Code, Office_Email FROM tbl_cdm_emp_mas where Office_Email<>'' and emp_path<>''", cdmConnection)
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsEmail)

        Dim dsUser As New DataSet
        If Connection.State = ConnectionState.Closed Then Connection.Open()
        Command = New MySqlCommand("SELECT M_EMPL_ID_PK, M_EMPL_EMAILID FROM tb_mast_employee", cdmConnection)
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsUser)

        For Each userRow As DataRow In dsUser.Tables(0).Rows
            For Each emailRow As DataRow In dsEmail.Tables(0).Rows
                If userRow.Item(0) = emailRow.Item(0) Then
                    If emailRow.Item(1) <> "" Then
                        objQuery.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_EMAILID='" & emailRow.Item(1) & "'", "M_EMPL_ID_PK='" & emailRow.Item(0) & "'")
                    End If
                    Exit For
                End If
            Next
        Next
        Connection.Close()
    End Sub

    Private Sub btnCopyEmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopy.Click
        Try
            'lnkErrorEmployee.Visible = False
            If Not File1.PostedFile Is Nothing And File1.PostedFile.ContentLength > 0 Then
                Dim fn As String = System.IO.Path.GetFileName(File1.PostedFile.FileName)
                If Right(fn, 3) <> "xls" Then
                    lblStatus.Text = "Please select a valid file to upload"
                    lblStatus.Visible = True
                    Exit Sub
                End If
                Dim SaveLocation As String = ApplicationPath & "\" & EmpSaveFile & ""
                If File.Exists(SaveLocation) Then File.Delete(SaveLocation)
                File1.PostedFile.SaveAs(SaveLocation)
                CheckEmployeeSheet()
            Else
                lblStatus.Text = "Please select a file to upload."
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Connectivity error occured", , Session("CurUserRole"))
        End Try
    End Sub

    Private Sub CheckEmployeeSheet()
        Dim oleConnection As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & EmpSaveFile & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
        Dim oleCommand As OleDbCommand
        Dim oleReader As OleDbDataReader
        Dim colCount As Integer = 34
        Dim ErrorMessage As String = ""
        Try
            Connection.Open()
            Command = New MySqlCommand("select * from tb_master_project", Connection)
            dsProject = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsProject)

            Command = New MySqlCommand("select * from tb_master_title", Connection)
            dsTitle = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsTitle)

            Command = New MySqlCommand("select * from tb_mast_empstatus", Connection)
            dsStatus = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsStatus)
            Connection.Close()
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload Terminated! This may be due to Problem in server connectivity. Please contact your administrator.", Connection, Session("CurUserRole"))
            'lnkErrorEmployee.Visible = False
            Exit Sub
        End Try

        Try
            'ErrorFileName = ApplicationPath & "\" & EmpErrorFile
            'If File.Exists(ErrorFileName) Then File.Delete(ErrorFileName)
            oleConnection.Open()
            strSQL = "select count(*) from [KRA_Data$] where Month='' or Year='' or [Emp ID]='' or Name='' or ]Appraiser ID]='' or Project='' or Title='' or Status=''"
            oleCommand = New OleDbCommand(strSQL, oleConnection)
            oleReader = oleCommand.ExecuteReader()
            If oleReader(0) <> "0" Then
                ErrorMessage = "Some of the critical data missing. Kindly check the upload sheet"
            End If
            oleReader.Close()
            If ErrorMessage = "" Then
                strSQL = "select distinct Project from [KRA_Data$]"
                oleCommand = New OleDbCommand(strSQL, oleConnection)
                oleReader = oleCommand.ExecuteReader()
                While (oleReader.Read())
                    dataRow = dsProject.Tables(0).Select("PROJ_NAME='" & oleReader("Project") & "'")
                    If dataRow.Length = 0 Then ErrorMessage = "Invalid project found"
                    Exit While
                End While
                oleReader.Close()
            End If
            If ErrorMessage = "" Then
                strSQL = "select distinct Title from [KRA_Data$]"
                oleCommand = New OleDbCommand(strSQL, oleConnection)
                oleReader = oleCommand.ExecuteReader()
                While (oleReader.Read())
                    dataRow = dsTitle.Tables(0).Select("TITL_NAME='" & oleReader("Title") & "'")
                    If dataRow.Length = 0 Then ErrorMessage &= "Invalid title found"
                    Exit While
                End While
                oleReader.Close()
            End If
            If ErrorMessage = "" Then
                strSQL = "select distinct Status from [KRA_Data$]"
                oleCommand = New OleDbCommand(strSQL, oleConnection)
                oleReader = oleCommand.ExecuteReader()
                While (oleReader.Read())
                    dataRow = dsStatus.Tables(0).Select("empstat_name='" & oleReader("Status") & "'")
                    If dataRow.Length = 0 Then ErrorMessage &= "Invalid employee status found"
                    Exit While
                End While
                oleReader.Close()
            End If
            oleConnection.Close()
            If ErrorMessage = "" Then
                lblStatus.Text = "File ready to upload"
                btnCopy.Enabled = False
                btnUpload.Enabled = True
            Else
                lblError.Text = ErrorMessage
            End If
        Catch ex As Exception
            lblError.Text = "Upload Terminated! Please check the upload sheet. Make sure the sheet name is 'KRA_Data'"
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            If Connection.State = ConnectionState.Open Then Connection.Close()
            Exit Sub
        End Try
    End Sub

End Class
