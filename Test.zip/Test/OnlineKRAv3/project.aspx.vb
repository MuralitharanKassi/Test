Imports MySql.Data.MySqlClient

Partial Class project_add
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As New MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Bindgrid()
        End If
    End Sub

    Private Sub dgProject_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgProject.ItemCommand
        lblError.Text = ""
        lblStatus.Text = ""
        Select e.CommandName
            Case "doAdd"
                Try
                    Dim projectbox As TextBox
                    Dim projectname As String
                    projectbox = CType(e.Item.FindControl("txtProject"), TextBox)
                    projectname = projectbox.Text.Trim()
                    If projectname <> "" Then
                        Dim objQuery As New Support.QuerySet
                        Dim result As String
                        Connection.Open()
                        result = objQuery.SelectAValue(Connection, "PROJ_NAME", "tb_master_project", "PROJ_NAME='" & projectname & "'")
                        If LCase(result) <> LCase(projectname) Then
                            strSQL = "insert into tb_master_project(PROJ_NAME) values('" & projectname & "')"
                            Command = New MySqlCommand(strSQL, Connection)
                            Command.ExecuteNonQuery()
                            projectbox.Text = ""
                            lblStatus.Text = "Successfully Added"
                        Else
                            lblError.Text = "Cannot add project. Name already exists"
                        End If
                        Connection.Close()
                        objQuery = Nothing
                    Else
                        lblError.Text = "Project name cannot be empty"
                    End If
                Catch ex As Exception
                    If Connection.State = ConnectionState.Open Then Connection.Close()
                    lblError.Text = ex.Message
                End Try
            Case "doEdit"
                dgProject.EditItemIndex = CInt(e.Item.ItemIndex)
                dgProject.ShowFooter = False
            Case "doUpdate"
                Try
                    Connection.Open()
                    Dim projectbox As TextBox
                    Dim projectname As String
                    projectbox = CType(e.Item.FindControl("txtProject"), TextBox)
                    projectname = projectbox.Text.Trim()
                    If projectname <> "" Then
                        Dim objQuery As New Support.QuerySet
                        Dim result As String
                        result = objQuery.SelectAValue(Connection, "PROJ_NAME", "tb_master_project", "PROJ_NAME='" & projectname & "'")
                        If LCase(result) <> LCase(projectname) Then
                            Dim strSQL As String = "update tb_master_project set PROJ_NAME='" & projectname & "' where PROJ_ID_PK='" & e.Item.Cells(0).Text.Trim & "'"
                            Command = New MySqlCommand(strSQL, Connection)
                            Reader = Command.ExecuteReader(CommandBehavior.CloseConnection)
                            lblStatus.Text = "Successfully Modified"
                            dgProject.EditItemIndex = -1
                            dgProject.ShowFooter = True
                        Else
                            lblError.Text = "Cannot update project. Name already exists"
                        End If
                        objQuery = Nothing
                    Else
                        lblError.Text = "Project name cannot be empty"
                    End If
                    Connection.Close()
                Catch ex As Exception
                    If Connection.State = ConnectionState.Open Then Connection.Close()
                    lblError.Text = ex.Message
                End Try
            Case "doCancel"
                dgProject.EditItemIndex = -1
                dgProject.ShowFooter = True
        End Select
        Bindgrid()
    End Sub

    Private Sub dgProject_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgProject.PageIndexChanged
        dgProject.CurrentPageIndex = e.NewPageIndex
        Bindgrid()
    End Sub

    Private Sub Bindgrid()
        Try
            Dim myDataset As New DataSet
            Connection.Open()
            Dim myData As New MySqlDataAdapter("SELECT PROJ_ID_PK as ProjectID, PROJ_NAME as Project from tb_master_project ORDER BY PROJ_NAME", Connection)
            myData.Fill(myDataset)
            dgProject.DataSource = myDataset.Tables(0).DefaultView
            dgProject.DataBind()
            Connection.Close()
        Catch ex2 As Exception
            lblError.Text = ex2.Message
        End Try
    End Sub

    'add dgProject_DeleteCommand by suresh p
    'Private Sub dgProject_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgProject.DeleteCommand
    '    Try
    '        Connection.Open()
    '        'Dim txtPrjName As TextBox = e.Item.Cells(0).Controls(0)
    '        Dim txtPrjName As String = e.Item.Cells(0).Text
    '        'row_id = e.Item.Cells[0].Text
    '        If txtPrjName <> "" Then
    '            Dim objQuery As New Support.QuerySet
    '            Dim result As String
    '            result = objQuery.SelectAValue(Connection, "PROJ_NAME", "tb_master_project", "PROJ_NAME='" & Trim(txtPrjName) & "' and PROJ_ID_PK<>'" & e.Item.Cells(2).Text & "'")
    '            If LCase(result) <> LCase(txtPrjName) Then
    '                Dim strSQL As String = "delete from  tb_master_project where PROJ_ID_PK='" & e.Item.Cells(2).Text & "'"
    '                Command = New MySqlCommand(strSQL, Connection)
    '                Reader = Command.ExecuteReader(CommandBehavior.CloseConnection)
    '                lblstatus.Text = "Successfully Removed"
    '                lblstatus.Visible = True
    '                lblerr.Visible = False
    '            Else
    '                lblerr.Text = "Cannot Removed project"
    '                lblerr.Visible = True
    '                lblstatus.Visible = False
    '            End If
    '        Else
    '            lblerr.Visible = True
    '            lblerr.Text = "Project name cannot be empty"
    '        End If
    '        'close connection by suresh p
    '        Connection.Close()
    '    Catch ex2 As Exception
    '        lblerr.Text = ex2.Message
    '    End Try
    '    dgProject.EditItemIndex = -1
    '    'pnladd.Visible = True
    '    Bindgrid()
    'End Sub

End Class
