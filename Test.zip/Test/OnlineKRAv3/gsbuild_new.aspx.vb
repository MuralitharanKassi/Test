Imports System.Data.Odbc
Imports System.CodeDom.Compiler
Imports Microsoft.VisualBasic 'More than just VB6 Runtime functions in here!
Imports System.Reflection

Partial Class gsbuild_new
    Inherits System.Web.UI.Page
    Dim Connection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ddl_editopr1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddl_editopr4 As System.Web.UI.WebControls.DropDownList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Dim qrySelect As New clsGeneral
        lbl_errmsg.Visible = False
        txt_division.Visible = False
        txt_project.Visible = False
        txt_title.Visible = False
        txt_month.Visible = False
        txt_year.Visible = False
        If Not IsPostBack Then
            Connection.Open()
            lbl_division.Text = Request("ddl_division")
            txt_division.Text = Request("ddl_division")
            lbl_project.Text = SelectAValue(Connection, "PROJ_NAME", "tb_master_project", "PROJ_ID_PK='" & Request("ddl_project") & "'")
            txt_project.Text = Request("ddl_project")
            lbl_title.Text = SelectAValue(Connection, "TITL_NAME", "tb_master_title", "TITL_ID_PK='" & Request("ddl_title") & "'")
            txt_title.Text = Request("ddl_title")
            lbl_month.Text = MonthName(Request("ddl_month"))
            txt_month.Text = Request("ddl_month")
            lbl_year.Text = Request("ddl_year")
            txt_year.Text = Request("ddl_year")
            Connection.Close()
        End If
        pnl_infodisplay.Visible = True
        pnl_paramentry.Visible = True
        txt_keydetn_weight.Attributes.Add("onchange", "checkWeightage(this)")
        ResetForm()
        FillParameter()
        BindGrid()
    End Sub

    Private Sub FillParameter()
        Dim strSQl As String
        strSQl = "SELECT " & _
                    "distinct Parameter " & _
                 "FROM " & _
                    "tb_mast_service " & _
                 "WHERE " & _
                    "Parameter NOT IN (" & _
                        "SELECT " & _
                            "distinct Parameter " & _
                        "FROM " & _
                            "tb_temp_service " & _
                        "WHERE " & _
                            "project='" & txt_project.Text & "' and " & _
                            "Title='" & txt_title.Text & "' and " & _
                            "role_month='" & txt_month.Text & "' and " & _
                            "role_year='" & txt_year.Text & "')"

        Dim kraconn_param As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        kraconn_param.Open()
        Dim kraRS_param As OdbcDataReader
        Dim kracmd_param As New OdbcCommand(strSQl, kraconn_param)
        kracmd_param.Connection = kraconn_param
        kraRS_param = kracmd_param.ExecuteReader()
        ddl_parameter.Items.Clear()
        While (kraRS_param.Read())
            ddl_parameter.Items.Add(New ListItem(kraRS_param(0), kraRS_param(0)))
        End While
        kraRS_param.Close()
    End Sub

    Private Sub ResetForm()
        ddl_parameter.Items.Clear()
        txt_param_weight.Text = "0"
        txt_keydetn.Text = ""
        txt_keydetn_weight.Text = "0"
        txt_goal.Text = ""
        ddl_oprtype.SelectedValue = ""
        txt_perf1.Text = ""
        txt_perf2.Text = ""
        txt_perf3.Text = ""
        txt_perf4.Text = ""
    End Sub

    Private Sub btn_add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_add.Click
        Dim parameter, opr1, opr2, opr3, opr4, keydetn, keydetn_weight, param_weight, goal, perf1, perf2, perf3, perf4 As String
        Dim flag As Boolean
        Dim i, dup As Integer
        Dim strSQL As String
        Dim oprtype As String()
        Dim kraconn_project As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        kraconn_project.Open()

        Try
            parameter = Request.Form("ddl_parameter")
            param_weight = Request.Form("txt_param_weight")
            keydetn = Request.Form("txt_keydetn")
            keydetn_weight = Request.Form("txt_keydetn_weight")
            goal = Request.Form("txt_goal")
            If InStr(Request.Form("ddl_oprtype"), ",") > 0 Then
                oprtype = Request.Form("ddl_oprtype").Split(",")
                opr1 = oprtype(0)
                opr2 = oprtype(1)
                opr3 = oprtype(2)
                opr4 = oprtype(3)
            End If
            perf1 = Request.Form("txt_perf1")
            perf2 = Request.Form("txt_perf2")
            perf3 = Request.Form("txt_perf3")
            perf4 = Request.Form("txt_perf4")
            If keydetn <> "" Then flag = True
            i = 0
            While flag
                flag = False
                strSQL = "INSERT INTO tb_temp_service( " & _
                                "Division, " & _
                                "project, " & _
                                "Title, " & _
                                "Key_Deter, " & _
                                "weight, " & _
                                "Parameter, " & _
                                "Weightage, " & _
                                "Goal, " & _
                                "opr1, " & _
                                "Does_not_meet, " & _
                                "opr2, " & _
                                "Meets_Expectation, " & _
                                "opr3, " & _
                                "Exceeds_Expectation, " & _
                                "opr4, " & _
                                "Role_Model, " & _
                                "role_month, " & _
                                "role_year " & _
                         ") VALUES(" & _
                                "'" & txt_division.Text & "'," & _
                                "'" & txt_project.Text & "'," & _
                                "'" & txt_title.Text & "'," & _
                                "'" & keydetn.Replace("'", "/'") & "'," & _
                                "'" & keydetn_weight & "'," & _
                                "'" & parameter & "'," & _
                                "'" & param_weight & "'," & _
                                "'" & FormatGoalData(goal, "G") & "'," & _
                                "'" & opr1 & "'," & _
                                "'" & FormatGoalData(perf1) & "'," & _
                                "'" & opr2 & "'," & _
                                "'" & FormatGoalData(perf2) & "'," & _
                                "'" & opr3 & "'," & _
                                "'" & FormatGoalData(perf3) & "'," & _
                                "'" & opr4 & "'," & _
                                "'" & FormatGoalData(perf4) & "'," & _
                                "'" & txt_month.Text & "'," & _
                                "'" & txt_year.Text & "'" & _
                                ")"

                Dim kraRS_project As OdbcDataReader
                Dim kracmd_project As New OdbcCommand(strSQL, kraconn_project)
                kracmd_project.Connection = kraconn_project
                kraRS_project = kracmd_project.ExecuteReader()

                i = i + 1
                keydetn = Request.Form("txt_keydetn-" & i)
                keydetn_weight = Request.Form("txt_keydetn_weight-" & i)
                goal = Request.Form("txt_goal-" & i)
                If InStr(Request.Form("ddl_oprtype-" & i), ",") > 0 Then
                    oprtype = Request.Form("ddl_oprtype-" & i).Split(",")
                    opr1 = oprtype(0)
                    opr2 = oprtype(1)
                    opr3 = oprtype(2)
                    opr4 = oprtype(3)
                End If
                perf1 = Request.Form("txt_perf1-" & i)
                perf2 = Request.Form("txt_perf2-" & i)
                perf3 = Request.Form("txt_perf3-" & i)
                perf4 = Request.Form("txt_perf4-" & i)
                Try
                    If keydetn <> "" Then
                        flag = True
                    End If
                Catch Ex As Exception
                    lbl_errmsg.Text = Ex.Message
                    'Response.Write("Error:" & Ex.Message)
                    kraconn_project.Close()
                    Exit Sub
                End Try
                kraRS_project.Close()
            End While
            kraconn_project.Close()
        Catch ex1 As Exception
            lbl_errmsg.Text = ex1.Message
            Response.Write("Error:" & ex1.Message)
            kraconn_project.Close()
            Exit Sub
        End Try
        BindGrid()
        FillParameter()
    End Sub

    Private Function FormatGoalData(ByVal strData As String, Optional ByVal strPerf As String = "") As String
        Dim intLen As Integer
        intLen = Len(strData)

        If (strData.IndexOf("%", 0, Len(strData)) > 0) Then
            If (UCase(strPerf) = "G") Then
                If (CDbl(strData.Substring(0, intLen - 1)) / 100) = 1 Then
                    FormatGoalData = "100"
                Else
                    FormatGoalData = CStr(CDbl(strData.Substring(0, intLen - 1)) / 100)
                End If
            Else
                FormatGoalData = CStr(CDbl(strData.Substring(0, intLen - 1)) / 100)
            End If
        Else
            FormatGoalData = strData
        End If
    End Function

    Private Sub BindGrid()
        Dim myDataset As New DataSet
        Dim conn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Dim conn2 As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        conn.Open()
        conn2.Open()
        Dim strSQL As String
        Try
            strSQL = "SELECT " & _
                         "count(distinct Parameter) " & _
                     "FROM " & _
                        "tb_temp_service " & _
                     "WHERE " & _
                        "project='" & txt_project.Text & "' and " & _
                        "Title='" & txt_title.Text & "' and " & _
                        "role_month='" & txt_month.Text & "' and " & _
                        "role_year='" & txt_year.Text & "'"
            Dim kraRS As OdbcDataReader
            Dim kracmd As New OdbcCommand(strSQL, conn)
            kracmd.Connection = conn
            kraRS = kracmd.ExecuteReader()
            'Response.Write(strSQL)
            kraRS.Read()
            If kraRS(0) <> "0" Then
                strSQL = "SELECT " & _
                             "distinct Parameter as Parameter, " & _
                             "Weightage as Param_weight, " & _
                             "Key_Deter as Key_Detn, " & _
                             "weight as Keydetn_weight " & _
                         "FROM " & _
                             "tb_temp_service " & _
                         "WHERE " & _
                             "project='" & txt_project.Text & "' and " & _
                             "Title='" & txt_title.Text & "' and " & _
                             "role_month='" & txt_month.Text & "' and " & _
                             "role_year='" & txt_year.Text & "'"
                'Response.Write(strSQL)
                Dim myData As New OdbcDataAdapter(strSQL, conn2)
                myData.Fill(myDataset)
                Grid_Param.DataSource = myDataset.Tables(0).DefaultView
                Grid_Param.DataBind()
                Grid_Param.Visible = True
                'btn_savegoal.Visible = True
                lnk_confirm.Visible = True
            Else
                Grid_Param.Visible = False
                'btn_savegoal.Visible = False
                lnk_confirm.Visible = False
            End If
            kraRS.Close()
            conn.Close()
            conn2.Close()
        Catch Ex As Exception
            lbl_errmsg.Text = Ex.Message
            Response.Write(Ex.Message)
            conn.Close()
            conn2.Close()
        End Try
    End Sub

    Private Sub BindGoalSheet()
        Dim myDataset As New DataSet
        Dim conn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        conn.Open()
        Dim strSQL As String
        Try
            strSQL = "SELECT " & _
                             "role_id_pk as ID, Parameter, Weightage, Key_Deter, weight, " & _
                             "case when Does_not_meet < 1 then CONCAT(Goal*100,'%') else Goal end as goal, " & _
                             "CONCAT(case opr1 when 1 then '<' when 2 then '>' when 3 then '>=' when 4 then '<=' when 5 then '<>' end,',', " & _
                             "case opr2 when 1 then '<' when 2 then '>' when 3 then '>=' when 4 then '<=' when 5 then '<>' end,',', " & _
                             "case opr3 when 1 then '<' when 2 then '>' when 3 then '>=' when 4 then '<=' when 5 then '<>' end,',', " & _
                             "case opr4 when 1 then '<' when 2 then '>' when 3 then '>=' when 4 then '<=' when 5 then '<>' end) as opr, " & _
                             "case when Does_not_meet < 1 then CONCAT(Does_not_meet*100,'%') else Does_not_meet end as perf1, " & _
                             "case when Does_not_meet < 1 then CONCAT(Meets_Expectation*100,'%') else Meets_Expectation end as perf2, " & _
                             "case when Does_not_meet < 1 then CONCAT(Exceeds_Expectation*100,'%') else Exceeds_Expectation end as perf3, " & _
                             "case when Does_not_meet < 1 then CONCAT(Role_Model*100,'%') else Role_Model end as perf4 " & _
                         "FROM " & _
                             "tb_temp_service " & _
                         "WHERE " & _
                             "project='" & txt_project.Text & "' and " & _
                             "Title='" & txt_title.Text & "' and " & _
                             "role_month='" & txt_month.Text & "' and " & _
                             "role_year='" & txt_year.Text & "'"
            'Response.Write(strSQL)
            Dim myData As New OdbcDataAdapter(strSQL, conn)
            myData.Fill(myDataset)
            Goalsheet.DataSource = myDataset.Tables(0).DefaultView
            Goalsheet.DataBind()
            conn.Close()
        Catch Ex As Exception
            Response.Write(Ex.Message)
            lbl_errmsg.Text = Ex.Message
            conn.Close()
        End Try
    End Sub

    Private Sub Grid_Param_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Grid_Param.EditCommand
        Grid_Param.EditItemIndex = CInt(e.Item.ItemIndex)
        BindGrid()
    End Sub

    Private Sub Grid_Param_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Grid_Param.CancelCommand
        Grid_Param.EditItemIndex = -1
        BindGrid()
    End Sub

    Private Sub Goalsheet_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Goalsheet.EditCommand
        Goalsheet.EditItemIndex = CInt(e.Item.ItemIndex)
        BindGoalSheet()
    End Sub

    Private Sub Goalsheet_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Goalsheet.CancelCommand
        Goalsheet.EditItemIndex = -1
        BindGoalSheet()
    End Sub

    Private Sub lnk_confirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnk_confirm.Click
        txt_flag.Text = "edit"
        pnl_infodisplay.Visible = True
        Grid_Param.Visible = False
        Goalsheet.Visible = True
        pnl_paramentry.Visible = False
        lnk_confirm.Visible = False
        lnk_back.Visible = True
        btn_savegoal.Visible = True
        BindGoalSheet()
    End Sub

    Private Sub Goalsheet_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Goalsheet.UpdateCommand
        Try
            Dim goal, perf1, perf2, perf3, perf4 As TextBox
            Dim oprtype As DropDownList
            Dim strSQL As String = ""
            Dim opr As String()

            goal = e.Item.Cells(4).FindControl("goal")
            perf1 = e.Item.Cells(6).FindControl("perf1")
            perf2 = e.Item.Cells(7).FindControl("perf2")
            perf3 = e.Item.Cells(8).FindControl("perf3")
            perf4 = e.Item.Cells(9).FindControl("perf4")
            oprtype = e.Item.Cells(5).FindControl("ddl_opr")

            If goal.Text = "" Or perf1.Text = "" Or perf2.Text = "" Or perf3.Text = "" Or perf4.Text = "" Or oprtype.SelectedValue = "" Then
                lbl_errmsg.Text = "Please fill all the fields"
                lbl_errmsg.Visible = True
            Else
                opr = oprtype.SelectedValue.Split(",")
                Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
                strSQL = "UPDATE " & _
                             "tb_temp_service " & _
                         "SET " & _
                             "Goal='" & FormatGoalData(goal.Text) & "', " & _
                             "opr1='" & opr(0) & "', " & _
                             "Does_not_meet='" & FormatGoalData(perf1.Text) & "', " & _
                             "opr2='" & opr(1) & "', " & _
                             "Meets_Expectation='" & FormatGoalData(perf2.Text) & "', " & _
                             "opr3='" & opr(2) & "', " & _
                             "Exceeds_Expectation='" & FormatGoalData(perf3.Text) & "', " & _
                             "opr4='" & opr(3) & "', " & _
                             "Role_Model='" & FormatGoalData(perf4.Text) & "' " & _
                         "WHERE " & _
                             "role_id_pk='" & e.Item.Cells(11).Text & "'"

                Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
                kraConnection.Open()
                kraCommand.ExecuteNonQuery()
                kraConnection.Close()
                Goalsheet.EditItemIndex = -1
                BindGoalSheet()
            End If
        Catch ex As Exception
            lbl_errmsg.Text = ex.Message
        End Try
    End Sub

    Private Sub btn_savegoal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_savegoal.Click
        Dim strSQL As String
        Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        strSQL = "INSERT INTO " & _
                    "tb_mast_service(" & _
                    "Division, " & _
                    "project, " & _
                    "Title, " & _
                    "Key_Deter, " & _
                    "weight, " & _
                    "Parameter, " & _
                    "Weightage, " & _
                    "Goal, " & _
                    "opr1, " & _
                    "Does_not_meet, " & _
                    "opr2, " & _
                    "Meets_Expectation, " & _
                    "opr3, " & _
                    "Exceeds_Expectation, " & _
                    "opr4, " & _
                    "Role_Model, " & _
                    "role_month, " & _
                    "role_year) " & _
                 "SELECT " & _
                    "Division, " & _
                    "project, " & _
                    "Title, " & _
                    "Key_Deter, " & _
                    "weight, " & _
                    "Parameter, " & _
                    "Weightage, " & _
                    "Goal, " & _
                    "opr1, " & _
                    "Does_not_meet, " & _
                    "opr2, " & _
                    "Meets_Expectation, " & _
                    "opr3, " & _
                    "Exceeds_Expectation, " & _
                    "opr4, " & _
                    "Role_Model, " & _
                    "role_month, " & _
                    "role_year " & _
                 "FROM " & _
                    "tb_temp_service " & _
                 "WHERE " & _
                    "project='" & txt_project.Text & "' and " & _
                    "Title='" & txt_title.Text & "' and " & _
                    "role_month='" & txt_month.Text & "' and " & _
                    "role_year='" & txt_year.Text & "' " & _
                 "ORDER BY Parameter"
        Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
        kraConnection.Open()
        kraCommand.ExecuteNonQuery()
        kraConnection.Close()
        Goalsheet.Visible = False

        strSQL = "DELETE " & _
                 "FROM " & _
                    "tb_temp_service " & _
                 "WHERE " & _
                    "project='" & txt_project.Text & "' and " & _
                    "Title='" & txt_title.Text & "' and " & _
                    "role_month='" & txt_month.Text & "' and " & _
                    "role_year='" & txt_year.Text & "'"
        Dim kraCommand2 As New OdbcCommand(strSQL, kraConnection)
        kraConnection.Open()
        kraCommand2.ExecuteNonQuery()
        kraConnection.Close()
        btn_savegoal.Visible = False
        lbl_errmsg.Text = "KRA Goalsheet Saved Sucessfully"
        lbl_errmsg.Visible = True


    End Sub

    Private Sub lnk_back_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnk_back.Click
        txt_flag.Text = ""
        pnl_infodisplay.Visible = True
        Grid_Param.Visible = True
        Goalsheet.Visible = False
        pnl_paramentry.Visible = True
        lnk_confirm.Visible = True
        lnk_back.Visible = False
        btn_savegoal.Visible = False
    End Sub
    Sub insertData(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
        If e.CommandName = "Insert" Then
            Dim ddl_parameter, ddl_oprtype As DropDownList
            Dim txt_weightage, txt_keydetn, txt_weight, txt_goal, txt_perf1, txt_perf2, txt_perf3, txt_perf4 As TextBox

            Dim parameter, opr1, opr2, opr3, opr4, keydetn, keydetn_weight, param_weight, goal, perf1, perf2, perf3, perf4 As String
            Dim i, dup As Integer
            Dim strSQL As String
            Dim oprtype As String()
            Dim kraconn_project As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            kraconn_project.Open()
            Try
                ddl_parameter = e.Item.FindControl("add_parameter")
                parameter = ddl_parameter.SelectedValue
                txt_weightage = e.Item.FindControl("add_weightage")
                param_weight = txt_weightage.Text
                txt_keydetn = e.Item.FindControl("add_key_deter")
                keydetn = txt_keydetn.Text
                txt_weight = e.Item.FindControl("add_weight")
                keydetn_weight = txt_weight.Text
                txt_goal = e.Item.FindControl("add_goal")
                goal = txt_goal.Text
                ddl_oprtype = e.Item.FindControl("add_opr")
                If InStr(ddl_oprtype.SelectedValue, ",") > 0 Then
                    oprtype = ddl_oprtype.SelectedValue.Split(",")
                    opr1 = oprtype(0)
                    opr2 = oprtype(1)
                    opr3 = oprtype(2)
                    opr4 = oprtype(3)
                End If
                txt_perf1 = e.Item.FindControl("add_perf1")
                perf1 = txt_perf1.Text
                txt_perf2 = e.Item.FindControl("add_perf2")
                perf2 = txt_perf2.Text
                txt_perf3 = e.Item.FindControl("add_perf3")
                perf3 = txt_perf3.Text
                txt_perf4 = e.Item.FindControl("add_perf4")
                perf4 = txt_perf4.Text
                strSQL = "INSERT INTO tb_temp_service( " & _
                                "Division, " & _
                                "project, " & _
                                "Title, " & _
                                "Key_Deter, " & _
                                "weight, " & _
                                "Parameter, " & _
                                "Weightage, " & _
                                "Goal, " & _
                                "opr1, " & _
                                "Does_not_meet, " & _
                                "opr2, " & _
                                "Meets_Expectation, " & _
                                "opr3, " & _
                                "Exceeds_Expectation, " & _
                                "opr4, " & _
                                "Role_Model, " & _
                                "role_month, " & _
                                "role_year " & _
                         ") VALUES(" & _
                                "'" & txt_division.Text & "'," & _
                                "'" & txt_project.Text & "'," & _
                                "'" & txt_title.Text & "'," & _
                                "'" & keydetn.Replace("'", "/'") & "'," & _
                                "'" & keydetn_weight & "'," & _
                                "'" & parameter & "'," & _
                                "'" & param_weight & "'," & _
                                "'" & FormatGoalData(goal, "G") & "'," & _
                                "'" & opr1 & "'," & _
                                "'" & FormatGoalData(perf1) & "'," & _
                                "'" & opr2 & "'," & _
                                "'" & FormatGoalData(perf2) & "'," & _
                                "'" & opr3 & "'," & _
                                "'" & FormatGoalData(perf3) & "'," & _
                                "'" & opr4 & "'," & _
                                "'" & FormatGoalData(perf4) & "'," & _
                                "'" & txt_month.Text & "'," & _
                                "'" & txt_year.Text & "'" & _
                                ")"

                Dim kraRS_project As OdbcDataReader
                Dim kracmd_project As New OdbcCommand(strSQL, kraconn_project)
                kracmd_project.Connection = kraconn_project
                kraRS_project = kracmd_project.ExecuteReader()
                kraRS_project.Close()
                kraconn_project.Close()
            Catch ex1 As Exception
                lbl_errmsg.Text = ex1.Message
                'Response.Write("Error:" & ex1.Message)
                kraconn_project.Close()
                Exit Sub
            End Try
            BindGrid()
            FillParameter()
        End If
    End Sub

    Private Sub Goalsheet_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles Goalsheet.ItemDataBound
        Dim kraconn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Dim kraRS As OdbcDataReader
        Dim kracmd As New OdbcCommand
        Dim param As DropDownList
        If e.Item.ItemType = ListItemType.Footer Then
            kraconn.Open()
            kracmd.CommandText = "SELECT distinct Parameter FROM tb_mast_service "
            kracmd.Connection = kraconn
            kraRS = kracmd.ExecuteReader()
            param = e.Item.Cells(0).FindControl("add_parameter")
            While (kraRS.Read())
                param.Items.Add(kraRS(0))
            End While
            kraRS.Close()
            kraconn.Close()
        End If
    End Sub

    Private Sub Goalsheet_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Goalsheet.DeleteCommand
        Try
            Dim strSQL As String = ""
            Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            strSQL = "DELETE FROM " & _
                         "tb_temp_service " & _
                     "WHERE " & _
                         "role_id_pk='" & e.Item.Cells(11).Text & "'"

            Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
            kraConnection.Open()
            kraCommand.ExecuteNonQuery()
            kraConnection.Close()
            Goalsheet.EditItemIndex = -1
            BindGoalSheet()
        Catch ex As Exception
            lbl_errmsg.Text = ex.Message
        End Try
    End Sub
End Class
