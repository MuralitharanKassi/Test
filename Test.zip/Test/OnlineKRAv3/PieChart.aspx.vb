Imports System.Data.Odbc
Imports System.Drawing
Imports System.Drawing.Imaging

Partial Class PieChart
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim status As String
        Dim statusnot As String
        Dim kraconn_project As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        kraconn_project.Open()
        Dim kraRS_project As OdbcDataReader
        Dim kracmd_project As New OdbcCommand("select (count(distinct tran_empid)/(select count(distinct M_EMPL_ID_PK) from tb_tran_storerating,tb_mast_employee where M_APPRAISER_ID='" & Session.Item("userempno") & "'))*100 from tb_mast_employee,tb_tran_storerating where M_APPRAISER_ID='" & Session.Item("userempno") & "' and M_EMPL_ID_PK=tran_empid and tran_month='" & Session("Month") & "' and tran_year='" & Session("year") & "'", kraconn_project)
        kracmd_project.Connection = kraconn_project
        kraRS_project = kracmd_project.ExecuteReader()
        While (kraRS_project.Read())
            If kraRS_project(0) Is DBNull.Value Then
                status = 0
            Else
                status = kraRS_project(0)
            End If
        End While
        Dim i As Integer
        Dim bm As New Bitmap(500, 200)
        Dim g As Graphics
        g = Graphics.FromImage(bm)

        'set canvas color
        g.Clear(Color.Snow)

        'display graph title
        g.DrawString("Your Team Status", New Font("Tahoma", 16), Brushes.Black, New PointF(5, 5))

        Dim yaxis(1) As Integer
        If status = "null" Or status = "" Then
            yaxis(0) = 0
            yaxis(1) = 100
        Else
            statusnot = 100 - status
            yaxis(0) = status
            yaxis(1) = statusnot
        End If


        Dim xaxis(1) As String
        xaxis(0) = "Completed - " & Math.Round(CInt(yaxis(0)), 0) & "%"
        xaxis(1) = "Not Completed - " & Math.Round(CInt(yaxis(1)), 0) & "%"
      
        'display graph legends
        Dim symbolLeg As PointF = New PointF(335, 20)
        Dim descLeg As PointF = New PointF(360, 16)
        For i = 0 To xaxis.Length - 1
            g.FillRectangle(New SolidBrush(GetColor(i)), symbolLeg.X, symbolLeg.Y, 20, 10)
            g.DrawRectangle(Pens.Black, symbolLeg.X, symbolLeg.Y, 20, 10)
            g.DrawString(xaxis(i).ToString, New Font("Arial", 10), Brushes.Black, descLeg)
            symbolLeg.Y += 15
            descLeg.Y += 15
        Next i

        Dim totalAng As Integer
        Dim currentangle As Single = 0
        Dim startangle As Single = 0

        For i = 0 To yaxis.Length - 1
            totalAng = totalAng + yaxis(i)
        Next
        For i = 0 To yaxis.Length - 1
            currentangle = yaxis(i) / totalAng * 360
            g.FillPie(New SolidBrush(GetColor(i)), 100, 40, 150, 150, startangle, currentangle)
            g.DrawPie(Pens.Black, 100, 40, 150, 150, startangle, currentangle)
            startangle += currentangle
        Next i
        Dim p As New Pen(Color.Black, 2)
        g.DrawRectangle(p, 1, 1, 498, 198)

        bm.Save(Response.OutputStream, ImageFormat.Jpeg)

    End Sub

    Private Function GetColor(ByVal itemIndex As Integer) As Color
        Dim objColor As Color
        Select Case itemIndex
            Case 0
                objColor = Color.Green
            Case 1
                objColor = Color.Red
            Case Else
                objColor = Color.Blue
        End Select
        Return objColor
    End Function
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class
