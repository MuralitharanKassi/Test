Imports MySql.Data.MySqlClient

Partial Class kraemployeemaster
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    'Dim Reader As MySqlDataReader
    'Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblStatus.Text = ""
        lblError.Text = ""
        If Not IsPostBack Then
            If Request.QueryString("status") = "updated" Then
                lblStatus.Text = "Updated Successfully"
            End If
            Try
                Dim objControl As New Support.DataControl
                Connection.Open()
                objControl.FillDropDown(Connection, ddlProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                objControl.FillDropDown(Connection, ddlTitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                objControl.FillDropDown(Connection, ddlStatus, "tb_mast_empstatus", "empstat_name", "empstat_id")
                objControl.FillDropDown(Connection, ddlRole, "tb_mast_role", "role_name", "role_id")
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlMonth, Session("Month"), Session("Year"))
                ddlMonth.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
                Connection.Close()
                objControl = Nothing
            Catch ex3 As Exception
                lblError.Text = ex3.Message
            End Try
        End If
    End Sub

    Private Sub Search()
        Try
            Dim objSupport As New Support.Common
            Dim myDataset As New DataSet
            Connection.Open()
            strSQL = "select EmpID, Name as EmpName, Project, Title, AppraiserID, Appraiser, Status, Month, Year from userinfo where "
            If ddlMonth.SelectedValue = "0" Then
                strSQL = strSQL & " Month = (select max(Month) from userinfo) and Year = (select max(Year) from userinfo)"
            Else
                strSQL = strSQL & " Month = '" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and Year = '" & objSupport.GetYear(ddlMonth.SelectedValue) & "'"
            End If
            If txtEmpID.Text <> "" Then strSQL = strSQL & " and EmpID like '" & txtEmpID.Text & "%'"
            If txtEmpName.Text <> "" Then strSQL = strSQL & " and Name like '" & txtEmpName.Text & "%'"
            If ddlProject.SelectedItem.Value <> "0" Then strSQL = strSQL & " and ProjectID = '" & ddlProject.SelectedItem.Value & "'"
            If ddlTitle.SelectedItem.Value <> "0" Then strSQL = strSQL & " and TitleID = '" & ddlTitle.SelectedItem.Value & "'"
            If txtAppraiser.Text <> "" Then strSQL = strSQL & " and AppraiserID = '" & txtAppraiser.Text & "'"
            If ddlStatus.SelectedItem.Value <> "0" Then strSQL = strSQL & " and StatusID = '" & ddlStatus.SelectedItem.Value & "'"
            If ddlRole.SelectedItem.Value <> "0" Then strSQL = strSQL & " and Role like '%" & ddlRole.SelectedItem.Value & "%'"
            'If Session("UserCurRole") = "Administrator" Then Response.Write(strSQL)
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            grdEmployee.DataSource = myDataset.Tables(0).DefaultView
            grdEmployee.DataBind()
            Connection.Close()
            objSupport = Nothing
            lnkExport.Visible = True
            Datagrid1.Visible = True
            Datagrid1.DataSource = myDataset.Tables(0).DefaultView
            Datagrid1.DataBind()
            Datagrid1.Visible = False
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        grdEmployee.CurrentPageIndex = 0
        Search()
    End Sub

    Private Sub grdEmployee_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdEmployee.PageIndexChanged
        grdEmployee.CurrentPageIndex = e.NewPageIndex
        Search()
    End Sub

    'Private Sub Export()
    '    Try
    '        grdExport.Visible = True
    '        Response.Clear()
    '        Response.AddHeader("content-disposition", "attachment;filename=KRA_Employee_List.xls")
    '        Response.Charset = ""
    '        Response.Cache.SetCacheability(HttpCacheability.NoCache)
    '        Response.ContentType = "application/vnd.xls"
    '        Dim stringWrite As New System.IO.StringWriter
    '        Dim htmlWrite As New System.Web.UI.HtmlTextWriter(stringWrite)
    '        'Dim htmlWrite As New HtmlTextWriter(stringWrite)
    '        grdExport.RenderControl(htmlWrite)
    '        Response.Write(stringWrite.ToString())
    '        Response.End()
    '        grdExport.Visible = False
    '    Catch ex3 As Exception
    '        Label7.Text = ex3.Message
    '    End Try
    'End Sub

    Private Sub lnkExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkExport.Click
        grdEmployee.AllowPaging = False
        Datagrid1.Visible = True
        KRAClass.ExportDataGrid(Datagrid1, "KRA_Employee_List.xls")
        ' Call ExportExcel()
        grdEmployee.AllowPaging = True
        Datagrid1.Visible = False
        'Export()
    End Sub


    Private Sub ExportExcel()
        grdEmployee.AllowSorting = "False"
        grdEmployee.DataBind()
        grdEmployee.AllowSorting = "False"
        grdEmployee.DataBind()
        Response.ContentType = "application/vnd.ms-excel"
        Response.Charset = ""
        Me.EnableViewState = False
        Dim tw As New System.IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Dim frm As HtmlForm = New HtmlForm()
        Me.Controls.Add(frm)
        frm.Controls.Add(grdEmployee)
        frm.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
        grdEmployee.AllowSorting = "False"
        grdEmployee.DataBind()
        With HttpContext.Current.Response
            .Clear()
            .AddHeader("content-disposition", "attachment;filename=" & "KRA_Employee_List.xls")
            .Charset = ""
            .Cache.SetCacheability(HttpCacheability.NoCache)
            .ContentType = "application/vnd.xls"
            Dim stringWrite As New System.IO.StringWriter
            Dim htmlWrite As New System.Web.UI.HtmlTextWriter(stringWrite)
            grdEmployee.RenderControl(htmlWrite)
            .Write(stringWrite.ToString())
            .End()
        End With
    End Sub

End Class
