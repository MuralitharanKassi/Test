Imports MySql.Data.MySqlClient
Imports System.Text

Partial Class krahome
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String
    Dim fromdate, todate As Integer
    Dim Completed, PendingAppraiser, PendingReviewer, PendingSignoff, NotCompleted, Total As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents pnl As System.Web.UI.WebControls.Panel

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblError.Text = ""
        Try
            'If Session("DefaultPassword") = "1" Then
            '    Response.Redirect("krachangepass.aspx")
            'End If
            If Session("UserCurRole") = "Administrator" Then
                Response.Redirect("krahome_2.aspx", True)
            Else
                myperf.InnerHtml = PerformanceChart()
                If Session("UserCurRole") <> "User" Then
                    projperf.InnerHtml = RatingChart()
                    allcomp.InnerHtml = CompletionChart(0, "allcomp")
                    projcomp.InnerHtml = CompletionChart(Session("UserProjectID"), "projcomp")
                End If
            End If
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Public Function PerformanceChart(Optional ByVal Project As String = "") As String
        Try
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            Dim totalScore As Double = 0
            Dim selMonth As Integer = Session("Month")
            Dim selYear As Integer = Session("Year")
            If selMonth > 6 Then
                selMonth = selMonth - 5
            Else
                selMonth = selMonth + 6
                selYear = selYear - 1
            End If
            Dim xmlData As String
            Dim count As Integer = 0
            Dim score As Double

            xmlData = "<chart palette='1' bgColor='FFFFFF,EEEEEE' yAxisMinValue='0' yAxisMaxValue='4' formatNumberScale='0' placeValuesInside='1' xAxisName='Month' yAxisName='Rating' labelDisplay='Rotate' slantLabels='1' bgSWFAlpha='0' legendAllowDrag='1' showlegend='0' legendPosition='RIGHT' shownames='1' showvalues='1' showSum='1' decimals='1' formatNumberScale='0'>"
            If Project = "" Then
                strSQL = "call ConsolidatedFinalScore(" & Session("UserID") & "," & selMonth & "," & selYear & ")"
            Else
                strSQL = "call ConsolidatedFinalScore(" & Session("UserID") & "," & selMonth & "," & selYear & ")"
            End If
            Command = New MySqlCommand
            Command.CommandText = strSQL
            Command.Connection = Connection
            Reader = Command.ExecuteReader()
            While Reader.Read()
                If count < 6 Then
                    If Not IsDBNull(Reader("FinalScore")) Then
                        If LCase(Reader("KRAStatus")) = "completed" Then
                            score = Reader("FinalScore")
                            If score < 1 Then score = 1
                            xmlData = xmlData & "<set label='" & MonthName(Reader("month"), True) & "-" & Mid(Reader("year"), 3, 2) & "' value='" & score & "' />"
                        Else
                            score = 0
                            'xmlData = xmlData & "<set label='" & MonthName(reader("month"), True) & "-" & Mid(reader("year"), 3, 2) & "' value='" & reader("KRAStatus") & "' />"
                        End If
                        'xmlData = xmlData & "<set label='" & MonthName(reader("month"), True) & "-" & Mid(reader("year"), 3, 2) & "' value='" & score & "' />"
                        totalScore = totalScore + score
                        count = count + 1
                    End If
                End If
            End While
            Reader.Close()
            xmlData = xmlData & "</chart>"
            Return FusionCharts.RenderChart("Charts/Bar2D.swf", "", xmlData, "myperf", "360", "190", False, False)
            Connection.Close()
        Catch ex As Exception
            Connection.Close()
            lblError.Text = "Error Occured (Ref:02)"
            Return ""
        End Try
    End Function
    Public Function RatingChart() As String
        Try
            ProjectPerformanceReport()
            Dim GridItem As DataGridItem
            Dim xmlData As String
            xmlData = "<chart palette='3' bgColor='FFFFFF,EEEEEE' xAxisName='Rating' yAxisName='Count' rotateLabels='1' slantLabels='1' shownames='1' showvalues='0' maxColWidth='32' showSum='1' overlapColumns='1' legendPosition='BOTTOM' formatNumberScale='0'>"
            'xmlData = xmlData & "<categories>"
            'For Each GridItem In grdProjectPerformance.Items
            '    If GridItem.Cells(0).Text <> "<b>Overall</b>" And GridItem.Cells(0).Text <> "&nbsp;" Then
            '        xmlData = xmlData & "<category label='" & GridItem.Cells(0).Text & "' />"
            '    End If
            'Next
            'xmlData = xmlData & "</categories>"
            Dim title As String
            For i As Integer = 1 To 5
                If i = 5 Then
                    title = "Not Done"
                Else
                    title = "PL" & i
                End If
                'xmlData = xmlData & "<dataset seriesName='" & title & "'>"
                For Each GridItem In grdProjectPerformance.Items
                    If GridItem.Cells(0).Text <> "<b>Overall</b>" And GridItem.Cells(0).Text <> "&nbsp;" Then
                        'xmlData = xmlData & "<set value='" & GridItem.Cells(2 * i - 1).Text & "' toolText='" & title & "," & GridItem.Cells(2 * i - 1).Text & "(" & Replace(GridItem.Cells(2 * i).Text, "%", "%25") & ")" & "' />"
                        xmlData = xmlData & "<set label='" & title & "' value='" & GridItem.Cells(2 * i - 1).Text & "' toolText='" & title & "," & GridItem.Cells(2 * i - 1).Text & "(" & Replace(GridItem.Cells(2 * i).Text, "%", "%25") & ")" & "' />"
                    End If
                Next
                'xmlData = xmlData & "</dataset>"
            Next
            xmlData = xmlData & "</chart>"
            Return FusionCharts.RenderChart("Charts/Bar2D.swf", "", xmlData, "divrating", "360", "190", False, False)
        Catch ex As Exception
            lblError.Text = "Error Occured (Ref:03)"
            Return ""
        End Try
    End Function
    Private Sub ProjectPerformanceReport()
        Dim myDataset As New DataSet

        Dim totalRows, totalColumns As Integer
        Dim encoding As New ASCIIEncoding
        'Dim encoding As New UTF8Encoding
        Try
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            fromdate = 100 * Session("Year") + Session("Month")
            'todate = 100 * Session("Year") + Session("Month")
            strSQL = "call RatingDistribution(" & Session("UserProjectID") & ",0," & fromdate & "," & fromdate & ")"
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            totalRows = myDataset.Tables(0).Rows.Count
            totalColumns = myDataset.Tables(0).Columns.Count
            Dim Rating(12, totalColumns - 2) As String
            Dim rowCounter As Integer
            Dim colCounter As Integer
            For rowCounter = 0 To 12
                For colCounter = 0 To totalColumns - 2
                    Rating(rowCounter, colCounter) = "0"
                Next
            Next
            Dim rowValue As Integer
            For rowCounter = 0 To totalRows - 1
                rowValue = rowCounter

                If rowValue <> 0 Then
                    If myDataset.Tables(0).Rows(rowCounter).Item(0).GetType().ToString().Equals("System.Byte[]") Then
                        rowValue = 2 * CInt(encoding.GetString(myDataset.Tables(0).Rows(rowCounter).Item(0))) - 1
                    Else
                        rowValue = 2 * CInt(myDataset.Tables(0).Rows(rowCounter).Item(0)) - 1
                    End If

                End If
                For colCounter = 1 To totalColumns - 1
                    If myDataset.Tables(0).Rows(rowCounter).Item(colCounter).GetType().ToString().Equals("System.Byte[]") Then
                        Rating(rowValue, colCounter - 1) = encoding.GetString(myDataset.Tables(0).Rows(rowCounter).Item(colCounter))
                    Else
                        Rating(rowValue, colCounter - 1) = myDataset.Tables(0).Rows(rowCounter).Item(colCounter).ToString()
                    End If
                Next
            Next
            Dim objControl As New Support.DataControl
            grdProjectPerformance.DataSource = New Mommo.Data.ArrayDataView(objControl.TransposeArray(Rating))
            grdProjectPerformance.DataBind()
            objControl = Nothing
            Dim GridItem As DataGridItem
            Dim strMonth As String
            Dim i As Integer
            For Each GridItem In grdProjectPerformance.Items
                strMonth = GridItem.Cells(0).Text
                'Added to hide the percentage columns
                GridItem.Cells(2).Visible = False
                GridItem.Cells(4).Visible = False
                GridItem.Cells(6).Visible = False
                GridItem.Cells(8).Visible = False
                GridItem.Cells(10).Visible = False
                GridItem.Cells(12).Visible = False
                If strMonth <> "Overall" And strMonth <> "&nbsp;" Then GridItem.Cells(0).Text = MonthName(Mid(strMonth, 5, 2), True) & "-" & Mid(strMonth, 3, 2)
                If GridItem.Cells(11).Text <> "&nbsp;" Then GridItem.Cells(9).Text = CInt(GridItem.Cells(11).Text) - (CInt(GridItem.Cells(1).Text) + CInt(GridItem.Cells(3).Text) + CInt(GridItem.Cells(5).Text) + CInt(GridItem.Cells(7).Text))
                For i = 1 To 11 Step 2
                    If GridItem.Cells(i).Text <> "&nbsp;" Then
                        If GridItem.Cells(i).Text = "0" Or GridItem.Cells(11).Text = "0" Then
                            GridItem.Cells(i + 1).Text = "0%"
                        Else
                            GridItem.Cells(i + 1).Text = CStr(Math.Round(100 * (CInt(GridItem.Cells(i).Text) / CInt(GridItem.Cells(11).Text)))) & "%"
                        End If
                    End If
                Next
            Next
            For Each GridItem In grdProjectPerformance.Items
                strMonth = GridItem.Cells(0).Text
                If strMonth = "Overall" Then
                    For i = 0 To 12
                        GridItem.Cells(i).Text = "<b>" & GridItem.Cells(i).Text & "</b>"
                        'Added to hide the Overall row
                        GridItem.Cells(i).Visible = False
                    Next
                End If
            Next
            Connection.Close()
            'LinkButton1.Visible = True
        Catch ex As Exception
            lblError.Text = "Error Occured (Ref:04)"
        End Try
        'pnlChart.Visible = True
    End Sub
    Public Function CompletionChart(ByVal Project As Integer, ByVal target As String) As String
        Try
            Dim myDataset As New DataSet
            'connection.Open()
            Dim selMonth As Integer = Session("Month")
            Dim selYear As Integer = Session("Year")
            Dim xmlData As String
            Dim count As Integer = 0
            'Dim score As Double
            strSQL = "call KRACompletionCount(" & selMonth & "," & selYear & ")"
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            grdReport.DataSource = myDataset.Tables(0).DefaultView
            grdReport.DataBind()
            xmlData = "<chart palette='1' bgColor='FFFFFF,EEEEEE' bgSWFAlpha='0' startingAngle='130' shownames='1' showvalues='1' formatNumberScale='0' showZeroPies='1' showPercentValues='0' showPercentInToolTip='1' pieSliceDepth='10' pieRadius='70'>"
            Dim GridItem As DataGridItem
            If Project = 0 Then
                xmlData = xmlData & "<set label='Completed' value='" & Completed & "' isSliced='1' />"
                xmlData = xmlData & "<set label='Pending with Appraiser' value='" & PendingAppraiser & "' />"
                xmlData = xmlData & "<set label='Pending with Reviewer' value='" & PendingReviewer & "' />"
                xmlData = xmlData & "<set label='Signoff Pending' value='" & PendingSignoff & "' />"
            Else
                For Each GridItem In grdReport.Items
                    If GridItem.Cells(0).Text = Session("UserProjectName") Then
                        xmlData = xmlData & "<set label='Completed' value='" & GridItem.Cells(2).Text & "' isSliced='1' />"
                        xmlData = xmlData & "<set label='Pending with Appraiser' value='" & GridItem.Cells(3).Text & "' />"
                        xmlData = xmlData & "<set label='Pending with Reviewer' value='" & GridItem.Cells(4).Text & "' />"
                        xmlData = xmlData & "<set label='Signoff Pending' value='" & GridItem.Cells(5).Text & "' />"
                    End If
                Next
            End If
            xmlData = xmlData & "</chart>"
            Return FusionCharts.RenderChart("Charts/Pie3D.swf", "", xmlData, target, "360", "190", False, False)
            'connection.Close()
        Catch ex As Exception
            lblError.Text = "Error Occured (Ref:05)"
            Return ""
        End Try
    End Function

    Private Sub grdReport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdReport.ItemDataBound
        If e.Item.ItemType = ListItemType.Header Then
            Completed = 0
            PendingAppraiser = 0
            PendingReviewer = 0
            PendingSignoff = 0
            NotCompleted = 0
            Total = 0
        ElseIf e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Completed = Completed + CInt(e.Item.Cells(2).Text)
            PendingAppraiser = PendingAppraiser + CInt(e.Item.Cells(3).Text)
            PendingReviewer = PendingReviewer + CInt(e.Item.Cells(4).Text)
            PendingSignoff = PendingSignoff + CInt(e.Item.Cells(5).Text)
            NotCompleted = NotCompleted + CInt(e.Item.Cells(6).Text)
            Total = Total + CInt(e.Item.Cells(7).Text)
            e.Item.Cells(8).Text = e.Item.Cells(8).Text & "%"
        ElseIf e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(0).Text = "Total"
            e.Item.Cells(2).Text = Completed
            e.Item.Cells(3).Text = PendingAppraiser
            e.Item.Cells(4).Text = PendingReviewer
            e.Item.Cells(5).Text = PendingSignoff
            e.Item.Cells(6).Text = NotCompleted
            e.Item.Cells(7).Text = Total
            e.Item.Cells(8).Text = Math.Round(100 * (Completed / Total)) & "%"
        End If
    End Sub

    Private Sub grdProjectPerformance_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdProjectPerformance.ItemDataBound
        e.Item.Cells(13).Visible = False
        e.Item.Cells(2).Visible = False
        e.Item.Cells(4).Visible = False
        e.Item.Cells(6).Visible = False
        e.Item.Cells(8).Visible = False
        e.Item.Cells(10).Visible = False
        e.Item.Cells(12).Visible = False

        If e.Item.ItemType = ListItemType.Header Then
            e.Item.Cells(0).Text = "Month"
            e.Item.Cells(1).Text = "PL1"
            e.Item.Cells(3).Text = "PL2"
            e.Item.Cells(5).Text = "PL3"
            e.Item.Cells(7).Text = "PL4"
            e.Item.Cells(9).Text = "Not Done"
            e.Item.Cells(11).Text = "Total"
        End If
    End Sub
End Class
