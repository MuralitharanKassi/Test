Imports MySql.Data.MySqlClient

Partial Class kraempsign
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim objSupport As New Support.QuerySet
        Dim kracount As String
        Try
            Connection.Open()
            kracount = objSupport.SelectAValue(Connection, "count(*)", "tb_tran_storerating", "tran_empid='" & Session("UserID") & "' and tran_month='" & Session("Month") & "' and tran_year='" & Session("Year") & "' and tran_revtime<>'' and tran_signofftime is null", "tran_param")
            objSupport = Nothing
            If kracount = "0" Then
                grdEmployee.Visible = False
                lblresult.Visible = True
                lblresult.Text = "KRA does not exist or already signed off"
            Else
                If Not IsPostBack Then
                    strSQL = "select Name, Project, Title from userinfo where Month='" & Session("Month") & "' and Year='" & Session("Year") & "' and EmpID='" & Session("UserID") & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    Reader.Read()
                    If Reader.HasRows Then
                        lblHeader.Text = "Emp No: " & Session("UserID") & "  |  Emp Name: " & Reader(0) & "  |  Project: " & Reader(1) & "  |  Title: " & Reader(2)
                    End If
                    Reader.Close()
                    grdEmployee.Visible = True
                    BindGrid()
                End If
                txt_params.Text = FeedbackParam(pnlParam, Session("UserID"), Session("Month"), Session("Year"), , , True)
                strSQL = "select * from tb_tran_paramfeedback where M_PFEEDBACK_MONTH='" & Session("Month") & "' and M_PFEEDBACK_YEAR='" & Session("Year") & "' and M_PFEEDBACK_EMPID='" & Session("UserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Dim ParamList() As String
                Dim Parameter() As String

                ParamList = Split(txt_params.Text, ";")
                While Reader.Read()
                    For i = 0 To ParamList.Length - 2
                        Parameter = Split(ParamList(i), ",")
                        If Parameter(1) = Reader("M_PFEEDBACK_PARAM") Then
                            CType(pnlParam.FindControl(Parameter(0)), TextBox).Text = Reader("M_PFEEDBACK_COMMENT")
                        End If
                    Next
                End While
                Reader.Close()
                strSQL = "select * from tb_tran_empfeedback where M_FEEDBACK_MONTH='" & Session("Month") & "' and M_FEEDBACK_YEAR='" & Session("Year") & "' and M_FEEDBACK_EMPID='" & Session("UserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()

                While Reader.Read()
                    If Not IsDBNull(Reader("M_FEEDBACK_APPCOMM")) Then txt_appcomm.Text = Reader("M_FEEDBACK_APPCOMM")
                    If Not IsDBNull(Reader("M_FEEDBACK_REVCOMM")) Then txt_revcomm.Text = Reader("M_FEEDBACK_REVCOMM")
                    'If Not IsDBNull(Reader("M_FEEDBACK_EMPCOMM")) Then txt_empcomm.Text = Reader("M_FEEDBACK_EMPCOMM")
                    If Not IsDBNull(Reader("M_FEEDBACK_SUP_DONT")) Then txtrevdont.Text = Reader("M_FEEDBACK_SUP_DONT")
                    If Not IsDBNull(Reader("M_FEEDBACK_SUP_DO")) Then txtrevdo.Text = Reader("M_FEEDBACK_SUP_DO")
                    If Not IsDBNull(Reader("M_FEEDBACK_IDENT_TECH")) Then txtidtec.Text = Reader("M_FEEDBACK_IDENT_TECH")
                    If Not IsDBNull(Reader("M_FEEDBACK_IDENT_CERT")) Then txtidcer.Text = Reader("M_FEEDBACK_IDENT_CERT")
                    If Not IsDBNull(Reader("M_FEEDBACK_IDENT_SKILL")) Then txtidskill.Text = Reader("M_FEEDBACK_IDENT_SKILL")
                    If Not IsDBNull(Reader("M_FEEDBACK_REL_EMP")) Then lblrelemp.Text = Reader("M_FEEDBACK_REL_EMP")
                    If Not IsDBNull(Reader("M_FEEDBACK_REL_SUP")) Then lblrelsup.Text = Reader("M_FEEDBACK_REL_SUP")
                    If Not IsDBNull(Reader("M_FEEDBACK_COMP")) Then lblcomp.Text = Reader("M_FEEDBACK_COMP")
                End While
            End If
            Reader.Close()
            Connection.Close()
        Catch ex3 As Exception
            'errLabel.Text = ex3.Message
        End Try
    End Sub
    Private Sub BindGrid()
        Dim ds1 As DataSet
        Dim weightsum As Double = 0.0
        Dim empsum As Double = 0.0
        Dim appsum As Double = 0.0
        Dim revsum As Double = 0.0
        Dim hrsum As Double = 0.0

        Try
            Dim objSupport As New Support.QuerySet
            Dim status As String
            status = objSupport.SelectAValue(Connection, "count(tran_empid)", "tb_tran_storerating", "tran_empid  = " & Session("UserID") & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year"))
            If status = "0" Then
                errLabel.Text = "Related entries not found"
                errLabel.Visible = True
            Else
                GridPanel.Visible = True
                errLabel.Visible = False
                ds1 = objSupport.SelectDataset(Connection, "*", "tb_tran_storerating", "tran_empid  = " & Session("UserID") & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & "")
                grdEmployee.DataSource = ds1.Tables("tb_tran_storerating").DefaultView
                grdEmployee.DataBind()
                Dim DemoGridItem As DataGridItem
                Dim Param As String = ""
                For Each DemoGridItem In grdEmployee.Items
                    If Param = DemoGridItem.Cells(0).Text Then
                        DemoGridItem.Cells(0).Text = ""
                    Else
                        Param = DemoGridItem.Cells(0).Text
                        strSQL = "select round((sum(tran_revscore)/(tran_weightage/100))) from tb_tran_storerating where tran_param='" & Param & "' and tran_empid='" & Session("UserID") & "' and tran_month='" & Session("Month") & "' and tran_year='" & Session("Year") & "'"
                        Command = New MySqlCommand(strSQL, Connection)
                        Reader = Command.ExecuteReader()
                        Reader.Read()
                        If Reader.HasRows Then
                            DemoGridItem.Cells(16).Text = Reader(0)
                            'hrsum = hrsum + rs(0)
                        End If
                        Reader.Close()
                    End If
                    weightsum = weightsum + CDbl(DemoGridItem.Cells(2).Text.Substring(0, Len(DemoGridItem.Cells(2).Text) - 1)) / 100
                    appsum = appsum + CDbl(DemoGridItem.Cells(6).Text)
                    revsum = revsum + CDbl(DemoGridItem.Cells(8).Text)
                    lblRating.Text = "Appraiser Rating: " & appsum & "  |  Final Rating: " & Math.Round((revsum / (weightsum * 100)) * 100, 1)
                    lblRating.Visible = True
                Next
            End If

        Catch ex As Exception
            errLabel.Text = ex.Message

        End Try
    End Sub

    Private Sub printlink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printlink.Click
        Session("ReportMonth") = Session("Month")
        Session("ReportYear") = Session("Year")
        Session("ReportUserID") = Session("UserID")
        Response.Redirect("krareportdisplay.aspx")
    End Sub

    Private Sub bttupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttupdate.Click
        Try
            Connection.Open()

            strSQL = " Update tb_tran_storerating set tran_signofftime=now() where tran_empid = " & Session("UserID") & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & ""
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()

            Dim objSupport As New Support.Common
            strSQL = "update tb_tran_empfeedback set " & _
                        "M_FEEDBACK_SUP_DONT='" & objSupport.FormatData(txtrevdont.Text, "-") & "', " & _
                        "M_FEEDBACK_SUP_DO='" & objSupport.FormatData(txtrevdo.Text, "-") & "', " & _
                        "M_FEEDBACK_EMPCOMM='" & objSupport.FormatData(txt_empcomm.Text, "-") & "' " & _
                     "where M_FEEDBACK_EMPID='" & Session("UserID") & "' and " & _
                        "M_FEEDBACK_MONTH='" & Session("Month") & "' and " & _
                        "M_FEEDBACK_YEAR= '" & Session("Year") & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()

            Connection.Close()
            lblresult.Visible = True
            lblresult.Text = "Updated Successfully"
            Session("CurMonthKRA") = ""
            txtrevdo.ReadOnly = True
            txtrevdont.ReadOnly = True
            txt_empcomm.ReadOnly = True
            bttupdate.Enabled = False
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

End Class
