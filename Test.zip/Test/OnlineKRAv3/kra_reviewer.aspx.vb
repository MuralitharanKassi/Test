Imports MySql.Data.MySqlClient

Partial Class Krarev
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            BindGrid()
        End If
    End Sub
    Private Sub BindGrid(Optional ByVal EmpID As Integer = 0)
        Dim Emp_ID As String = ""
        Dim Exclude As String = ""
        Dim Reviewer As String = ""
        Try
            If Session("UserCurRole") <> "Administrator" And Session("UserCurRole") <> "Super Admin" Then
                Exclude = Session("UserID")
                Reviewer = Session("UserID")
            End If
            Connection.Open()
            strSQL = "call KRACompletionReport('','" & Exclude & "','','','','','" & Session("Month") & "','" & Session("Year") & "','" & Reviewer & "','')"
            Dim myDataset As New DataSet
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            If myDataset.Tables(0).Rows.Count > 0 Then
                rptList.DataSource = myDataset.Tables(0).DefaultView
                rptList.DataBind()
            Else
                rptList.DataSource = Nothing
                rptList.Visible = False
            End If
            Connection.Close()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub rptList_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs) Handles rptList.ItemCommand
        If e.CommandName = "doKRA" And e.CommandArgument <> "" Then
            Session("KRAUserID") = e.CommandArgument
            Response.Redirect("kra_review.aspx")
        End If
    End Sub

    Private Sub rptList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptList.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim ctlStatus As Label = CType(e.Item.FindControl("krastatus"), Label)
            Dim ctlLink As LinkButton = CType(e.Item.FindControl("empid"), LinkButton)
            ctlLink.Enabled = False
            ctlLink.CssClass = "disabled"
            Select Case LCase(ctlStatus.Text)
                Case "completed"
                    ctlStatus.CssClass = "status-green"
                Case "kra not eligible", "goalsheet not available"
                    ctlStatus.CssClass = "status-gray"
                Case "pending with appraiser"
                    ctlStatus.CssClass = "status-red"
                Case "pending with reviewer"
                    ctlStatus.CssClass = "status-orange"
                    ctlLink.Enabled = True
                    ctlLink.CssClass = ""
                Case Else
                    ctlStatus.CssClass = "status-black"
            End Select
        End If
    End Sub

End Class
