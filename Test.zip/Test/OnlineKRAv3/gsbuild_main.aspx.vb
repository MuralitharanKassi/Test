Imports System.Data.Odbc
Imports System.CodeDom.Compiler
Imports Microsoft.VisualBasic 'More than just VB6 Runtime functions in here!
Imports System.Reflection

Partial Class gsbuild_main
    Inherits System.Web.UI.Page


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ddl_editopr1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddl_editopr4 As System.Web.UI.WebControls.DropDownList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim kraconn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Dim kraRS As OdbcDataReader
        Dim kracmd As New OdbcCommand
        Dim strSQL As String
        lbl_errmsg.Visible = False
        kraconn.Open()
        If Not IsPostBack Then
            Dim Parameter_Count As Integer = 0
            Try
                kracmd.CommandText = "SELECT * FROM tb_master_project ORDER BY PROJ_NAME"
                kracmd.Connection = kraconn
                kraRS = kracmd.ExecuteReader()
                While (kraRS.Read())
                    ddl_project.Items.Add(New ListItem(kraRS(1), kraRS(0)))
                End While
                kraRS.Close()
                kracmd.CommandText = "SELECT * FROM tb_master_title ORDER BY TITL_NAME"
                kracmd.Connection = kraconn
                kraRS = kracmd.ExecuteReader()
                While (kraRS.Read())
                    ddl_title.Items.Add(New ListItem(kraRS(1), kraRS(0)))
                End While
                kraRS.Close()

            Catch ex3 As Exception
                lbl_errmsg.Text = ex3.Message
                lbl_errmsg.Visible = True
                'Error Message here
            End Try
            pnl_infoentry.Visible = True
        Else
            kracmd.CommandText = "SELECT COUNT(*) FROM tb_mast_service WHERE " & _
                                     "project='" & ddl_project.SelectedValue & "' and " & _
                                     "Title='" & ddl_title.SelectedValue & "' and " & _
                                     "role_month='" & ddl_month.SelectedValue & "' and " & _
                                     "role_year='" & ddl_year.SelectedItem.Text & "'"
            kracmd.Connection = kraconn
            kraRS = kracmd.ExecuteReader()
            kraRS.Read()
            If kraRS(0) <> "0" Then
                lbl_errmsg.Text = "Goal sheet already exists for the selected project."
                lbl_errmsg.Visible = True
                txt_opt.Text = "0"
            Else
                txt_opt.Text = "1"
            End If
            kraRS.Close()
        End If
    End Sub

    Private Sub btn_new_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_new.Click
        If txt_opt.Text = "1" Then
            Server.Transfer("gsbuild_new.aspx")
        End If
    End Sub

    Private Sub btn_ex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ex.Click
        If txt_opt.Text = "1" Then
            Server.Transfer("gsbuild_ex.aspx")
        End If
    End Sub
End Class
