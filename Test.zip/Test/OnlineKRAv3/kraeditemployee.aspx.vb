Imports MySql.Data.MySqlClient

Partial Class kraeditemployee
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As New MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Role As String
        Dim objSupport As New Support.DataControl
        If Not IsPostBack Then
            Try
                If Request.QueryString("id") = "" And Request.QueryString("m") = "" And Request.QueryString("y") = "" Then
                    Response.Redirect("kraemployeemaster.aspx")
                End If
                Connection.Open()
                objSupport.FillDropDown(Connection, ddlProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                objSupport.FillDropDown(Connection, ddlTitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                objSupport.FillDropDown(Connection, ddlStatus, "tb_mast_empstatus", "empstat_name", "empstat_id")
                ddlStatus.Attributes.Add("onchange", "toggleReason('" & ddlStatus.ClientID & "','" & hfStatus.ClientID & "')")

                strSQL = "select EmpID,Name,ProjectID,TitleID,AppraiserID,StatusID,Encrypt,Role,Block from userinfo where EmpID='" & Request.QueryString("id") & "' and Month='" & Request.QueryString("m") & "' and Year='" & Request.QueryString("y") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                While (Reader.Read())
                    lblMonthYear.Text = MonthName(Request.QueryString("m")) & " " & Request.QueryString("y")
                    txtMonth.Text = Request.QueryString("m")
                    txtYear.Text = Request.QueryString("y")
                    txtEmpID.Text = Reader("EmpID")
                    txtEmpName.Text = Reader("Name")
                    ddlTitle.SelectedValue = Reader("TitleID")
                    ddlProject.SelectedValue = Reader("ProjectID")
                    txtAppraiser.Text = Reader("AppraiserID")
                    ddlStatus.Text = Reader("StatusID")
                    hfStatus.Value = ddlStatus.Text
                    If Not IsDBNull(Reader("Role")) Then
                        Role = Reader("Role")
                        If InStr(Role, "1") > 0 Then cbRole1.Checked = True
                        If InStr(Role, "2") > 0 Then cbRole2.Checked = True
                        If InStr(Role, "3") > 0 Then cbRole3.Checked = True
                        If InStr(Role, "4") > 0 Then cbRole4.Checked = True
                        If InStr(Role, "5") > 0 Then cbRole5.Checked = True
                    End If
                    If Reader("Block") = False Then
                        ddlAccStatus.SelectedValue = "0"
                    Else
                        ddlAccStatus.SelectedValue = "1"
                    End If
                End While
                Reader.Close()
                Connection.Close()
                objSupport = Nothing
            Catch ex As Exception
                lblError.Text = ex.Message
            End Try
        End If
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            Dim appcheck As String
            Dim objCrypto As New Support.Crypto
            Dim objSupport As New Support.Common
            Dim objQuery As New Support.QuerySet
            Dim role As String = ""
            Connection.Open()
            appcheck = objQuery.SelectAValue(Connection, "count(M_EMPL_ID_PK)", "tb_mast_employee", "M_EMPL_ID_PK='" & txtAppraiser.Text & "'")
            If appcheck = "0" Then
                lblError.Visible = True
                lblError.ForeColor = Color.Red
                lblError.Text = "Appraiser ID does not Exist. Please enter valid Appraiser ID"
            Else
                If cbRole1.Checked = True Then role = role & "1,"
                If cbRole2.Checked = True Then role = role & "2,"
                If cbRole3.Checked = True Then role = role & "3,"
                If cbRole4.Checked = True Then role = role & "4,"
                If cbRole5.Checked = True Then role = role & "5,"
                If role <> "" Then
                    role = ",M_EMPL_ROLE='" & Mid(role, 1, Len(role) - 1) & "'"
                End If
                'If cbResetPassword.Checked = True Then
                '    objQuery.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_NAME='" & Trim(txtEmpName.Text.ToString()) & "',M_EMPL_BLOCK='" & ddlAccStatus.SelectedValue & "',M_EMPL_PASSWORD='" & objCrypto.Encrypt("password") & "',M_EMPL_ENCRYPT='1'" & role, "M_EMPL_ID_PK='" & txtEmpID.Text & "'")
                'Else
                objQuery.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_NAME='" & Trim(txtEmpName.Text.ToString()) & "',M_EMPL_BLOCK='" & ddlAccStatus.SelectedValue & "'" & role, "M_EMPL_ID_PK='" & txtEmpID.Text & "'")
                'End If
                objQuery.UpdateValue(Connection, "tb_tran_employee", "M_EMPL_PROJECT='" & ddlProject.SelectedValue & "',M_EMPL_TITLE='" & ddlTitle.SelectedValue & "',M_APPRAISER_ID='" & txtAppraiser.Text & "',M_EMPL_MODE='" & ddlStatus.SelectedValue & "'", "M_EMPL_ID_PK='" & txtEmpID.Text & "' and M_EMPL_MONTH='" & txtMonth.Text & "' and M_EMPL_YEAR='" & txtYear.Text & "'")
                If ddlStatus.SelectedItem.Text <> hfStatus.Value Then
                    objQuery.InsertValue(Connection, "tb_tran_emptrack", "emptrack_changedby, emptrack_datetime, emptrack_empid, emptrack_prevstatus, emptrack_curstatus, emptrack_reason", "'" & Session("UserID") & "',now(),'" & txtEmpID.Text & "','" & hfStatus.Value & "','" & ddlStatus.SelectedItem.Text & "','" & objSupport.FormatData(txtReason.Text, "-") & "'")
                End If
                Response.Redirect("kraemployeemaster.aspx?status=updated")
            End If
            Connection.Close()
            objQuery = Nothing
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub

End Class
