Imports MySql.Data.MySqlClient

Partial Class krastatusreport
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            If Not IsPostBack Then
                BindGrid()
            End If
        Catch ex As Exception
            Label7.Text = ex.Message
        End Try
    End Sub
    Public Sub BindGrid()
        Try
            Dim objQuery As New Support.QuerySet
            Dim myDataset As New DataSet
            Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
            Dim Connection As New MySqlConnection(conString)
            Connection.Open()
            myDataset = objQuery.SelectDataset(Connection, "*", "tb_tran_emptrack")
            Connection.Close()
            grdEmployee.DataSource = myDataset.Tables(0).DefaultView
            grdEmployee.DataBind()
        Catch ex1 As Exception
            Label7.Text = ex1.Message
        End Try
    End Sub

    Private Sub grdEmployee_PageIndexChanged1(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdEmployee.PageIndexChanged
        grdEmployee.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

End Class
