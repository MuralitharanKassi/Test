Imports System.Data.Odbc

Partial Class subordinateList
    Inherits System.Web.UI.Page
    Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    Dim DS As New DataSet
    Dim DA As New OdbcDataAdapter
    Dim DT As dataTable
    Dim DV As DataView
    Dim strSQL As String
    Dim Appraiser As Integer
    Dim slevel As String = ""

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        kraConnection.Open()
        strSQL = "select * from userinfo where Month=9 and Year=2008"
        DA = New OdbcDataAdapter(strSQL, kraConnection)
        DA.Fill(DS)
        DV = New DataView(DS.Tables(0))
        Appraiser = 2047
        DV.RowFilter = "EmpID = '" & Appraiser & "'"
        Response.Write("<br>" & DV(0)("Name") & ":" & DV(0)("Project"))
        DV.RowFilter = "AppraiserID = '" & Appraiser & "'"
        For i As Integer = 0 To DV.Count - 1
            Response.Write("<br>" & slevel.PadLeft(1, "-") & DV(i)("Name") & ":" & DV(i)("Project"))
            recurseSubordinateList(DV(i)("EmpID"), 2)
            DV.RowFilter = "AppraiserID = '" & Appraiser & "'"
        Next
        DV = Nothing
    End Sub
    Sub recurseSubordinateList(ByVal empID As String, ByVal Level As Integer)
        DV.RowFilter = "AppraiserID =" & empID
        For i As Integer = 0 To DV.Count - 1
            Response.Write("<br>" & slevel.PadLeft(Level, "-") & DV(i)("Name") & ":" & DV(i)("Project"))
            recurseSubordinateList(DV(i)("EmpID"), Level + 1)
            DV.RowFilter = "AppraiserID =" & empID
        Next
    End Sub

End Class
