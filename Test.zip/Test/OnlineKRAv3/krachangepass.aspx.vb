Imports MySql.Data.MySqlClient

Partial Class krachangepass
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String
    Dim passchanged As Boolean = False


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Dim i As Integer
            Dim objSuppport As New Support.Common
            txtNewPassword.Attributes.Add("onBlur", "return checklength('txtnewpass')")
            lblError.Visible = False
            lblStatus.Visible = False
            If Session("DefaultPassword") = "1" Then
                lblStatus.Text = "To ensure security, please change your default password"
                lblStatus.Visible = True
            End If
            If Session("UserDOB").ToString = "" Then
                lblStatus.Text = "Please update your security question"
                lblStatus.Visible = True
            End If
            For i = 1 To 31
                ddlDate.Items.Add(objSuppport.StringFill(i, 2))
            Next
            For i = 1 To 12
                ddlMonth.Items.Add(New ListItem(MonthName(i), objSuppport.StringFill(i, 2)))
            Next
            For i = 1949 To 1999
                ddlYear.Items.Add(objSuppport.StringFill(i, 4))
            Next
            Connection.Open()
            Dim userDOB As Date
            strSQL = "select M_EMPL_DOB as DOB, M_EMPL_REMQUES as SecretQ, M_EMPL_REMANS as SecretA from tb_mast_employee where M_EMPL_ID_PK='" & Session("UserID") & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            If Reader.HasRows() Then
                Reader.Read()
                If Not IsDBNull(Reader("DOB")) Then
                    userDOB = CDate(Reader("DOB"))
                    ddlDate.Visible = False
                    ddlMonth.Visible = False
                    ddlYear.Visible = False
                    rfvDate.Enabled = False
                    rfvMonth.Enabled = False
                    rfvYear.Enabled = False
                    lbldob.Visible = True
                    lbldob.Text = Day(userDOB) & "-" & MonthName(Month(userDOB)) & "-" & Year(userDOB)
                Else
                    ddlDate.Visible = True
                    ddlMonth.Visible = True
                    ddlYear.Visible = True
                    lbldob.Visible = False
                End If
            End If
            Reader.Close()
            Connection.Close()
            objSuppport = Nothing
            If Session("NewPassword") = "1" Then
                Panel1.Visible = False
                Panel2.Visible = False
                Panel3.Visible = True
                bttpass.Visible = False
                lblStatus.Visible = False
            End If
        End If
    End Sub

    Private Sub bttpass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttpass.Click
        Try
            Dim objCrypto As New Support.Crypto
            Dim objSupport As New Support.Common
            Connection.Open()
            If LCase(txtNewPassword.Text) = "password" Then
                lblError.Visible = True
                lblError.Text = "Please choose a different password"
            Else
                Dim oldPass As String
                strSQL = "select M_EMPL_PASSWORD, M_EMPL_ENCRYPT from tb_mast_employee where M_EMPL_ID_PK='" & Session("UserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Reader.Read()
                If Reader(1) = "1" Then
                    oldPass = objCrypto.Decrypt(Reader(0))
                Else
                    oldPass = Reader(0)
                End If
                Reader.Close()
                If txtOldPassword.Text = oldPass Then
                    If lbldob.Visible = True Then
                        strSQL = "update tb_mast_employee set M_EMPL_PASSWORD='" & objCrypto.Encrypt(txtNewPassword.Text.ToString) & "', M_EMPL_REMQUES='" & txtQuestion.SelectedValue & "', M_EMPL_REMANS='" & objSupport.FormatData(txtAnswer.Text) & "' where M_EMPL_ID_PK='" & Session("UserID") & "'"
                    Else
                        strSQL = "update tb_mast_employee set M_EMPL_PASSWORD='" & objCrypto.Encrypt(txtNewPassword.Text.ToString) & "', M_EMPL_DOB='" & ddlYear.SelectedValue & "-" & ddlMonth.SelectedValue & "-" & ddlDate.SelectedValue & "', M_EMPL_REMQUES='" & txtQuestion.SelectedValue & "', M_EMPL_REMANS='" & objSupport.FormatData(txtAnswer.Text) & "' where M_EMPL_ID_PK='" & Session("UserID") & "'"
                    End If
                    Command = New MySqlCommand(strSQL, Connection)
                    Command.ExecuteNonQuery()
                    Panel1.Visible = False
                    Panel2.Visible = False
                    Panel3.Visible = True
                    bttpass.Visible = False
                    lblStatus.Visible = True
                    lblStatus.Text = "Password changed successfully"
                    Session("NewPassword") = "1"
                Else
                    lblError.Visible = True
                    lblError.Text = "Old password does not match"
                End If
            End If
            Connection.Close()
            objSupport = Nothing
            objCrypto = Nothing
        Catch ex As Exception
            lblError.Visible = True
            lblError.Text = "Error while changing password. Try using different password" & ex.Message
        End Try
    End Sub

    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.Abandon()
        Response.Redirect("index.aspx")
    End Sub
End Class
