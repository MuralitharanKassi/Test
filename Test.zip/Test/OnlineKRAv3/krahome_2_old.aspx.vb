Imports MySql.Data.MySqlClient

Partial Class krahome_2
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents pnl As System.Web.UI.WebControls.Panel

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        If Session("DefaultPassword") = "1" Then
            Response.Redirect("krachangepass.aspx")
        End If
        Try
            If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Director" Then
                txtEmpID.Enabled = True
                txtEmpName.Enabled = True
                ddlTitle.Enabled = True
                ddlProject.Enabled = True
                txtAppID.Enabled = True
            ElseIf Session("UserCurRole") = "Project Admin" Or Session("UserCurRole") = "Viewer" Then
                txtEmpID.Enabled = True
                txtEmpName.Enabled = True
                ddlTitle.Enabled = True
                ddlProject.Enabled = False
                txtAppID.Enabled = True
            ElseIf Session("UserCurRole") = "User" Then
                txtEmpID.Enabled = False
                txtEmpName.Enabled = False
                ddlTitle.Enabled = False
                ddlProject.Enabled = False
                txtAppID.Enabled = False
                btnSubmit.Visible = False
            Else
                txtEmpID.Enabled = True
                txtEmpName.Enabled = True
                ddlTitle.Enabled = False
                ddlProject.Enabled = False
                txtAppID.Enabled = False
            End If

            If Request("app") <> "" Then
                txtAppID.Text = Request("app")
            End If

            If Not IsPostBack Then
                Dim objControl As New Support.DataControl
                Connection.Open()
                objControl.FillDropDown(Connection, ddlProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                objControl.FillDropDown(Connection, ddlTitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                objControl = Nothing
                BindGrid()
                Connection.Close()
            End If
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub
    Public Sub BindGrid()
        Try
            Dim DemoGridItem As GridViewRow
            Dim Project As String = ""
            Dim Title As String = ""
            Dim Appraiser As String = ""
            Dim Emp_ID As String = ""
            Dim EmpName As String = ""
            Dim ExclEmp As String = ""

            If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Director" Then
                If ddlProject.SelectedValue <> "0" Then Project = ddlProject.SelectedValue
                If ddlTitle.SelectedValue <> "0" Then Title = ddlTitle.SelectedValue
                Appraiser = txtAppID.Text
                Emp_ID = txtEmpID.Text
                EmpName = txtEmpName.Text
            ElseIf Session("UserCurRole") = "Project Admin" Or Session("UserCurRole") = "Viewer" Then
                Project = Session("UserProjectID")
                If ddlTitle.SelectedValue <> "0" Then Title = ddlTitle.SelectedValue
                Appraiser = txtAppID.Text
                Emp_ID = txtEmpID.Text
                EmpName = txtEmpName.Text
            Else
                If txtAppID.Text <> "" Then
                    Appraiser = txtAppID.Text
                Else
                    Appraiser = Session("UserID")
                End If
                Emp_ID = txtEmpID.Text
                EmpName = txtEmpName.Text
            End If
            'Connection.Open()
            strSQL = "call KRACompletionReport('" & Emp_ID & "','" & ExclEmp & "','" & EmpName & "','" & Appraiser & "','" & Title & "','" & Project & "','" & Session("Month") & "','" & Session("Year") & "','','')"
            Dim myDataset As New DataSet
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            gvList.DataSource = myDataset.Tables(0).DefaultView
            gvList.DataBind()
            'Connection.Close()
            For Each DemoGridItem In gvList.Rows
                DemoGridItem.Cells(1).Text = "<span title='Appraiser: " & DemoGridItem.Cells(8).Text & "(" & DemoGridItem.Cells(7).Text & ")'>" & DemoGridItem.Cells(1).Text & "</span>"
                If DemoGridItem.Cells(6).Text = "0" Then
                    DemoGridItem.Cells(5).ForeColor = Color.WhiteSmoke
                    DemoGridItem.Cells(5).Text = ""
                End If
                DemoGridItem.Cells(4).Font.Bold = True
                Select Case LCase(DemoGridItem.Cells(4).Text)
                    Case "completed"
                        DemoGridItem.Cells(4).ForeColor = Color.Green
                    Case "kra not eligible", "goalsheet not available"
                        DemoGridItem.Cells(4).ForeColor = Color.Gray
                    Case "pending with appraiser"
                        DemoGridItem.Cells(4).ForeColor = Color.Red
                    Case "pending with reviewer"
                        DemoGridItem.Cells(4).ForeColor = Color.Orange
                End Select
            Next
            'If Not gvList.HeaderRow Is Nothing And Not gvList.FooterRow Is Nothing Then
            'gvList.HeaderRow.TableSection = TableRowSection.TableHeader
            '    gvList.FooterRow.TableSection = TableRowSection.TableFooter
            'End If
        Catch ex1 As Exception
            lblError.Text = ex1.Message
        End Try
    End Sub

    'Private Sub export()
    '    Try
    '        Response.Clear()
    '        Response.AddHeader("content-disposition", "attachment;filename=KRA_Status.xls")
    '        Response.Charset = ""
    '        Response.Cache.SetCacheability(HttpCacheability.NoCache)
    '        Response.ContentType = "application/vnd.xls"
    '        Dim stringWrite As New System.IO.StringWriter
    '        Dim htmlWrite As New System.Web.UI.HtmlTextWriter(stringWrite)
    '        gvList.RenderControl(htmlWrite)
    '        Response.Write(stringWrite.ToString())
    '        Response.End()
    '    Catch ex3 As Exception
    '        lblError.Text = ex3.Message
    '    End Try
    'End Sub

    Private Sub LinkButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkExport.Click
        KRAClass.ExportGridView(Page, gvList, "KRA_Status.xls")
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        gvList.PageIndex = 0
        Connection.Open()
        BindGrid()
        Connection.Close()
    End Sub

    
    Private Sub gvList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvList.PageIndexChanging
        gvList.PageIndex = e.NewPageIndex
        Connection.Open()
        BindGrid()
        Connection.Close()
    End Sub
End Class
