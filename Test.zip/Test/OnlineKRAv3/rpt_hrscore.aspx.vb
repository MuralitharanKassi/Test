Imports MySql.Data.MySqlClient

Partial Class rpt_hrscore
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Grid_Param As System.Web.UI.WebControls.DataGrid

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim EmpID As Integer
        Dim myDataset As New DataSet
        Dim strCond As String = ""
        Dim canView As Boolean = False
        lbl_errmsg.Visible = False
        Try
            If Not IsPostBack Then
                pnldisplay.Visible = False
                If Request.QueryString("id") <> "" Then
                    EmpID = Request.QueryString("id")
                Else
                    If Session("UserCurRole") <> "Administrator" Then
                        EmpID = Session("UserID")
                    End If
                End If
                If Session("UserCurRole") <> "User" Then
                    pnlinput.Visible = True
                End If
            Else
                If txtEmpID.Text <> "" Then
                    EmpID = txtEmpID.Text
                End If
            End If
            Connection.Open()
            'Dim chkRights As New clsGeneral
            If (EmpID.ToString = Session("UserID")) Or Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Director" Or Session("UserCurRole") = "Super Admin" Then
                canView = True
            ElseIf isManager(Connection, EmpID, Session("UserID"), Session("Month"), Session("Year")) Then
                canView = True
            End If
            If canView Then
                Dim isValidEmployee As String
                Dim objQuery As New Support.QuerySet
                isValidEmployee = objQuery.SelectAValue(Connection, "count(*)", "tb_mast_employee", "M_EMPL_ID_PK='" & EmpID & "'")
                objQuery = Nothing
                If isValidEmployee = "0" Then
                    lbl_errmsg.Text = "Employee ID does not exists"
                    lbl_errmsg.Visible = True
                Else
                    strSQL = "select EmpID, Name, Title, Project from userinfo where EmpID='" & EmpID & "' and Month='" & Session("Month") & "' and year='" & Session("Year") & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    If Reader.HasRows Then
                        Reader.Read()
                        lblEmpID.Text = Reader("EmpID")
                        lblEmpName.Text = Reader("Name")
                        lblTitle.Text = Reader("Title")
                        lblProject.Text = Reader("Project")
                        Reader.Close()
                        getScore(EmpID)
                    Else
                        lbl_errmsg.Visible = True
                        lbl_errmsg.Text = "Employee data not avalilable for current month"
                    End If
                End If
            Else
                lbl_errmsg.Text = "You are not authorized to view this report"
            End If
            Connection.Close()
        Catch Ex As Exception
            lbl_errmsg.Visible = True
            lbl_errmsg.Text = Ex.Message
            Connection.Close()
        End Try
    End Sub

    Private Sub getScore(Optional ByVal EmpId As Integer = 0)
        Dim myDataset As New DataSet
        'kraConnection.Open()
        Try
            Dim selMonth As Integer = Microsoft.VisualBasic.DateAndTime.Month(Now) - 1
            Dim selYear As Integer = Year(Now)
            selYear = selYear - 1

            strSQL = "call ConsolidatedFinalScore(" & EmpId & "," & selMonth & "," & selYear & ")"
            'Response.Write(strSQL)
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            grdScore.DataSource = myDataset.Tables(0).DefaultView
            grdScore.DataBind()
            Dim DemoGridItem As DataGridItem
            For Each DemoGridItem In grdScore.Items
                DemoGridItem.Cells(3).Text = MonthName(DemoGridItem.Cells(0).Text) & "-" & DemoGridItem.Cells(1).Text
                If LCase(DemoGridItem.Cells(7).Text) <> "completed" Then
                    DemoGridItem.Cells(6).Text = DemoGridItem.Cells(7).Text
                    DemoGridItem.Cells(6).ForeColor = Color.Gray
                    DemoGridItem.Cells(8).ForeColor = Color.WhiteSmoke
                    DemoGridItem.Cells(8).Text = ""
                End If
            Next
            pnldisplay.Visible = True
            'grdScore.Visible = True
            'kraConnection.Close()
        Catch Ex As Exception
            'Response.Write(Ex.Message)
            lbl_errmsg.Visible = True
            lbl_errmsg.Text = Ex.Message
            'kraConnection.Close()
        End Try
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click

    End Sub
End Class
