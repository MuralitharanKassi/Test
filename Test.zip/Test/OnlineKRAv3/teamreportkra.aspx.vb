Imports System.Data.Odbc
Partial Class teamreportkra
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            DropDownList1.Items.Item(Session("month")).Selected = True
            txtyear.Text = Session("year")
        End If
    End Sub
    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        export()
    End Sub
    Private Sub export()
        Try
            Response.Clear()
            Response.AddHeader("content-disposition", "attachment;filename=kra_report.xls")
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.xls"
            Dim stringWrite As New System.IO.StringWriter
            'Dim htmlWrite As New System.Web.UI.HtmlTextWriter(stringWrite)
            Dim htmlWrite As New HtmlTextWriter(stringWrite)
            grdKRAReport.RenderControl(htmlWrite)
            Response.Write(stringWrite.ToString())
            Response.End()
        Catch Ex As Exception
            Label7.Text = Ex.Message
        End Try
    End Sub
    Private Sub go2()
        Try
            LinkButton1.Visible = True
            Dim kraconn_project As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            Dim myDataset As New DataSet
            'Dim strSQL As String
            kraconn_project.Open()
            grdKRAReport.Visible = True
            'Dim clsSelect As New clsGeneral
            Dim counter As String
            counter = SelectAValue("count(DISTINCT tran_empid)", "tb_tran_storerating", "tran_month='" & DropDownList1.SelectedItem.Value & "' and tran_year='" & txtyear.Text & "' and tran_proj='" & Session("project") & "'")
            Dim rating(counter, 12) As String
            Dim curIter As Integer = 0
            Dim kraconn_overall As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            kraconn_overall.Open()
            Dim kraRS_overall As OdbcDataReader
            Dim kracmd_overall As New OdbcCommand("select round((sum(tran_revscore)/100)*100) from tb_tran_storerating where tran_month='" & DropDownList1.SelectedItem.Value & "' and tran_year='" & txtyear.Text & "' and tran_empid in (select M_EMPL_ID_PK from tb_mast_employee where M_EMPL_PROJECT ='" & Session("project") & "') group by tran_empid", kraconn_overall)
            kracmd_overall.Connection = kraconn_overall
            kraRS_overall = kracmd_overall.ExecuteReader()
            While (kraRS_overall.Read())
                curIter = curIter + 1
                rating(curIter, 11) = kraRS_overall(0)
            End While
            kraRS_overall.Close()
            curIter = 0
            Dim kraconn_report As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            kraconn_report.Open()
            Dim kraRS_report As OdbcDataReader
            Dim kracmd_report As New OdbcCommand("select s.tran_empid as EmpId, e.M_EMPL_NAME as EmpName, p.PROJ_NAME as Project,t.TITL_NAME as Title,CASE WHEN s.tran_param='Project Level Key Initiatives' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as PLKI,CASE WHEN s.tran_param='Quality' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Quality,CASE WHEN s.tran_param='Efficiency & Productivity' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Efficiency,CASE WHEN s.tran_param='Schedule Adherence' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Schedule,CASE WHEN s.tran_param='Skill Based' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Skill,CASE WHEN s.tran_param='Competency' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Competency,CASE WHEN s.tran_param='People Development' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Developement,M_EMPL_MODE as Status from tb_tran_storerating s, tb_mast_employee e, tb_master_project p, tb_master_title t where s.tran_empid=e.M_EMPL_ID_PK and s.tran_proj=p.PROJ_ID_PK and s.tran_title=t.TITL_ID_PK and tran_month='" & DropDownList1.SelectedItem.Value & "' and tran_year='" & txtyear.Text & "' and tran_empid in (select M_EMPL_ID_PK from tb_mast_employee where M_EMPL_PROJECT ='" & Session("project") & "') group by tran_empid, tran_param", kraconn_report)
            kracmd_report.Connection = kraconn_report
            kraRS_report = kracmd_report.ExecuteReader()
            Dim curEmp As Integer = 0
            Dim i As Integer
            While (kraRS_report.Read())
                If curEmp <> kraRS_report("EmpId") Then
                    curIter = curIter + 1
                    rating(curIter, 0) = kraRS_report("EmpId")
                    rating(curIter, 1) = kraRS_report("EmpName")
                    'rating(curIter, 2) = kraRS_report("Project")
                    rating(curIter, 3) = kraRS_report("Title")
                    rating(curIter, 12) = kraRS_report("Status")
                    For i = 4 To 10
                        rating(curIter, i) = 0
                    Next
                    curEmp = kraRS_report("EmpId")
                End If
                For i = 4 To 10
                    If Not kraRS_report(i) Is DBNull.Value Then
                        rating(curIter, i) = kraRS_report(i)
                    End If
                Next
            End While
            grdKRAReport.DataSource = New Mommo.Data.ArrayDataView(rating)
            grdKRAReport.DataBind()
            kraconn_project.Close()
        Catch Ex As Exception
            Label7.Text = Ex.Message
        End Try

    End Sub

    Private Sub go1()
        Try
            LinkButton1.Visible = True
            Dim kraconn_project As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            Dim myDataset As New DataSet
            'Dim strSQL As String
            kraconn_project.Open()
            grdKRAReport.Visible = True
            'Dim clsSelect As New clsGeneral
            Dim counter As String
            Dim curMonth As Integer = DropDownList1.SelectedItem.Value
            counter = SelectAValue("count(DISTINCT tran_month)", "tb_tran_storerating", "tran_month in ('" & curMonth - 2 & "','" & curMonth - 1 & "','" & curMonth & "') and tran_year='" & txtyear.Text & "' and tran_proj='" & Session("project") & "'")
            Dim rating(counter, 12) As String
            Dim curIter As Integer = 0
            Dim kraconn_overall As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            kraconn_overall.Open()
            Dim kraRS_overall As OdbcDataReader
            Dim kracmd_overall As New OdbcCommand("select round((sum(tran_revscore)/100)*100) from tb_tran_storerating where tran_month in ('" & curMonth - 2 & "','" & curMonth - 1 & "','" & curMonth & "') and tran_year='" & txtyear.Text & "' and tran_empid='" & txtempid.Text & "' group by tran_month", kraconn_overall)
            kracmd_overall.Connection = kraconn_overall
            kraRS_overall = kracmd_overall.ExecuteReader()
            While (kraRS_overall.Read())
                curIter = curIter + 1
                rating(curIter, 11) = kraRS_overall(0)
            End While
            kraRS_overall.Close()
            curIter = 0
            Dim kraconn_report As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            kraconn_report.Open()
            Dim kraRS_report As OdbcDataReader
            Dim kracmd_report As New OdbcCommand("select s.tran_empid as EmpId, e.M_EMPL_NAME as EmpName, p.PROJ_NAME as Project,t.TITL_NAME as Title,CASE WHEN s.tran_param='Project Level Key Initiatives' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as PLKI,CASE WHEN s.tran_param='Quality' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Quality,CASE WHEN s.tran_param='Efficiency & Productivity' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Efficiency,CASE WHEN s.tran_param='Schedule Adherence' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Schedule,CASE WHEN s.tran_param='Skill Based' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Skill,CASE WHEN s.tran_param='Competency' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Competency,CASE WHEN s.tran_param='People Development' THEN round((sum(s.tran_revscore)/(s.tran_weightage/100))) END as Developement,M_EMPL_MODE as Status from tb_tran_storerating s, tb_mast_employee e, tb_master_project p, tb_master_title t where s.tran_empid=e.M_EMPL_ID_PK and s.tran_proj=p.PROJ_ID_PK and s.tran_title=t.TITL_ID_PK and tran_month in ('" & curMonth - 2 & "','" & curMonth - 1 & "','" & curMonth & "') and tran_year='" & txtyear.Text & "' and tran_empid='" & txtempid.Text & "' group by tran_empid, tran_param", kraconn_report)
            kracmd_report.Connection = kraconn_report
            kraRS_report = kracmd_report.ExecuteReader()
            Dim curEmp As Integer = 0
            Dim i As Integer
            While (kraRS_report.Read())
                If curEmp <> curMonth - curIter - 1 Then
                    curIter = curIter + 1
                    rating(curIter, 0) = curMonth - curIter - 1
                    rating(curIter, 1) = Session("year")
                    'rating(curIter, 2) = kraRS_report("Project")
                    rating(curIter, 3) = kraRS_report("Title")
                    rating(curIter, 12) = kraRS_report("Status")
                    For i = 4 To 10
                        rating(curIter, i) = 0
                    Next
                    curEmp = curMonth - curIter - 1
                End If
                For i = 4 To 10
                    If Not kraRS_report(i) Is DBNull.Value Then
                        rating(curIter, i) = kraRS_report(i)
                    End If
                Next
            End While
            grdKRAReport.DataSource = New Mommo.Data.ArrayDataView(rating)
            grdKRAReport.DataBind()
            kraconn_project.Close()
        Catch Ex As Exception
            Label7.Text = Ex.Message
        End Try

    End Sub

    Private Sub btbgo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btbgo.Click
        If cmbotype.SelectedItem.Text = "" Or cmbotype.SelectedItem.Text = "--Select--" Then
            infovalidator.ErrorMessage = "Please Select Report Type"
            infovalidator.IsValid = False
        ElseIf DropDownList1.SelectedItem.Text = "" Or DropDownList1.SelectedItem.Text = "--Select--" Then
            infovalidator.ErrorMessage = "Please Select Month"
            infovalidator.IsValid = False
        Else
            If cmbotype.SelectedItem.Value = 2 Then
                go2()
            Else
                go1()
            End If
        End If
    End Sub

    Private Sub grdkrareport_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        Try
            If e.Item.ItemType = ListItemType.Header Then
                If cmbotype.SelectedItem.Value = 2 Then
                    e.Item.Cells(0).Text = "EmpID"
                    e.Item.Cells(1).Text = "Emp Name"
                    'e.Item.Cells(2).Text = "Project"
                    e.Item.Cells(3).Text = "Title"
                    e.Item.Cells(4).Text = "PLKI"
                    e.Item.Cells(5).Text = "Quality"
                    e.Item.Cells(6).Text = "Efficiency"
                    e.Item.Cells(7).Text = "Schedule"
                    e.Item.Cells(8).Text = "Skill"
                    e.Item.Cells(9).Text = "Competency"
                    e.Item.Cells(10).Text = "Development"
                    e.Item.Cells(11).Text = "Overall"
                    e.Item.Cells(12).Text = "Status"
                Else
                    e.Item.Cells(0).Text = "Month"
                    e.Item.Cells(1).Text = "Year"
                    'e.Item.Cells(2).Text = "Project"
                    'e.Item.Cells(3).Text = "Title"
                    e.Item.Cells(4).Text = "PLKI"
                    e.Item.Cells(5).Text = "Quality"
                    e.Item.Cells(6).Text = "Efficiency"
                    e.Item.Cells(7).Text = "Schedule"
                    e.Item.Cells(8).Text = "Skill"
                    e.Item.Cells(9).Text = "Competency"
                    e.Item.Cells(10).Text = "Development"
                    e.Item.Cells(11).Text = "Overall"
                    'e.Item.Cells(12).Text = "Status"
                End If
            End If
        Catch Ex As Exception
            Label7.Text = Ex.Message
        End Try

    End Sub
    Private Sub cmbotype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbotype.SelectedIndexChanged

    End Sub
End Class
