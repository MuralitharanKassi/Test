Imports MySql.Data.MySqlClient
Imports System.Data.OleDb
Imports System.Text
Imports System.IO
Partial Class Kra_actual_upload
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    'Dim Reader As MySqlDataReader
    'Dim Command As New MySqlCommand
    'Dim strSQL As String
    Dim FilePath As String
    Dim FileID As Integer
    Dim r As New Random

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FilePath = Server.MapPath("files") & "\"
    End Sub

    Private Sub btnupload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupload.Click
        Try
            If Not File1.PostedFile Is Nothing And File1.PostedFile.ContentLength > 0 Then
                Dim fn As String = System.IO.Path.GetFileName(File1.PostedFile.FileName)
                If Right(fn, 3) <> "xls" Then
                    Label1.Text = "Please select only excel file"
                    Label1.Visible = True
                    Exit Sub
                Else
                    FileID = r.Next(1000, 9999)
                    Dim SaveLocation As String = FilePath & "ActualScore" & FileID & ".xls"
                    Try
                        If File.Exists(SaveLocation) Then File.Delete(SaveLocation)
                        File1.PostedFile.SaveAs(SaveLocation)
                        CheckFile("ActualScore" & FileID)
                    Catch Exc As Exception
                        CustomValidator1.ErrorMessage = "Upload Terminated! This may be due to server connectivity. Please contact your administrator."
                        If Session("UserCurRole") = "Administrator" Then
                            CustomValidator1.ErrorMessage = "Error: " & Exc.Message
                        End If
                        CustomValidator1.IsValid = False
                    End Try
                End If
            Else
                Label4.Text = "Please select a file to upload."
                Label4.Visible = True
            End If
        Catch ex As Exception
            lblerr.Text = "Error saving file"
            If Session("UserCurRole") = "Administrator" Then
                lblerr.Text = "Error: " & ex.Message
            End If
        End Try
    End Sub
    Private Sub CheckFile(ByVal Filename As String)
        Dim ConnString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & FilePath & Filename & ".xls;Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1"""
        Dim xlconn As New OleDbConnection(ConnString)
        'Dim xlsTable As DataTable
        Dim objStreamWriter_excel As StreamWriter
        'Dim textfile As String
        Dim excelfile As String
        Dim errorrow As String = ""
        Dim objQuery As New Support.QuerySet
        If IsPostBack Then
            Try
                xlconn.Open()
                excelfile = "Error_" & Filename & ".csv"
                Dim errorfilename As String = FilePath & excelfile

                If File.Exists(errorfilename) Then File.Delete(errorfilename)
                objStreamWriter_excel = File.AppendText(errorfilename)

                objStreamWriter_excel.WriteLine(""" Employee_ID "","" Project "","" Title "","" Month "","" Year "","" Parameter "","" Key_Determinant "","" Weightage "","" Goal "","" Actual_Score "","" Error Details "","" Row Number """)

                '---------------------------------------------------------
                Dim temp_value As Integer = 1
                Dim errormessage As String = ""
                Dim xlda As String = "select * from [Actual_Score_Template$]"
                Dim acualcommand As New OleDbCommand(xlda, xlconn)
                Dim actualReader As OleDbDataReader = acualcommand.ExecuteReader(CommandBehavior.CloseConnection)
                Dim count_title As Integer
                Dim count_project As Integer
                Dim exceldetails(actualReader.FieldCount) As String
                Dim i As Integer
                Dim k As Integer = 0
                Dim j As Integer = 1
                While (actualReader.Read())
                    Connection.Open()
                    count_title = objQuery.SelectAValue(Connection, "count(TITL_ID_PK)", "tb_master_title", "TITL_NAME='" & actualReader(2) & "'")
                    count_project = objQuery.SelectAValue(Connection, "count(PROJ_ID_PK)", "tb_master_project", "PROJ_NAME='" & actualReader(1) & "'")
                    Connection.Close()
                    If IsDBNull(actualReader(0)) Or IsDBNull(actualReader(1)) Or IsDBNull(actualReader(2)) Or IsDBNull(actualReader(3)) Or IsDBNull(actualReader(4)) Or IsDBNull(actualReader(5)) Or IsDBNull(actualReader(6)) Or IsDBNull(actualReader(7)) Or IsDBNull(actualReader(8)) Or IsDBNull(actualReader(9)) Then
                        errormessage = "Fields can not be empty;"
                    Else
                        If count_title = 0 Then
                            errormessage = errormessage & "Title Not Found;"
                        End If
                        If count_project = 0 Then
                            errormessage = errormessage & "Project Not Found;"
                        End If

                        If errormessage <> "" Then
                            For i = 0 To 9
                                exceldetails(i) = Replace(actualReader(i), "'", "")
                            Next
                            objStreamWriter_excel.WriteLine("""" & exceldetails(0) & """,""" & exceldetails(1) & """,""" & exceldetails(2) & """,""" & exceldetails(3) & """,""" & exceldetails(4) & """,""" & exceldetails(5) & """,""" & exceldetails(6) & """,""" & exceldetails(7) & """,""" & exceldetails(8) & """,""" & exceldetails(9) & """,""" & errormessage & """,""" & j + 1 & """")
                            If errorrow <> "" Then
                                errorrow = errorrow & "," & j + 1
                            Else
                                errorrow = j + 1
                            End If
                            k = k + 1
                        Else
                        End If
                        j = j + 1
                    End If
                End While
                '---------------------------------------------------------
                'Close the streamWriter
                objStreamWriter_excel.Close()
                xlconn.Close()
                If errorrow <> "" Then
                    CustomValidator1.ErrorMessage = k & " Out of " & j & " records contains error "
                    errReport.Visible = True
                    errReport.Attributes.Add("target", "_blank")
                    errReport.Attributes.Add("href", errorfilename)
                    CustomValidator1.IsValid = False
                    Label4.Visible = False
                Else
                    If chkoverwrite.Checked = True Then
                        actual_upload(1)
                    Else
                        actual_upload(0)
                    End If
                End If
            Catch ex As Exception
                CustomValidator1.ErrorMessage = "Upload Terminated! This may be due to Incorrect file structure."
                If Session("UserCurRole") = "Administrator" Then
                    CustomValidator1.ErrorMessage = "Error: " & ex.Message
                End If
                CustomValidator1.IsValid = False
                'objStreamWriter_excel.Close()
                xlconn.Close()
            End Try
        End If
    End Sub
    Private Sub actual_upload(Optional ByVal Overwrite As Integer = 0)
        Try
            Dim path As String = FilePath & "ActualScore" & FileID & ".xls"
            If IsPostBack Then
                Dim xlconn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & path & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
                xlconn.Open()
                Dim xlproject As String
                Dim xltitle As String
                Dim flag As String
                Dim temp As Integer = 0
                Dim upd As Integer = 0
                Dim ins As Int16 = 0
                Dim objQuery As New Support.QuerySet
                Try
                    Dim xlda As String = "select * from [Actual_Score_Template$]"
                    Dim acualcommand As New OleDbCommand(xlda, xlconn)
                    Dim actualReader As OleDbDataReader = acualcommand.ExecuteReader(CommandBehavior.CloseConnection)
                    Try
                        While (actualReader.Read())
                            If IsDBNull(actualReader("Title")) And IsDBNull(actualReader("Month")) Then
                                temp = 1
                            ElseIf IsDBNull(actualReader("Emp ID")) Or IsDBNull(actualReader("Actual Score")) Then
                                temp = 2
                                Exit While
                            Else
                                Connection.Open()
                                xlproject = objQuery.SelectAValue(Connection, "PROJ_ID_PK", "tb_master_project", "PROJ_NAME='" & actualReader("Project") & "'")
                                xltitle = objQuery.SelectAValue(Connection, "TITL_ID_PK", "tb_master_title", "TITL_NAME='" & actualReader("Title") & "'")
                                flag = objQuery.SelectAValue(Connection, "count(*)", "tb_tran_actuals", "empid='" & actualReader("Emp ID") & "' and act_month='" & MonthName(actualReader("Month")) & "' and act_year='" & actualReader("Year") & "' and Key_Deter='" & actualReader("Key Determinant") & "' and Parameter='" & actualReader("Parameter") & "'")

                                If flag = 1 Then
                                    If Overwrite = 1 Then
                                        objQuery.UpdateValue(Connection, "tb_tran_actuals", "project='" & xlproject & "', title='" & xltitle & "', act_month='" & MonthName(actualReader("Month")) & "', act_year='" & actualReader("Year") & "',actual='" & actualReader("Actual Score") & "'", "empid='" & actualReader("Emp ID") & "' and act_month='" & MonthName(actualReader("Month")) & "' and act_year='" & actualReader("Year") & "' and Key_Deter='" & actualReader("Key Determinant") & "' and Parameter='" & actualReader("Parameter") & "'")
                                        upd = upd + 1
                                    End If
                                Else
                                    objQuery.InsertValue(Connection, "tb_tran_actuals", "empid,project,title,act_month,act_year,Key_Deter,Parameter,actual", "'" & actualReader("Emp ID") & "','" & xlproject & "','" & xltitle & "','" & actualReader("Month") & "','" & actualReader("Year") & "','" & actualReader("Key Determinant") & "','" & actualReader("Parameter") & "','" & actualReader("Actual Score") & "'")
                                    ins = ins + 1
                                End If
                                Connection.Close()
                            End If
                        End While
                        If temp = 2 Then
                            CustomValidator1.Text = "There are null entries in the excel sheet. Please check and try again"
                            CustomValidator1.IsValid = False
                            Label4.Visible = False
                        Else
                            Label4.Text = "Data Transfer done successfully. " & upd & " row(s) updated. " & ins & " row(s) inserted."
                            Label4.Visible = True
                        End If
                        xlconn.Close()

                    Catch ex As Exception
                        CustomValidator1.Text = ex.Message
                        CustomValidator1.IsValid = False
                        Label4.Visible = False
                        xlconn.Close()
                    End Try
                Catch ex2 As Exception
                    lblerr.Text = "Sheet name mismatch. Please make sure the sheet name is 'Actual_Score_Template'"
                End Try
            End If
        Catch ex As Exception
            lblerr.Text = "Error reading source file"
        End Try
    End Sub
End Class
