var tmenuItems = [

    ["+General","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Home","javascript:loadPage('home.aspx')", "", "", "", "Home Page", "", "", "", "", ],
    ["Transaction","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Appraisal","javascript:loadPage('kra_appraiser.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Sign Off KRA","javascript:loadPage('kraempsign.aspx')", "", "", "", "", "", "", "", "", ],
    ["Reports","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|My KRA Score","javascript:loadPage('krareportdisplay.aspx')", "", "", "", "", "", "", "", "", ],
        ["|KRA Report","javascript:loadPage('krareport.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Final Rating","javascript:loadPage('rpt_hrscore.aspx')", "", "", "", "", "", "", "", "", ],
];

dtree_init();