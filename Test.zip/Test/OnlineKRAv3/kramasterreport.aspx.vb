Imports MySql.Data.MySqlClient

Partial Class kramasterreport
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As New MySqlCommand
    Dim Parameters() As String
    Dim ReportType As String
    Dim ParamList() As String
    Dim strSQL As String
    
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Select Case Request.QueryString("r")
            Case "1"
                ReportType = "Parameter Wise List"
            Case "2"
                ReportType = "KRA Actuals"
        End Select
        'lblTitle.Text = ReportType
        If Not IsPostBack Then
            Try
                Dim objSupport As New Support.DataControl
                Connection.Open()
                objSupport.FillDropDown(Connection, ddlProject, "tb_master_project", "proj_name", "proj_id_pk")
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlMonth, Session("Month"), Session("Year"))
                Connection.Close()
                objSupport = Nothing
                ddlMonth.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
                divExport.Visible = False
            Catch ex3 As Exception
                lblError.Text = ex3.Message
            End Try
        End If
    End Sub

    Private Sub getReport()
        Try
            Dim objQuery As New Support.QuerySet
            Dim objSupport As New Support.Common
            'Dim Adapter As MySqlDataAdapter
            Dim counter As String
            Connection.Open()
            Dim cond As String = ""
            If ddlProject.SelectedValue <> "0" Then
                cond = cond & " and tran_proj ='" & ddlProject.SelectedValue & "'"
            End If
            counter = objQuery.SelectAValue(Connection, "count(DISTINCT tran_empid)", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'" & cond)
            cond = ""
            divExport.Visible = True
            Dim myDataset As New DataSet
            Dim errorData As String = ""
            If ReportType = "KRA Actuals" Then
                Dim empid As Integer = 0
                Dim intloop As Integer = -1
                Dim curparamcount As Integer = 0
                Dim curparamname As String = ""
                Dim i As Integer
                Try
                    ddlProject.Visible = True
                    lblProject.Visible = True
                    Dim Project As String = "0"
                    If ddlProject.SelectedValue <> "0" Then Project = ddlProject.SelectedValue
                    strSQL = "call Actual_Score(" & objSupport.GetMonth(ddlMonth.SelectedValue) & "," & objSupport.GetYear(ddlMonth.SelectedValue) & "," & Project & ")"
                    Parameters = Split(objQuery.SelectArrayList(Connection, "distinct tran_param", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'"), ",")
                    If ddlProject.SelectedValue = "0" Then
                        counter = objQuery.SelectAValue(Connection, "count(DISTINCT tran_empid)", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>''")
                    Else
                        counter = objQuery.SelectAValue(Connection, "count(DISTINCT tran_empid)", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' and tran_proj='" & ddlProject.SelectedItem.Value & "'")
                    End If
                    Dim paramlen As Integer = 8
                    Dim bound As Integer = 0
                    bound = (UBound(Parameters) + 1) * (paramlen + 1)
                    Dim Actuals(counter, bound + 5) As String
                    If Session("UserCurRole") = "Administrator" Then
                        errorData &= "Parameter Count: " & (UBound(Parameters) + 1) & "<br>"
                        errorData &= "Employee Count: " & counter & "<br>"
                        errorData &= "Array Bound: " & bound & "<br>"
                    End If
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    Dim Param_total As Double = 0
                    Dim Last_Keydetn As Boolean = False
                    Dim Weightage As Double = 0
                    Dim prev_Parameter As Integer
                    'Dim ParamName, KeyName As String
                    While Reader.Read()
                        If empid <> Reader("EmpID") Then
                            empid = Reader("EmpID")
                            If Weightage <> 0 Then
                                Actuals(intloop, 5 + (prev_Parameter * (paramlen + 1)) + paramlen + 1) = Format(Param_total / (Weightage / 100), "#.##")
                            End If
                            Param_total = 0
                            intloop = intloop + 1
                            Actuals(intloop, 0) = intloop + 1
                            Actuals(intloop, 1) = Reader("EmpID")
                            Actuals(intloop, 2) = Reader("Name")
                            Actuals(intloop, 3) = Reader("Appraiser")
                            Actuals(intloop, 4) = Reader("Project")
                            Actuals(intloop, 5) = Reader("Title")
                        End If
                        For i = 0 To UBound(Parameters)
                            If Reader("parameter") = Parameters(i) Then
                                If Reader("parameter") = curparamname Then
                                    curparamcount = curparamcount + 1
                                Else
                                    curparamname = Reader("parameter")
                                    curparamcount = 1
                                    If curparamcount <> 0 Then
                                        If Weightage <> 0 Then
                                            Actuals(intloop, 5 + (prev_Parameter * (paramlen + 1)) + paramlen + 1) = Format(Param_total / (Weightage / 100), "#.##")
                                        Else
                                            Actuals(intloop, 5 + (prev_Parameter * (paramlen + 1)) + paramlen + 1) = ""
                                        End If
                                    End If
                                    Param_total = 0
                                End If
                                prev_Parameter = i
                                If Mid(Reader("Weightage"), 1, Len(Reader("Weightage")) - 1) <> "0" Then
                                    Weightage = CDbl(Mid(Reader("Weightage"), 1, Len(Reader("Weightage")) - 1))
                                Else
                                    Weightage = 0
                                End If
                                If Reader("RevScore") <> "0" Then
                                    Param_total = Format(Param_total + Reader("RevScore"), "#.##")
                                End If
                                Actuals(intloop, 5 + (i * (paramlen + 1)) + curparamcount) = Reader("Actual")
                                Exit For
                            End If
                        Next
                    End While
                    grdReport.DataSource = New Mommo.Data.ArrayDataView(Actuals)
                    grdReport.DataBind()
                    grdExport.DataSource = New Mommo.Data.ArrayDataView(Actuals)
                    grdExport.DataBind()
                    Reader.Close()
                Catch ex As Exception
                    Response.Write("Error occured!!<br>" & ex.Message & "<br><a href='kramasterreport.aspx?r=2'>click here</a> to go back")
                    If Session("UserCurRole") = "Administrator" Then
                        Response.Write("<br>Error in Emp ID: " & empid & ": Parameter: " & curparamname)
                    End If
                    Response.End()
                End Try

            ElseIf ReportType = "Parameter Wise List" Then
                ddlProject.Visible = True
                lblProject.Visible = True
                Dim curIter As Integer = 0
                ParamList = Split(objQuery.SelectArrayList(Connection, "distinct tran_param", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'"), ",")
                Dim rating(counter, 5 + ParamList.Length) As String
                If ddlProject.SelectedValue <> "0" Then cond = cond & " and tran_proj ='" & ddlProject.SelectedValue & "'"
                strSQL = "select round(sum(tran_revscore),1) from tb_tran_storerating where tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' " & cond & " group by tran_empid order by tran_empid"
                'If Session("UserCurRole") = "Administrator" Then Response.Write(strSQL & "<br>")
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                While (Reader.Read())
                    rating(curIter, 4 + ParamList.Length) = Reader(0)
                    curIter = curIter + 1
                End While
                Reader.Close()
                curIter = -1
                'strSQL = "select EmpId, Name as EmpName, Project, Title, s.tran_param as Parameter, round(sum(s.tran_revrating*(s.tran_weight/100))/(s.tran_weightage/100),1) as Score, Status from tb_tran_storerating s, userinfo u where s.tran_empid=u.EmpID and Month='" & getMonth(ddlMonth.SelectedValue) & "' and Year='" & getYear(ddlMonth.SelectedValue) & "' and tran_month='" & getMonth(ddlMonth.SelectedValue) & "' and tran_year='" & getYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' " & cond & " group by tran_empid, tran_param order by tran_empid, tran_param"
                strSQL = "select EmpId, Name as EmpName, Project, Title, s.tran_param as Parameter, round(100*sum(s.tran_revscore)/sum(s.tran_weight),1) as Score, Status from tb_tran_storerating s, userinfo u where s.tran_empid=u.EmpID and Month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and Year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' " & cond & " group by tran_empid, tran_param order by tran_empid, tran_param"
                'If Session("UserCurRole") = "Administrator" Then Response.Write(strSQL & "<br>")
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Dim curEmp As Integer = 0
                Dim i As Integer
                While (Reader.Read())
                    If curEmp <> Reader("EmpId") Then
                        curIter = curIter + 1
                        rating(curIter, 0) = Reader("EmpId")
                        rating(curIter, 1) = Reader("EmpName")
                        rating(curIter, 2) = Reader("Project")
                        rating(curIter, 3) = Reader("Title")
                        rating(curIter, 5 + ParamList.Length) = Reader("Status")
                        For i = 4 To 3 + ParamList.Length
                            rating(curIter, i) = ""
                        Next
                        curEmp = Reader("EmpId")
                    End If
                    For i = 0 To ParamList.Length - 1
                        If ParamList(i) = Reader("Parameter") Then
                            If Not Reader("Score") Is DBNull.Value Then
                                rating(curIter, 4 + i) = Reader("Score")
                            End If
                        End If
                    Next
                End While
                grdReport.DataSource = New Mommo.Data.ArrayDataView(rating)
                grdReport.DataBind()
                grdExport.DataSource = New Mommo.Data.ArrayDataView(rating)
                grdExport.DataBind()
            End If
            objSupport = Nothing
            objQuery = Nothing
            Connection.Close()
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Try
            divExport.Visible = False
            grdReport.CurrentPageIndex = 0
            getReport()
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub

    Private Sub grdReport_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdReport.PageIndexChanged
        grdReport.CurrentPageIndex = e.NewPageIndex
        getReport()
    End Sub

    Private Sub grdReport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdReport.ItemDataBound
        Try
            If ReportType = "KRA Actuals" Then
                If e.Item.ItemType = ListItemType.Header Then
                    e.Item.Cells(0).Text = "S.No"
                    e.Item.Cells(1).Text = "EmpID"
                    e.Item.Cells(2).Text = "Emp Name"
                    e.Item.Cells(3).Text = "Appraiser"
                    e.Item.Cells(4).Text = "Project"
                    e.Item.Cells(5).Text = "Title"
                    Dim i As Integer
                    Dim j As Integer
                    Dim paramlen As Integer = 8
                    For i = 0 To UBound(Parameters)
                        For j = 1 To 9
                            If j = 9 Then
                                e.Item.Cells(5 + (i * (paramlen + 1)) + j).Text = Parameters(i) & " Total"
                            Else
                                e.Item.Cells(5 + (i * (paramlen + 1)) + j).Text = Parameters(i) & " " & j
                            End If
                        Next
                    Next
                End If
            End If
            If ReportType = "Parameter Wise List" Then
                If e.Item.ItemType = ListItemType.Header Then
                    e.Item.Cells(0).Text = "EmpID"
                    e.Item.Cells(1).Text = "Emp Name"
                    e.Item.Cells(2).Text = "Project"
                    e.Item.Cells(3).Text = "Title"
                    Dim i As Integer
                    For i = 0 To ParamList.Length - 1
                        e.Item.Cells(4 + i).Text = ParamList(i)
                    Next
                    e.Item.Cells(4 + ParamList.Length).Text = "Overall"
                    e.Item.Cells(5 + ParamList.Length).Text = "Status"
                End If
            End If
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub

    Private Sub grdExport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdExport.ItemDataBound
        Try
            If ReportType = "KRA Actuals" Then
                If e.Item.ItemType = ListItemType.Header Then
                    e.Item.Cells(0).Text = "S.No"
                    e.Item.Cells(1).Text = "EmpID"
                    e.Item.Cells(2).Text = "Emp Name"
                    e.Item.Cells(3).Text = "Appraiser"
                    e.Item.Cells(4).Text = "Project"
                    e.Item.Cells(5).Text = "Title"
                    Dim i As Integer
                    Dim j As Integer
                    Dim paramlen As Integer = 8
                    For i = 0 To UBound(Parameters)
                        For j = 1 To 9
                            If j = 9 Then
                                e.Item.Cells(5 + (i * (paramlen + 1)) + j).Text = Parameters(i) & " Total"
                            Else
                                e.Item.Cells(5 + (i * (paramlen + 1)) + j).Text = Parameters(i) & " " & j
                            End If
                        Next
                    Next
                End If
            End If
            If ReportType = "Parameter Wise List" Then
                If e.Item.ItemType = ListItemType.Header Then
                    e.Item.Cells(0).Text = "EmpID"
                    e.Item.Cells(1).Text = "Emp Name"
                    e.Item.Cells(2).Text = "Project"
                    e.Item.Cells(3).Text = "Title"
                    Dim i As Integer
                    For i = 0 To ParamList.Length - 1
                        e.Item.Cells(4 + i).Text = ParamList(i)
                    Next
                    e.Item.Cells(4 + ParamList.Length).Text = "Overall"
                    e.Item.Cells(5 + ParamList.Length).Text = "Status"
                End If
            End If
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub

    Protected Sub imgbtnXLS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnXLS.Click
        grdExport.Visible = True
        Export.Datagrid2Excel(grdExport, "kra_report", "", "", "export.css")
        grdExport.Visible = False
    End Sub

    Protected Sub imgbtnDOC_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDOC.Click
        grdExport.Visible = True
        Export.Datagrid2Word(grdExport, "kra_report", "", "", "export.css")
        grdExport.Visible = False
    End Sub

    Protected Sub imgbtnPDF_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnPDF.Click
        grdExport.Visible = True
        Export.Datagrid2PDF(grdExport, "kra_report", "", "", "export.css")
        grdExport.Visible = False
    End Sub
End Class
