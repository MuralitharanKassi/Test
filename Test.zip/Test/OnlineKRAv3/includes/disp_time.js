﻿var ist = new Date()
var montharray = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
var shortmonth = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

function padlength(what) {
    var output = (what.toString().length == 1) ? "0" + what : what
    return output
}
function formatField(num, isHour) {
    if (typeof isHour != "undefined") { //if this is the hour field
        var hour = (num > 12) ? num - 12 : num
        return (hour == 0) ? 12 : hour
        //var hour=(num>23)? num-24 : num
        //return hour
    }
    return (num <= 9) ? "0" + num : num//if this is minute or sec field
}
function displayist() {
    ist.setSeconds(ist.getSeconds() + 1)
    var datestring = padlength(ist.getDate()) + " " + shortmonth[ist.getMonth()] + " " + ist.getFullYear()
    var timestring = padlength(ist.getHours()) + ":" + padlength(ist.getMinutes()) + ":" + padlength(ist.getSeconds())
    var hour = ist.getHours();
    var minutes = ist.getMinutes();
    var seconds = ist.getSeconds();
    var month = ist.getMonth();
    var date = ist.getDate();
    var year = ist.getFullYear();
    var ampm = (hour >= 12) ? "PM" : "AM"
    document.getElementById('IST').innerHTML = datestring + ", " + formatField(hour, 1) + ":" + formatField(minutes) + ":" + formatField(seconds) + " " + ampm + " IST";

}
