Imports System.Data.Odbc

Partial Class kravaluesadmin
    Inherits System.Web.UI.Page
    Dim totloop

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Try
                Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
                kraConnection.Open()
                Dim strSQL As String = "select EmpID, Name, ProjectID, TitleID, Project, Title from userinfo where EmpID='" & Request.QueryString("id") & "' AND Month= '" & Session("month") & "' AND Year='" & Session("year") & "'"
                Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
                Dim kraReader As OdbcDataReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
                kraReader.Read()
                Session.Item("kraempno") = kraReader.GetString(0)
                Session.Item("kraempname") = kraReader.GetString(1)
                Session.Item("kraproject") = kraReader.GetString(2)
                Session.Item("kratitle") = kraReader.GetString(3)
                'Dim objGeneral As New clsGeneral
                lblHeader.Text = "Emp No: <b>" & Session.Item("kraempno") & "</b><br>" & "Emp Name: <b>" & Session.Item("kraempname") & "</b><br>" & "Project: <b>" & kraReader.GetString("Project") & "</b><br>" & "Title: <b>" & kraReader.GetString("Title") & "</b>"
                kraReader.Close()
            Catch ex As Exception
                lblStatus.Text = ex.Message
            End Try
        End If
        If IsPostBack Then
            Try
                Dim kraconn_transaction As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
                kraconn_transaction.Open()
                Dim kraRS_transaction As OdbcDataReader
                Dim kracmd_transaction As New OdbcCommand("SELECT COUNT(tran_empid) FROM tb_tran_storerating WHERE tran_empid='" & Session.Item("kraempno") & "' AND tran_month= '" & Session("month") & "' AND tran_year='" & Session("year") & "'", kraconn_transaction)
                kracmd_transaction.Connection = kraconn_transaction
                kraRS_transaction = kracmd_transaction.ExecuteReader()
                kraRS_transaction.Read()
                If (kraRS_transaction.HasRows) Then
                    If (kraRS_transaction(0) > 0) Then
                        lblStatus.Text = "Rating Already Present"
                    Else
                        kraconn_transaction.Close()
                        cmdConfirm.Visible = False
                        pnlOutter.Visible = True
                        'Dim objGeneral As New clsGeneral
                        Dim empid = Request.QueryString("id").ToString()
                        'Session.Item("kramonth") = objGeneral.SelectAvalue("role_month", "tb_mast_service", "Title =" & Session("title"))
                        'Session.Item("krayear") = objGeneral.SelectAvalue("role_year", "tb_mast_service", "Title =" & Session("title"))
                        totloop = adminParam(pnlTxtPanel, "role_month='" & Session("month") & "' and role_year= '" & Session("year") & "' and Title='" & Session("kratitle") & "'", Session("kraproject"), empid)
                        If totloop > 0 Then
                            cmdGenerate.Visible = True
                        Else
                            pnlTxtPanel.Visible = False
                            lblStatus.Text = "Rating Parameters Not Found"
                        End If

                    End If
                End If
            Catch ex1 As Exception
                lblStatus.Text = ex1.Message
            End Try
        End If
    End Sub

    Private Sub cmdGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim t, str
        Dim strActual As String()
        Dim blnCheck As Boolean = False
        str = "c=" & totloop
        Dim percentagecheck As Integer
        Dim actualpercentage As Integer
        Try
            For t = 1 To totloop
                If IsNothing(CType(FindControl("actual" & t), TextBox).Text) = False And CType(FindControl("actual" & t), TextBox).Text <> "" And blnCheck = False Then
                    If ((CType(FindControl("goal" & t), Label).Text).IndexOf("%") > -1) Then
                        CType(FindControl("actual" & t), TextBox).Text = CType(FindControl("actual" & t), TextBox).Text & "%"
                    End If
                    str = str & "&a" & t & "=" & CType(FindControl("actual" & t), TextBox).Text
                Else
                    blnCheck = True
                    Exit For
                End If
            Next
            If blnCheck = False Then
                Response.Redirect("krarating.aspx?" & str)
            Else
                vdlActual.IsValid = False
            End If

        Catch ex2 As Exception
            lblStatus.Text = ex2.Message
        End Try
    End Sub

    Private Sub vdlActual_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vdlActual.ServerValidate

    End Sub

    Private Sub cmdConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConfirm.Click

    End Sub
End Class
