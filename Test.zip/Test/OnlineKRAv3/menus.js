
	/* MENUS.JS */
	
	var eOpenMenu = null;
	var curleft = curtop = 0;
	function getAbsoluteLeft(objectId)
	{
		o = document.getElementById(objectId)
		oLeft = o.offsetLeft            // Get left position from the parent object
		while(o.offsetParent!=null)
		{
			oParent = o.offsetParent    // Get parent object reference
			oLeft += oParent.offsetLeft // Add parent left position
			o = oParent
		}
		// Return left postion
		return oLeft
	}

	function getAbsoluteTop(objectId)
	{
		// Get an object top position from the upper left viewport corner
		// Tested with relative and nested objects
		o = document.getElementById(objectId)
		oTop = o.offsetTop            // Get top position from the parent object
		while(o.offsetParent!=null)
		{
			oParent = o.offsetParent  // Get parent object reference
			oTop += oParent.offsetTop // Add parent top position
			o = oParent
		}
		// Return top position
		return oTop
	}

	function OpenMenu(eSrc,eMenu)
	{
		//alert(divMenuBar.offsetParent.offsetLeft);
		//alert(getAbsoluteLeft("divMenuBar"));
		//alert(getAbsoluteTop("divMenuBar"));
		eMenu.style.left = eSrc.offsetLeft + getAbsoluteLeft("divMenuBar");
		eMenu.style.top = divMenuBar.offsetHeight + getAbsoluteTop("divMenuBar");
		eMenu.style.visibility = "visible";
		eOpenMenu = eMenu;
	}

	function CloseMenu(eMenu)
	{
		eMenu.style.visibility = "hidden";
		eOpenMenu = null;
	}

	function document.onmouseover()
	{
		var eSrc = window.event.srcElement;
		if ("clsMenuBarItem" == eSrc.className)
		{
			eSrc.style.color = "#333333"; 
			var eMenu = document.all[eSrc.id.replace("tdMenuBarItem","divMenu")];
			if (eOpenMenu && eOpenMenu != eMenu) 
			{
				CloseMenu(eOpenMenu);
			}
			if (eMenu) 
			{
				OpenMenu(eSrc,eMenu);
			}
		}
		else if (eOpenMenu && !eOpenMenu.contains(eSrc) && !divMenuBar.contains(eSrc)) 
		{
			CloseMenu(eOpenMenu);
		}
	}
	
	function document.onmouseout()
	{
		var eSrc = window.event.srcElement;
		if ("clsMenuBarItem" == eSrc.className)
		{
			eSrc.style.color = ""; 
		}
	}	
