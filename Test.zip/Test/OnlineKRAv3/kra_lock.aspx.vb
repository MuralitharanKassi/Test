Imports MySql.Data.MySqlClient

Partial Class kra_lock
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim i As Integer
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents CheckBox1 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lbCheckAll As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lbUncheckAll As System.Web.UI.WebControls.LinkButton

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblError.Text = ""
        lblStatus.Text = ""
        Try
            If Not IsPostBack Then
                Connection.Open()
                Dim objControl As New Support.DataControl
                objControl.FillDropDown(Connection, cboProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                FillMonth(Connection, "", "", ddlMonth, Session("Month"), Session("Year"), 6)
                objControl = Nothing
                Connection.Close()
                ddlMonth.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
            End If
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            'Dim conn As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            Connection.Open()
            If sel_project.Text = "0" Then
                For Each item As ListItem In lst_all.Items
                    Command = New MySqlCommand("UPDATE tb_mast_service SET kra_locked='0' WHERE project='" & item.Value & "' and role_month='" & sel_month.Text & "' and role_year='" & sel_year.Text & "' ", Connection)
                    Command.ExecuteNonQuery()
                Next
                For Each item As ListItem In lst_selected.Items
                    Command = New MySqlCommand("UPDATE tb_mast_service SET kra_locked='1' WHERE project='" & item.Value & "' and role_month='" & sel_month.Text & "' and role_year='" & sel_year.Text & "' ", Connection)
                    Command.ExecuteNonQuery()
                Next
            Else
                For Each item As ListItem In lst_all.Items
                    Command = New MySqlCommand("UPDATE tb_mast_service SET kra_locked='0' WHERE title='" & item.Value & "' and project='" & sel_project.Text & "' and role_month='" & sel_month.Text & "' and role_year='" & sel_year.Text & "' ", Connection)
                    Command.ExecuteNonQuery()
                Next
                For Each item As ListItem In lst_selected.Items
                    Command = New MySqlCommand("UPDATE tb_mast_service SET kra_locked='1' WHERE title='" & item.Value & "' and project='" & sel_project.Text & "' and role_month='" & sel_month.Text & "' and role_year='" & sel_year.Text & "' ", Connection)
                    Command.ExecuteNonQuery()
                Next
            End If
            Connection.Close()
            lblStatus.Text = "Successfully Updated"
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub btnGoal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoal.Click
        Try
            Dim objSupport As New Support.Common
            sel_project.Text = cboProject.SelectedValue
            sel_month.Text = objSupport.GetMonth(ddlMonth.SelectedValue)
            sel_year.Text = objSupport.GetYear(ddlMonth.SelectedValue)
            lst_all.Items.Clear()
            lst_selected.Items.Clear()
            If cboProject.SelectedValue = "0" Then
                lbl_unlocked.Text = "Unlocked Projects"
                lbl_locked.Text = "Locked Projects"
                bindProjects()
            Else
                lbl_project.Text = "Title specific lock status for " & cboProject.SelectedItem.Text
                sel_project.Text = cboProject.SelectedValue
                lbl_unlocked.Text = "Unlocked Titles"
                lbl_locked.Text = "Locked Titles"
                bindTitles()
            End If
            objSupport = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub bindProjects()
        Try
            Dim objSupport As New Support.Common
            Dim objControl As New Support.DataControl
            Connection.Open()
            strSQL = "SELECT project, PROJ_NAME, sum(kra_locked) " & _
                     "from(tb_mast_service, tb_master_project) " & _
                     "where PROJ_ID_PK=project and role_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and role_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'" & _
                     "group by project " & _
                     "order by PROJ_NAME"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()

            While Reader.Read()
                If Reader(2) = "0" Then
                    lst_all.Items.Add(New ListItem(Reader(1), Reader(0)))
                Else
                    lst_selected.Items.Add(New ListItem(Reader(1), Reader(0)))
                End If
            End While
            objControl.SortListControl(lst_all, True)
            objControl.SortListControl(lst_selected, True)
            Connection.Close()
            objControl = Nothing
            objSupport = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub bindTitles()
        Try
            Dim objSupport As New Support.Common
            Dim objControl As New Support.DataControl
            Connection.Open()
            strSQL = "SELECT Title, TITL_NAME, kra_locked " & _
                     "from tb_mast_service, tb_master_title " & _
                     "where TITL_ID_PK=Title and role_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and role_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and project='" & cboProject.SelectedValue & "' " & _
                     "group by Title " & _
                     "order by TITL_NAME"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()

            While Reader.Read()
                If Reader(2) = "0" Then
                    lst_all.Items.Add(New ListItem(Reader(1), Reader(0)))
                Else
                    lst_selected.Items.Add(New ListItem(Reader(1), Reader(0)))
                End If
            End While
            objControl.SortListControl(lst_all, True)
            objControl.SortListControl(lst_selected, True)
            Connection.Close()
            objControl = Nothing
            objSupport = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub btn_moveall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_moveall.Click
        Try
            Dim objControl As New Support.DataControl
            For Each item As ListItem In lst_all.Items
                lst_selected.Items.Add(New ListItem(item.Text, item.Value))
            Next

            lst_all.Items.Clear()

            objControl.SortListControl(lst_all, True)
            objControl.SortListControl(lst_selected, True)
            objControl = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub btn_moveone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_moveone.Click
        Try
            Dim objControl As New Support.DataControl
            For Each item As ListItem In lst_all.Items
                If item.Selected = True Then
                    lst_selected.Items.Add(New ListItem(item.Text, item.Value))
                End If
            Next
            For i = lst_all.Items.Count - 1 To 0 Step -1
                If lst_all.Items.Item(i).Selected Then
                    lst_all.Items.RemoveAt(i)
                End If
            Next
            objControl.SortListControl(lst_all, True)
            objControl.SortListControl(lst_selected, True)
            objControl = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub btn_removeone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_removeone.Click
        Try
            Dim objControl As New Support.DataControl
            For Each item As ListItem In lst_selected.Items
                If item.Selected = True Then
                    lst_all.Items.Add(New ListItem(item.Text, item.Value))
                End If
            Next
            For i = lst_selected.Items.Count - 1 To 0 Step -1
                If lst_selected.Items.Item(i).Selected Then
                    lst_selected.Items.RemoveAt(i)
                End If
            Next
            objControl.SortListControl(lst_all, True)
            objControl.SortListControl(lst_selected, True)
            objControl = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

    Private Sub btn_removeall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_removeall.Click
        Try
            Dim objControl As New Support.DataControl
            For Each item As ListItem In lst_selected.Items
                lst_all.Items.Add(New ListItem(item.Text, item.Value))
            Next
            lst_selected.Items.Clear()
            objControl.SortListControl(lst_all, True)
            objControl.SortListControl(lst_selected, True)
            objControl = Nothing
        Catch ex As Exception
            lblError.Text = "Error occured"
        End Try
    End Sub

End Class
