Imports MySql.Data.MySqlClient

Partial Class kracompletionreport
    Inherits System.Web.UI.Page
    Dim Completed, PendingAppraiser, PendingReviewer, PendingSignoff, NotCompleted, Total As Integer
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Dataset As New DataSet
    Dim Datatable As DataTable
    Dim Dataview As DataView
    Dim strSQL As String
    Dim Appraiser As Integer
    Dim Project As String
    Dim i As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblStatus.Visible = False
        lblError.Visible = False
        If Not IsPostBack Then
            Try
                Connection.Open()
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlmonth, Session("Month"), Session("Year"))
                Connection.Close()
                ddlmonth.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
            Catch ex As Exception
                lblError.Text = ex.Message
            End Try
        End If

    End Sub

    Private Sub BindGrid()
        Try
            Dim Adapter As MySqlDataAdapter
            Dim objSupport As New Support.Common
            Connection.Open()
            strSQL = "call KRACompletionCount(" & objSupport.GetMonth(ddlmonth.SelectedValue) & "," & objSupport.GetYear(ddlmonth.SelectedValue) & ")"
            Adapter = New MySqlDataAdapter(strSQL, Connection)
            Adapter.Fill(Dataset)
            If Session("UserCurRole") = "Project Admin" Then
                'Find related project of the employee(if logged in user is not Admin
                strSQL = "select EmpID, name, AppraiserID, Appraiser, ProjectID, Project from userinfo where Month=" & objSupport.GetMonth(ddlmonth.SelectedValue) & " and Year=" & objSupport.GetYear(ddlmonth.SelectedValue)
                Adapter = New MySqlDataAdapter(strSQL, Connection)
                Adapter.Fill(Dataset)
                Dataview = New DataView(Dataset.Tables(0))
                Appraiser = Session("UserID")
                Dataview.RowFilter = "EmpID = '" & Appraiser & "'"
                Project = ","
                Project = Project & Dataview(0)("ProjectID") & ","
                Dataview.RowFilter = "AppraiserID = '" & Appraiser & "'"
                For i As Integer = 0 To Dataview.Count - 1
                    If InStr(Project, "," & Dataview(0)("ProjectID") & ",") <= 0 Then
                        Project = Project & Dataview(0)("ProjectID") & ","
                    End If
                    recurseSubordinateList(Dataview(i)("EmpID"), 2)
                    Dataview.RowFilter = "AppraiserID = '" & Appraiser & "'"
                Next
                Dataview = Nothing
                Project = Mid(Project, 2, Len(Project) - 2)
                Dataview = Dataset.Tables(0).DefaultView
                Dataview.RowFilter = "ProjectID in (" & Project & ")"
                grdReport.DataSource = Dataview
                grdReport.DataBind()
            Else
                grdReport.DataSource = Dataset.Tables(0).DefaultView
                grdReport.DataBind()
            End If
            Connection.Close()
            Dim DemoGridItem As DataGridItem
            For Each DemoGridItem In grdReport.Items
                For i = 2 To 7
                    If DemoGridItem.Cells(i).Text <> "0" Then
                        DemoGridItem.Cells(i).Text = "<a href='completion_detail.aspx?p=" & DemoGridItem.Cells(1).Text & "&s=" & i - 1 & "&m=" & objSupport.GetMonth(ddlmonth.SelectedValue) & "&y=" & objSupport.GetYear(ddlmonth.SelectedValue) & "' target='_blank'>" & DemoGridItem.Cells(i).Text & "</a>"
                    End If
                Next
            Next
            objSupport = Nothing
            lnkExport.Visible = True
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub
    Sub recurseSubordinateList(ByVal empID As String, ByVal Level As Integer)
        Try
            Dataview.RowFilter = "AppraiserID =" & empID
            For i As Integer = 0 To Dataview.Count - 1
                If InStr(Project, "," & Dataview(0)("ProjectID") & ",") <= 0 Then
                    Project = Project & Dataview(0)("ProjectID") & ","
                End If
                recurseSubordinateList(Dataview(i)("EmpID"), Level + 1)
                Dataview.RowFilter = "AppraiserID =" & empID
            Next
        Catch ex As Exception
            'Error message
        End Try
    End Sub
    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        grdReport.CurrentPageIndex = 0
        BindGrid()
    End Sub

    Private Sub grdReport_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdReport.PageIndexChanged
        grdReport.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkExport.Click
        KRAClass.ExportDataGrid(grdReport, "KRA_Completion_Count.xls")
        'export()
    End Sub

    Private Sub grdReport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdReport.ItemDataBound
        e.Item.Cells(1).Visible = False
        If e.Item.ItemType = ListItemType.Header Then
            Completed = 0
            PendingAppraiser = 0
            PendingReviewer = 0
            PendingSignoff = 0
            NotCompleted = 0
            Total = 0
        ElseIf e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Completed = Completed + CInt(e.Item.Cells(2).Text)
            PendingAppraiser = PendingAppraiser + CInt(e.Item.Cells(3).Text)
            PendingReviewer = PendingReviewer + CInt(e.Item.Cells(4).Text)
            PendingSignoff = PendingSignoff + CInt(e.Item.Cells(5).Text)
            NotCompleted = NotCompleted + CInt(e.Item.Cells(6).Text)
            Total = Total + CInt(e.Item.Cells(7).Text)
            e.Item.Cells(8).Text = e.Item.Cells(8).Text & "%"
        ElseIf e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(0).Text = "Total"
            'If Completed <> 0 Then
            '    e.Item.Cells(2).Text = "<a href='completion_detail.aspx?s=1&m=" & getMonth(ddlmonth.SelectedValue) & "&y=" & getYear(ddlmonth.SelectedValue) & "' target='_blank'>" & Completed & "</a>"
            'Else
            e.Item.Cells(2).Text = Completed
            'End If
            'If PendingAppraiser <> 0 Then
            '    e.Item.Cells(3).Text = "<a href='completion_detail.aspx?s=2&m=" & getMonth(ddlmonth.SelectedValue) & "&y=" & getYear(ddlmonth.SelectedValue) & "' target='_blank'>" & PendingAppraiser & "</a>"
            'Else
            e.Item.Cells(3).Text = PendingAppraiser
            'End If
            'If PendingReviewer <> 0 Then
            '    e.Item.Cells(4).Text = "<a href='completion_detail.aspx?s=3&m=" & getMonth(ddlmonth.SelectedValue) & "&y=" & getYear(ddlmonth.SelectedValue) & "' target='_blank'>" & PendingReviewer & "</a>"
            'Else
            e.Item.Cells(4).Text = PendingReviewer
            'End If
            'If PendingSignoff <> 0 Then
            '    e.Item.Cells(5).Text = "<a href='completion_detail.aspx?s=4&m=" & getMonth(ddlmonth.SelectedValue) & "&y=" & getYear(ddlmonth.SelectedValue) & "' target='_blank'>" & PendingSignoff & "</a>"
            'Else
            e.Item.Cells(5).Text = PendingSignoff
            'End If
            'If NotCompleted <> 0 Then
            '    e.Item.Cells(6).Text = "<a href='completion_detail.aspx?s=5&m=" & getMonth(ddlmonth.SelectedValue) & "&y=" & getYear(ddlmonth.SelectedValue) & "' target='_blank'>" & NotCompleted & "</a>"
            'Else
            e.Item.Cells(6).Text = NotCompleted
            'End If
            'If Total <> 0 Then
            '    e.Item.Cells(7).Text = "<a href='completion_detail.aspx?s=6&m=" & getMonth(ddlmonth.SelectedValue) & "&y=" & getYear(ddlmonth.SelectedValue) & "' target='_blank'>" & Total & "</a>"
            '    e.Item.Cells(8).Text = Math.Round(100 * (Completed / Total)) & "%"
            'Else
            e.Item.Cells(7).Text = Total
            If Total <> 0 Then e.Item.Cells(8).Text = Math.Round(100 * (Completed / Total)) & "%"
            'End If
        End If
    End Sub
End Class
