Imports MySql.Data.MySqlClient

Partial Class Krareport
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String
    
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents display As System.Web.UI.WebControls.Label
    Protected WithEvents txt_empid As System.Web.UI.WebControls.TextBox
    Protected WithEvents emp_oldpass As System.Web.UI.WebControls.TextBox
    Protected WithEvents display_info As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents emp_newpass As System.Web.UI.WebControls.TextBox
    Protected WithEvents CompareValidator1 As System.Web.UI.WebControls.CompareValidator
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents emp_repass As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblError.Text = ""
        Try
            If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Director" Then
                txtempid.Enabled = True
                txtempname.Enabled = True
                combotitle.Enabled = True
                comboProj.Enabled = True
            ElseIf Session("UserCurRole") = "Project Admin" Or Session("UserCurRole") = "Viewer" Then
                txtempid.Enabled = True
                txtempname.Enabled = True
                combotitle.Enabled = True
                comboProj.Enabled = False
            Else
                txtempid.Enabled = True
                txtempname.Enabled = True
                combotitle.Enabled = False
                comboProj.Enabled = False
            End If

            If Not IsPostBack Then
                Try
                    Connection.Open()
                    Dim objControl As New Support.DataControl
                    objControl.FillDropDown(Connection, comboProj, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                    objControl.FillDropDown(Connection, combotitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                    objControl = Nothing
                    Connection.Close()
                Catch ex3 As Exception
                    lblError.Text = ex3.Message
                End Try
                BindGrid()
            End If
        Catch ex3 As Exception
            'lblError.Text = ex3.Message
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Public Sub BindGrid(Optional ByVal EmpID As Integer = 0)
        Dim Project, Title, Emp_ID, EmpName As String
        Try
            If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Director" Then
                Project = comboProj.SelectedValue
                Title = combotitle.SelectedValue
                Emp_ID = txtempid.Text
                EmpName = txtempname.Text
            ElseIf Session("UserCurRole") = "Project Admin" Or Session("UserCurRole") = "Viewer" Then
                Project = Session("UserProjectID")
                Title = combotitle.SelectedValue
                Emp_ID = txtempid.Text
                EmpName = txtempname.Text
            Else
                Project = Session("UserProjectID")
                Title = "0"
                Emp_ID = txtempid.Text
                EmpName = txtempname.Text
            End If
            'call EmpListwithAppraisee(empid,empname,appraiser,title,project,kmonth,kyear)
            Connection.Open()
            strSQL = "call EmpListwithAppraisee('" & Emp_ID & "','" & EmpName & "','','" & Title & "','" & Project & "','" & Session("Month") & "','" & Session("Year") & "')"
            Dim myDataset As New DataSet
            Dim Adapter As New MySqlDataAdapter(strsql, Connection)
            Adapter.Fill(myDataset)
            grdEmployee.DataSource = myDataset.Tables(0).DefaultView
            grdEmployee.DataBind()
            Connection.Close()
        Catch ex3 As Exception
            If ex3.Message = "Cannot find table 0." Then
                lblError.Text = "Employee data not exist for " & MonthName(Session("Month")) & " '" & Session("Year")
            Else
                lblError.Text = ex3.Message
            End If
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Private Sub grdEmployee_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.ItemCommand
        If e.CommandName = "getScore" Then
            lblInfo.Text = "KRA Score for <b>" & e.Item.Cells(1).Text & "</b>(" & e.Item.Cells(4).Text & ")"
            getScore(e.Item.Cells(4).Text)
            'e.Item.CssClass = "selected"
        End If
    End Sub

    Private Sub grdEmployee_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdEmployee.ItemDataBound
        'e.Item.CssClass = ""
    End Sub

    Private Sub grdEmployee_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdEmployee.PageIndexChanged
        grdEmployee.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        grdEmployee.CurrentPageIndex = 0
        BindGrid()
        grdScore.DataSource = Nothing
        grdScore.DataBind()
    End Sub

    Private Sub getScore(ByVal EmpID As String)
        'Dim EmpID As Integer
        Dim myDataset As New DataSet
        Dim strCond As String = ""
        Dim canView As Boolean = False
        'lblError.Visible = False
        Try
            If Not IsPostBack Then
                'pnlFinalScore.Visible = False
                'If Request.QueryString("id") <> "" Then
                '    EmpID = Request.QueryString("id")
                'Else
                '    If Session("UserCurRole") <> "Administrator" Then
                '        EmpID = Session("UserID")
                '    End If
                'End If
                If Session("UserCurRole") <> "User" Then
                    'pnlFinalScore.Visible = True
                End If
            Else
                'If txtempid.Text <> "" Then
                '    EmpID = txtempid.Text
                'End If
            End If
            Connection.Open()
            'Dim chkRights As New clsGeneral
            If (EmpID.ToString = Session("UserID")) Or Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Director" Or Session("UserCurRole") = "Super Admin" Then
                canView = True
            ElseIf isManager(Connection, EmpID, Session("UserID"), Session("Month"), Session("Year")) Then
                canView = True
            End If
            If canView Then
                Dim isValidEmployee As String
                Dim objQuery As New Support.QuerySet
                isValidEmployee = objQuery.SelectAValue(Connection, "count(*)", "tb_mast_employee", "M_EMPL_ID_PK='" & EmpID & "'")
                objQuery = Nothing
                If isValidEmployee = "0" Then
                    lblError.Text = "Employee ID does not exists"
                    'lblError.Visible = True
                Else
                    'strSQL = "select EmpID, Name, Title, Project from userinfo where EmpID='" & EmpID & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'"
                    'Command = New MySqlCommand(strSQL, Connection)
                    'Reader = Command.ExecuteReader()
                    'If Reader.HasRows Then
                    '    Reader.Read()
                    '    'lblEmpID.Text = Reader("EmpID")
                    '    'lblEmpName.Text = Reader("Name")
                    '    'lblTitle.Text = Reader("Title")
                    '    'lblProject.Text = Reader("Project")
                    '    Reader.Close()
                    BindScore(EmpID)
                    'Else
                    '    lblError.Visible = True
                    '    lblError.Text = "Employee data not avalilable for current month"
                    'End If
                End If
            Else
                'lblInfo.Text = ""
                lblError.Text = "You are not authorized to view this report"
                grdScore.DataSource = Nothing
                grdScore.DataBind()
            End If
            Connection.Close()
        Catch Ex As Exception
            'lblError.Text = Ex.Message
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Private Sub BindScore(Optional ByVal EmpId As Integer = 0)
        Dim myDataset As New DataSet
        'kraConnection.Open()
        Try
            Dim selMonth As Integer = Microsoft.VisualBasic.DateAndTime.Month(Now) - 1
            Dim selYear As Integer = Year(Now)
            selYear = selYear - 1

            strSQL = "call ConsolidatedFinalScore(" & EmpId & "," & selMonth & "," & selYear & ")"
            'Response.Write(strSQL)
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            grdScore.DataSource = myDataset.Tables(0).DefaultView
            grdScore.DataBind()
            Dim DemoGridItem As DataGridItem
            For Each DemoGridItem In grdScore.Items
                DemoGridItem.Cells(3).Text = MonthName(DemoGridItem.Cells(0).Text, True) & "-" & DemoGridItem.Cells(1).Text
                If LCase(DemoGridItem.Cells(7).Text) <> "completed" Then
                    'DemoGridItem.Cells(6).Text = DemoGridItem.Cells(7).Text
                    'DemoGridItem.Cells(6).ForeColor = Color.Gray
                    'DemoGridItem.Cells(8).ForeColor = Color.WhiteSmoke
                    'DemoGridItem.Cells(8).Text = ""

                    CType(DemoGridItem.Cells(9).Controls(0), LinkButton).Text = DemoGridItem.Cells(7).Text
                    CType(DemoGridItem.Cells(9).Controls(0), LinkButton).Enabled = False
                    CType(DemoGridItem.Cells(9).Controls(0), LinkButton).CssClass = "disabled"
                    DemoGridItem.Cells(8).ForeColor = Color.WhiteSmoke
                    DemoGridItem.Cells(8).Text = ""
                End If
            Next
            'pnlFinalScore.Visible = True
            'grdScore.Visible = True
            'kraConnection.Close()
        Catch Ex As Exception
            'Response.Write(Ex.Message)
            'lblError.Text = Ex.Message
            'kraConnection.Close()
        End Try
    End Sub

    Private Sub grdScore_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdScore.ItemCommand
        If e.CommandName = "getRating" Then
            Session("ReportMonth") = e.Item.Cells(0).Text
            Session("ReportYear") = e.Item.Cells(1).Text
            Session("ReportUserID") = e.Item.Cells(2).Text
            Response.Redirect("krareportdisplay.aspx")
        End If
    End Sub
End Class
