Imports MySql.Data.MySqlClient
Imports System.Data.OleDb
Imports System.Text
Imports System.IO

Partial Class exceldb
    Inherits System.Web.UI.Page
    Dim ApplicationPath As String
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim oleConnection As OleDbConnection
    Dim oleCommand As OleDbCommand
    Dim oleReader As OleDbDataReader
    Dim strSQL As String
    Dim dsTitle As DataSet
    Dim dsProject As DataSet
    Dim dsParameter As DataSet
    Dim dsStatus As DataSet
    Dim DataAdapter As MySqlDataAdapter
    Dim dataRow() As DataRow
    Dim SaveFolder As String = "files"
    Dim EmpSaveFile As String = "Employee.xls"
    Dim EmpErrorFile As String = "Employee_Error.csv"
    Dim GoalSaveFile As String = "Goalsheet.xls"
    Dim GoalErrorFile As String = "Goalsheet_Error.csv"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblMonth As System.Web.UI.WebControls.Label
    Protected WithEvents comboMonth As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtYear As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        lblError.Text = ""
        lblStatus.Text = ""
        Try
            ApplicationPath = Server.MapPath(SaveFolder)
            'lnkUploadEmployee.Attributes.Add("onclick", "return confirm('This will delete the Employee Database.\nYou cannot revert back this.\nAre you sure you want to proceed?');")
            lnkClearGoalsheet.Attributes.Add("onclick", "return confirm('Are you sure you want to delete the selected goalsheet?');")
            If Not IsPostBack Then
                ddlGoalMonth.Items.Item(Session("Month")).Selected = True
                ddlEmpMonth.Items.Item(Session("Month")).Selected = True
                txtGoalYear.Text = Session("Year")
                txtEmpYear.Text = Session("Year")

                lnkGoalTemplate.HRef = SaveFolder & "/Goalsheet_Template.xls"
                lnkGoalError.HRef = SaveFolder & "/" & GoalErrorFile
                lnkEmpTemplate.HRef = SaveFolder & "/Employee_Template.xls"
                lnkEmpError.HRef = SaveFolder & "/" & EmpErrorFile
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Error Occured", Connection, Session("CurUserRole"))
        End Try
    End Sub

    Private Sub ProjectTitleFill(ByVal Filename As String, ByVal Sheetname As String, ByVal ProjectField As DropDownList, ByVal TitleField As DropDownList)
        Try
            oleConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & Filename & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
            oleConnection.Open()
            oleCommand = New OleDbCommand("select DISTINCT Project from [" & Sheetname & "$]", oleConnection)
            oleReader = oleCommand.ExecuteReader()

            Connection.Open()
            Command = New MySqlCommand("select * from tb_master_project", Connection)
            dsProject = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsProject)

            ProjectField.Items.Clear()
            ProjectField.Items.Add(New ListItem("All", "All"))
            While oleReader.Read()
                For Each row As DataRow In dsProject.Tables(0).Rows
                    If Not IsDBNull(oleReader("Project")) AndAlso row.Item("PROJ_NAME").ToString.ToLower = oleReader("Project").ToString.Trim.ToLower Then
                        ProjectField.Items.Add(New ListItem(row.Item("PROJ_NAME"), row.Item("PROJ_ID_PK")))
                        Exit For
                    End If
                Next
            End While
            oleReader.Close()

            oleCommand = New OleDbCommand("select DISTINCT Title from [" & Sheetname & "$]", oleConnection)
            oleReader = oleCommand.ExecuteReader()

            Command = New MySqlCommand("select * from tb_master_title", Connection)
            dsTitle = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsTitle)

            TitleField.Items.Clear()
            TitleField.Items.Add(New ListItem("All", "All"))
            While oleReader.Read()
                For Each row As DataRow In dsTitle.Tables(0).Rows
                    If Not IsDBNull(oleReader("Title")) AndAlso row.Item("TITL_NAME").ToString.ToLower = oleReader("Title").ToString.Trim.ToLower Then
                        TitleField.Items.Add(New ListItem(row.Item("TITL_NAME"), row.Item("TITL_ID_PK")))
                        Exit For
                    End If
                Next
            End While

            oleConnection.Close()
            Connection.Close()
        Catch ex As Exception
            'lblError.Text = ex.Message
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

#Region "Employee Upload"

    Private Sub btnEmployee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployee.Click
        UploadEmployeeData()
        lnkErrorGoalsheet.Visible = False
        lnkCopyEmployee.Visible = True
        lnkErrorEmployee.Visible = False
    End Sub

    Private Sub lnkUploadEmployee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkUploadEmployee.Click
        pnlEmpCopy.Visible = False
        pnlEmpUpload.Visible = True
        ProjectTitleFill(EmpSaveFile, "Employee", ddlEmpProject, ddlEmpTitle)
    End Sub

    Private Sub UploadEmployeeData()
        Dim EmpID As String = ""
        Dim Flag As String = ""
        Dim objQuery As New Support.QuerySet
        Dim objSupport As New Support.Common
        Dim objCrypto As New Support.Crypto
        Dim ProjectID As String = ""
        Dim TitleID As String = ""
        Dim StatusID As String = ""
        Dim NestingDate As String = ""
        Dim curupdated As Integer
        Dim curinserted As Integer
        Dim gloupdated As Integer
        Dim gloinserted As Integer
        Dim curProject As String = ""
        Dim curTitle As String = ""
        Dim curStatus As String = ""

        Try
            oleConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & EmpSaveFile & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
            Connection.Open()
            Command = New MySqlCommand("select * from tb_master_project", Connection)
            dsProject = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsProject)
            Command = New MySqlCommand("select * from tb_master_title", Connection)
            dsTitle = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsTitle)
            Command = New MySqlCommand("select * from tb_mast_empstatus", Connection)
            dsStatus = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsStatus)

            oleConnection.Open()
            strSQL = "select * from [Employee$] where Name<>'' "
            If ddlEmpTitle.SelectedItem.Text <> "All" Then
                strSQL &= " and Project='" & ddlEmpProject.SelectedItem.Text & "'"
            End If
            If ddlEmpTitle.SelectedItem.Text <> "All" Then
                strSQL &= " and Title='" & ddlEmpTitle.SelectedItem.Text & "'"
            End If
            strSQL &= " order by Project, Title"
            oleCommand = New OleDbCommand(strSQL, oleConnection)
            oleReader = oleCommand.ExecuteReader()
            While (oleReader.Read())
                EmpID = oleReader(0)
                If curProject <> oleReader("Project").Trim Then
                    dataRow = dsProject.Tables(0).Select("PROJ_NAME='" & oleReader("Project").Trim & "'")
                    If dataRow.Length > 0 Then ProjectID = dataRow(0).Item(0)
                End If
                If curTitle <> oleReader("Title").Trim Then
                    dataRow = dsTitle.Tables(0).Select("TITL_NAME='" & oleReader("Title").Trim & "'")
                    If dataRow.Length > 0 Then TitleID = dataRow(0).Item(0)
                End If
                If curStatus <> oleReader("Status").Trim Then
                    dataRow = dsStatus.Tables(0).Select("empstat_name='" & oleReader("Status").Trim & "'")
                    If dataRow.Length > 0 Then StatusID = dataRow(0).Item(0)
                End If
                If TitleID = "" Then TitleID = 0
                If StatusID = "" Then StatusID = 0
                If Not IsDBNull(oleReader("Nesting Date")) Then
                    NestingDate = "'" & objSupport.MSDate(oleReader("Nesting Date")) & "'"
                Else
                    NestingDate = "\N"
                End If
                Flag = objQuery.SelectAValue(Connection, "count(*)", "tb_mast_employee", "M_EMPL_ID_PK='" & EmpID & "'")
                If Flag <> "0" Then
                    objQuery.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_NAME='" & objSupport.FormatData(oleReader("Name")) & "', M_EMPL_NESTINGDATE=" & NestingDate, "M_EMPL_ID_PK='" & EmpID & "'")
                    gloupdated = gloupdated + 1
                Else
                    objQuery.InsertValue(Connection, "tb_mast_employee", "M_EMPL_ID_PK,M_EMPL_NAME,M_EMPL_PASSWORD,M_EMPL_ENCRYPT,M_EMPL_NESTINGDATE", "'" & EmpID & "', '" & objSupport.FormatData(oleReader("Name")) & "', '" & objCrypto.Encrypt("password") & "', '1'," & NestingDate)
                    gloinserted = gloinserted + 1
                End If
                Flag = objQuery.SelectAValue(Connection, "count(*)", "tb_tran_employee", "M_EMPL_ID_PK='" & EmpID & "' and M_EMPL_MONTH='" & ddlEmpMonth.SelectedValue & "' and M_EMPL_YEAR='" & txtEmpYear.Text & "'")
                If Flag <> "0" Then
                    objQuery.UpdateValue(Connection, "tb_tran_employee", "M_EMPL_PROJECT='" & ProjectID & "' , M_EMPL_TITLE='" & TitleID & "', M_APPRAISER_ID='" & oleReader("Appraiser ID") & "', M_EMPL_MODE='" & StatusID & "'", "M_EMPL_ID_PK='" & EmpID & "'")
                    curupdated = curupdated + 1
                Else
                    objQuery.InsertValue(Connection, "tb_tran_employee", "M_EMPL_ID_PK,M_EMPL_PROJECT,M_EMPL_TITLE,M_APPRAISER_ID,M_EMPL_MODE,M_EMPL_MONTH,M_EMPL_YEAR", "'" & EmpID & "', '" & ProjectID & "', '" & TitleID & "', '" & oleReader("Appraiser ID") & "', '" & StatusID & "', '" & ddlEmpMonth.SelectedValue & "', '" & txtEmpYear.Text & "'")
                    curinserted = curinserted + 1
                End If
                curProject = oleReader("Project").Trim
                curTitle = oleReader("Title").Trim
                curStatus = oleReader("Status").Trim
                lblStatus.Text = EmpID
            End While
            objCrypto = Nothing
            objSupport = Nothing
            objQuery = Nothing
            oleConnection.Dispose()
            Connection.Close()
            UpdateEmployeeEmail()
            lblStatus.Text = "DB Transfer done successfully. " & curinserted & " records added and " & curupdated & " records updated for selected month. " & gloinserted & " new records added."
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload terminated: Error while uploading data", Connection, Session("CurUserRole"))
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Private Sub UpdateEmployeeEmail()
        Dim objQuery As New Support.QuerySet
        Dim dsEmail As New DataSet
        Dim cdmConnection As New MySqlConnection(ConfigurationManager.ConnectionStrings("cdm_connection").ConnectionString.ToString())
        cdmConnection.Open()
        Command = New MySqlCommand("SELECT Emp_Code, Office_Email FROM tbl_cdm_emp_mas where Office_Email<>''", cdmConnection)
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsEmail)

        Dim dsUser As New DataSet
        If Connection.State = ConnectionState.Closed Then Connection.Open()
        Command = New MySqlCommand("SELECT M_EMPL_ID_PK, M_EMPL_EMAILID FROM tb_mast_employee", Connection)
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsUser)

        For Each userRow As DataRow In dsUser.Tables(0).Rows
            For Each emailRow As DataRow In dsEmail.Tables(0).Rows
                If userRow.Item(0) = emailRow.Item(0) Then
                    If emailRow.Item(1) <> "" Then
                        objQuery.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_EMAILID='" & emailRow.Item(1) & "'", "M_EMPL_ID_PK='" & emailRow.Item(0) & "'")
                    End If
                    Exit For
                End If
            Next
        Next
        Connection.Close()
        cdmConnection.Close()
    End Sub

    Private Sub lnkCopyEmployee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkCopyEmployee.Click
        pnlEmpCopy.Visible = True
        pnlEmpUpload.Visible = False
        lnkErrorEmployee.Visible = False
    End Sub

    Private Sub btnCopyEmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyEmp.Click
        Try
            lnkErrorEmployee.Visible = False
            If Not File1.PostedFile Is Nothing And File1.PostedFile.ContentLength > 0 Then
                Dim fn As String = System.IO.Path.GetFileName(File1.PostedFile.FileName)
                If Right(fn, 3) <> "xls" Then
                    lblStatus.Text = "Please select a valid file to upload"
                    lblStatus.Visible = True
                    Exit Sub
                End If
                Dim SaveLocation As String = ApplicationPath & "\" & EmpSaveFile & ""
                If File.Exists(SaveLocation) Then File.Delete(SaveLocation)
                File1.PostedFile.SaveAs(SaveLocation)
                CheckEmployeeSheet()
                ProjectTitleFill(EmpSaveFile, "Employee", ddlEmpProject, ddlEmpTitle)
            Else
                lblStatus.Text = "Please select a file to upload."
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Connectivity error occured", , Session("CurUserRole"))
        End Try
    End Sub

    Private Sub CheckEmployeeSheet()
        Dim oleConnection As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & EmpSaveFile & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
        Dim oleCommand As OleDbCommand
        Dim oleReader As OleDbDataReader
        Dim ErrorStreamWriter As StreamWriter
        Dim colCount As Integer = 6
        Dim ErrorFound As Boolean = False
        Dim ErrorMessage As String = ""
        Dim Count As Integer
        Dim ErrorCount As Integer = 0
        Dim TotalCount As Integer = 1
        Dim RowData As String
        Dim ErrorFileName As String = ""

        Try
            Connection.Open()
            Command = New MySqlCommand("select * from tb_master_project", Connection)
            dsProject = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsProject)

            Command = New MySqlCommand("select * from tb_master_title", Connection)
            dsTitle = New DataSet
            DataAdapter = New MySqlDataAdapter(Command)
            DataAdapter.Fill(dsTitle)
            Connection.Close()
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload Terminated! This may be due to Problem in server connectivity. Please contact your administrator.", Connection, Session("CurUserRole"))
            lnkErrorEmployee.Visible = False
            Exit Sub
        End Try

        Try
            ErrorFileName = ApplicationPath & "\" & EmpErrorFile
            If File.Exists(ErrorFileName) Then File.Delete(ErrorFileName)
            oleConnection.Open()
            strSQL = "select * from [Employee$]"
            oleCommand = New OleDbCommand(strSQL, oleConnection)
            oleReader = oleCommand.ExecuteReader()
        Catch ex As Exception
            lblError.Text = "Upload Terminated! Sheet name may be Incorrect. Make sure the sheet name is 'Employee'."
            lnkErrorGoalsheet.Visible = False
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            Exit Sub
        End Try
        ErrorStreamWriter = File.AppendText(ErrorFileName)
        RowData = ""
        For Count = 0 To colCount
            RowData = RowData & """" & oleReader.GetName(Count) & ""","
        Next
        ErrorStreamWriter.WriteLine(RowData & """Error Details"",""Row Number""")

        Try
            While (oleReader.Read())
                RowData = ""
                ErrorMessage = ""

                dataRow = dsTitle.Tables(0).Select("TITL_NAME='" & oleReader("Title") & "'")
                If dataRow.Length = 0 Then ErrorMessage &= "Invalid Title; "

                dataRow = dsProject.Tables(0).Select("PROJ_NAME='" & oleReader("Project") & "'")
                If dataRow.Length = 0 Then ErrorMessage &= "Invalid Project; "

                For Count = 0 To colCount - 1 'Last field nesting date can be null
                    If IsDBNull(oleReader(Count)) Then
                        ErrorMessage &= oleReader.GetName(Count) & " Missing; "
                        RowData = RowData & """"","
                    Else
                        RowData = RowData & """" & oleReader(Count) & ""","
                    End If
                Next
                If Not IsDBNull(oleReader("Nesting Date")) Then
                    If Not IsDate(CDate(oleReader("Nesting Date").ToString)) Then
                        ErrorMessage &= "Invalid Date Format; "
                    End If
                End If
                If ErrorMessage <> "" Then
                    ErrorStreamWriter.WriteLine(RowData & """" & ErrorMessage & """,""" & TotalCount + 1 & """")
                    ErrorFound = True
                    ErrorCount = ErrorCount + 1
                End If
                TotalCount = TotalCount + 1
            End While
            ErrorStreamWriter.Close()
            oleConnection.Close()
            If ErrorFound Then
                lblError.Text = ErrorCount & " Out of " & TotalCount & " records contains error "
                lnkErrorEmployee.Visible = True
                pnlEmpCopy.Visible = True
                pnlEmpUpload.Visible = False
            Else
                lblStatus.Text = "File is ready for upload."
                pnlEmpCopy.Visible = False
                pnlEmpUpload.Visible = True
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload Terminated! This may be due to Incorrect file structure. Please check the upload file.", Connection, Session("CurUserRole"))
            lnkErrorEmployee.Visible = False
            pnlEmpUpload.Visible = False
            ErrorStreamWriter.Close()
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

#End Region

#Region "Goalsheet Upload"

    Private Sub btnGoal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoal.Click
        UploadGoalsheet()
        lnkErrorGoalsheet.Visible = False
        lnkCopyGoalsheet.Visible = True
        lnkErrorEmployee.Visible = False
    End Sub

    Private Sub lnkClearGoalsheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkClearGoalsheet.Click
        Dim strCond As String
        Dim KRACount As String
        Dim objQuery As New Support.QuerySet
        Try
            strCond = "tran_month='" & ddlGoalMonth.SelectedValue & "' and  tran_year='" & txtGoalYear.Text & "' and  tran_proj='" & ddlGoalProject.SelectedItem.Value & "'"
            If ddlGoalTitle.SelectedItem.Text <> "All" Then
                strCond &= " and tran_title='" & ddlGoalTitle.SelectedItem.Value & "'"
            End If
            Connection.Open()
            KRACount = objQuery.SelectAValue(Connection, "count(*)", "tb_tran_storerating", strCond)
            If KRACount = "0" Then
                strCond = "role_month='" & ddlGoalMonth.SelectedValue & "' and  role_year='" & txtGoalYear.Text & "' and  project='" & ddlGoalProject.SelectedItem.Value & "'"
                If ddlGoalTitle.SelectedItem.Text <> "All" Then
                    strCond = " and title='" & ddlGoalTitle.SelectedItem.Value & "'"
                End If
                objQuery.DeleteValue(Connection, "tb_mast_service", strCond)
                lblStatus.Text = "Data cleared successfully"
            Else
                lblStatus.Text = "KRA entries found for selected options"
            End If
            objQuery = Nothing
            Connection.Close()
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Error Occured", Connection, Session("CurUserRole"))
        End Try
    End Sub

    Private Sub UploadGoalsheet()
        Dim qryApp As String = ""
        Dim count As String
        Dim dataLength As Integer
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim updateCount As Integer = 0
        Dim ErrorFound As Integer = 0
        Dim colName As String = ""
        Dim colData As String = ""
        Dim curProject As String = ""
        Dim curTitle As String = ""
        Dim curProjectID As String = ""
        Dim curTitleID As String = ""
        Dim objQuery As New Support.QuerySet
        Dim cond As String = ""
        Dim colCount As Integer = 16
        'Dim FieldList As String = "Division,project,Title,Parameter,weight,Key_Deter,Weightage,Goal,opr1,Does_not_meet,opr2,Meets_Expectation,opr3,Exceeds_Expectation,opr4,Role_Model,role_month,role_year,kra_locked,goal_approved,updated_on"
        Dim FieldList As String = "project,Title,Parameter,weight,Key_Deter,Weightage,Goal,opr1,Does_not_meet,opr2,Meets_Expectation,opr3,Exceeds_Expectation,opr4,Role_Model,role_month,role_year,kra_locked,goal_approved,updated_on"

        If Session("RatingScale") = "5" Then
            colCount += 2
            FieldList &= ",opr5,PL5"
        End If

        Connection.Open()

        'Command = New MySqlCommand("select * from tb_master_project", Connection)
        'dsProject = New DataSet
        'DataAdapter = New MySqlDataAdapter(Command)
        'DataAdapter.Fill(dsProject)

        'Command = New MySqlCommand("select * from tb_master_title", Connection)
        'dsTitle = New DataSet
        'DataAdapter = New MySqlDataAdapter(Command)
        'DataAdapter.Fill(dsTitle)

        'Command = New MySqlCommand("select * from tb_mast_parameter", Connection)
        'dsParameter = New DataSet
        'DataAdapter = New MySqlDataAdapter(Command)
        'DataAdapter.Fill(dsParameter)

        Try
            cond = " role_month='" & ddlGoalMonth.SelectedValue & "' and role_year='" & txtGoalYear.Text & "'"
            If ddlGoalProject.SelectedItem.Text <> "All" Then
                cond &= " and project='" & ddlGoalProject.SelectedItem.Value & "'"
            End If
            If ddlGoalTitle.SelectedItem.Text <> "All" Then
                cond &= " and Title='" & ddlGoalTitle.SelectedItem.Value & "'"
            End If

            count = objQuery.SelectAValue(Connection, "count(project)", "tb_mast_service", cond)
            If count <> "0" Then
                If ddlGoalProject.SelectedItem.Text = "All" Then
                    lblStatus.Text = "Related entries found for following Projects: " & objQuery.SelectAValue(Connection, "group_concat(distinct PROJ_NAME)", "tb_mast_service, tb_master_project", cond)
                Else
                    lblStatus.Text = "Related entries found for selected Project."
                End If
                Connection.Close()
                Exit Sub
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload Terminated! This may be due to Problem in server connectivity. Please contact your administrator.", Connection, Session("CurUserRole"))
            Exit Sub
        End Try

        Try
            DataAdapter = New MySqlDataAdapter("Select " & FieldList & " from tb_mast_service", Connection)
            Dim CommandBuilder As New MySqlCommandBuilder(DataAdapter)
            Dim myDataSet As New DataSet
            DataAdapter.Fill(myDataSet, "tb_mast_service")
            cond = ""
            If ddlGoalProject.SelectedItem.Text <> "All" Then
                cond = " and [Project]='" & ddlGoalProject.SelectedItem.Text & "'"
            End If
            If ddlGoalTitle.SelectedItem.Text <> "All" Then
                cond = " and [Title]='" & ddlGoalTitle.SelectedItem.Text & "'"
            End If
            oleConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & GoalSaveFile & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
            oleConnection.Open()
            Dim oleDataAdapter As New OleDbDataAdapter("select * from [GoalSheet$] where KRA<>''" & cond, oleConnection)
            Dim xlDataTable As New DataTable
            oleDataAdapter.Fill(xlDataTable)
            oleDataAdapter.Dispose()
            Dim myDataRow As DataRow
            For Each xlDataRow As DataRow In xlDataTable.Rows
                i = i + 1
                myDataRow = myDataSet.Tables("tb_mast_service").NewRow
                For Each col As DataColumn In xlDataTable.Columns
                    j = j + 1
                    If (j <= colCount) Then
                        If IsDBNull((xlDataRow(col.ColumnName))) Then
                            ErrorFound = 1
                            lblStatus.Text = "<br>Process Terminated"
                            lblStatus.Text &= "<br>Null value identified in (Row= " & i + 1 & " Column= " & j & ")"
                            lblStatus.Text &= "<br>Please recheck Excel file and Try Again"
                            Exit For
                        End If
                        colData = CStr(xlDataRow(col.ColumnName)).Trim
                        dataLength = Len(xlDataRow(col.ColumnName))
                        Select Case col.ColumnName
                            'Case "Division"
                            '    myDataRow("Division") = colData

                            Case "Project"
                                If curProject <> xlDataRow("Project") Then
                                    curProjectID = objQuery.SelectAValue(Connection, "PROJ_ID_PK", "tb_master_project", "PROJ_NAME='" & colData & "'")
                                    curProject = xlDataRow("Project")
                                End If
                                myDataRow("project") = curProjectID

                            Case "Title"
                                If curTitle <> xlDataRow("Title") Then
                                    curTitleID = objQuery.SelectAValue(Connection, "TITL_ID_PK", "tb_master_title", "TITL_NAME='" & colData & "'")
                                    curTitle = xlDataRow("Title")
                                End If
                                myDataRow("Title") = curTitleID

                            Case "Goal", "PL1", "PL2", "PL3", "PL4", "PL5"
                                If col.ColumnName = "Goal" Then
                                    colName = "Goal"
                                ElseIf col.ColumnName = "PL1" Then
                                    colName = "Does_not_meet"
                                ElseIf col.ColumnName = "PL2" Then
                                    colName = "Meets_Expectation"
                                ElseIf col.ColumnName = "PL3" Then
                                    colName = "Exceeds_Expectation"
                                ElseIf col.ColumnName = "PL4" Then
                                    colName = "Role_Model"
                                ElseIf col.ColumnName = "PL5" Then
                                    colName = "PL5"
                                End If
                                myDataRow(colName) = colData

                            Case "KRA Weightage"
                                myDataRow("weight") = colData

                            Case "KPI Weightage"
                                myDataRow("Weightage") = colData

                            Case "Opr1", "Opr2", "Opr3", "Opr4", "Opr5"
                                myDataRow(col.ColumnName) = colData

                            Case "KRA"
                                myDataRow("Parameter") = colData.Replace("'", "''")

                            Case "KPI"
                                myDataRow("Key_Deter") = colData.Replace("'", "''")

                        End Select
                    End If
                Next

                Dim objSupport As New Support.Common
                myDataRow("role_month") = ddlGoalMonth.SelectedValue
                myDataRow("role_year") = txtGoalYear.Text
                myDataRow("kra_locked") = "0"
                myDataRow("goal_approved") = "1"
                myDataRow("updated_on") = objSupport.MSDateTime(DateTime.Now)
                objSupport = Nothing

                j = 0
                If (ErrorFound = 1) Then
                    Exit For
                Else
                    updateCount = updateCount + 1
                    myDataSet.Tables("tb_mast_service").Rows.Add(myDataRow)
                End If
            Next
            If (ErrorFound = 0) Then
                DataAdapter.Update(myDataSet, "tb_mast_service")
                DataAdapter.Dispose()
                lblStatus.Text = "DB Transfer done successfully. " & updateCount & " rows added."
            End If
            oleConnection.Dispose()
            Connection.Close()
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload Terminated! This may be due to Problem in server connectivity. Please contact your administrator.", Connection, Session("CurUserRole"))
        End Try
    End Sub

    Private Sub lnkCopyGoalsheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkCopyGoalsheet.Click
        pnlGSCopy.Visible = True
        pnlGSUpload.Visible = False
        lnkErrorGoalsheet.Visible = False
    End Sub

    Private Sub btnCopyGoal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyGoal.Click
        Try
            lnkErrorGoalsheet.Visible = False
            If Not File2.PostedFile Is Nothing And File2.PostedFile.ContentLength > 0 Then
                Dim fn As String = System.IO.Path.GetFileName(File2.PostedFile.FileName)
                If Right(fn, 3) <> "xls" Then
                    lblError.Text = "Please select a valid file to upload"
                    Exit Sub
                End If

                Dim SaveLocation As String = ApplicationPath & "\" & GoalSaveFile & ""
                If File.Exists(SaveLocation) Then File.Delete(SaveLocation)
                File2.PostedFile.SaveAs(SaveLocation)
                CheckGoalsheet()
                ProjectTitleFill(GoalSaveFile, "Goalsheet", ddlGoalProject, ddlGoalTitle)
            Else
                lblError.Text = "Please select a file to upload."
            End If
        Catch ex As Exception
            ErrorCatch(lblError, ex, "Upload Terminated! This may be due to Problem in server connectivity. Please contact your administrator.", , Session("CurUserRole"))
        End Try
    End Sub

    Private Sub CheckGoalsheet()
        Dim oleConnection As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ApplicationPath & "\" & GoalSaveFile & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
        Dim oleCommand As OleDbCommand
        Dim oleReader As OleDbDataReader
        Dim ErrorStreamWriter As StreamWriter
        Dim ErrorFound As Boolean = False
        Dim ErrorMessage As String
        Dim colCount As Integer = 16
        Dim CountTitle As Integer
        Dim CountProject As Integer
        Dim CountParam As Integer
        Dim Count As Integer
        Dim ErrorCount As Integer = 0
        Dim TotalCount As Integer = 1
        Dim RowData As String
        Dim ErrorFileName As String

        If Session("RatingScale") = "5" Then colCount += 2
        Connection.Open()
        Command = New MySqlCommand("select * from tb_master_project", Connection)
        dsProject = New DataSet
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsProject)

        Command = New MySqlCommand("select * from tb_master_title", Connection)
        dsTitle = New DataSet
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsTitle)

        Command = New MySqlCommand("select * from tb_mast_parameter", Connection)
        dsParameter = New DataSet
        DataAdapter = New MySqlDataAdapter(Command)
        DataAdapter.Fill(dsParameter)
        Connection.Close()

        ErrorFileName = ApplicationPath & "\" & GoalErrorFile
        If File.Exists(ErrorFileName) Then File.Delete(ErrorFileName)
        ErrorStreamWriter = File.AppendText(ErrorFileName)
        oleConnection.Open()
        Try
            strSQL = "select * from [GoalSheet$]"
            oleCommand = New OleDbCommand(strSQL, oleConnection)
            oleReader = oleCommand.ExecuteReader()
        Catch ex As Exception
            lblError.Text = "Upload Terminated! Sheet name may be Incorrect. Make sure the sheet name is 'Goalsheet'."
            lnkErrorGoalsheet.Visible = False
            ErrorStreamWriter.Close()
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            Exit Sub
        End Try

        RowData = ""
        For Count = 0 To colCount - 1
            RowData = RowData & """" & oleReader.GetName(Count) & ""","
        Next
        ErrorStreamWriter.WriteLine(RowData & """Error Details"",""Row Number""")
        Try
            While (oleReader.Read())
                ErrorMessage = ""
                RowData = ""
                For Count = 0 To colCount - 1
                    If IsDBNull(oleReader(Count)) Then
                        ErrorMessage &= oleReader.GetName(Count) & " Missing; "
                        RowData = RowData & """"","
                    Else
                        RowData = RowData & """" & oleReader(Count) & ""","
                    End If
                Next
                CountTitle = dsTitle.Tables(0).Compute("count(TITL_ID_PK)", "TITL_NAME='" & oleReader("Title") & "'")
                If CountTitle = 0 Then ErrorMessage = ErrorMessage & "Title Not Found; "

                CountProject = dsProject.Tables(0).Compute("count(PROJ_ID_PK)", "PROJ_NAME='" & oleReader("Project") & "'")
                If CountProject = 0 Then ErrorMessage = ErrorMessage & "Project Not Found; "

                CountParam = dsParameter.Tables(0).Compute("count(mast_parameter_id)", "mast_parameter_name='" & oleReader("KRA") & "'")
                If CountParam = 0 Then ErrorMessage = ErrorMessage & "Parameter Not Found; "

                If ErrorMessage <> "" Then
                    ErrorMessage = Mid(ErrorMessage, 1, Len(ErrorMessage) - 2)
                    ErrorStreamWriter.WriteLine(RowData & """" & ErrorMessage & """,""" & TotalCount + 1 & """")
                    ErrorFound = True
                    ErrorCount = ErrorCount + 1
                End If
                TotalCount += 1
            End While
            ErrorStreamWriter.Close()
            oleConnection.Close()
            If ErrorFound = True Then
                lblError.Text = ErrorCount & " Out of " & TotalCount & " records contains error "
                lnkErrorGoalsheet.Visible = True
                pnlGSCopy.Visible = True
                pnlGSUpload.Visible = False
            Else
                lblStatus.Text = "File is ready for upload."
                pnlGSUpload.Visible = True
                pnlGSCopy.Visible = False
            End If
        Catch ex As Exception
            lblError.Text = "Upload Terminated! This may be due to Incorrect file structure. Please check the upload file."
            lnkErrorGoalsheet.Visible = False
            pnlGSUpload.Visible = False
            ErrorStreamWriter.Close()
            If oleConnection.State = ConnectionState.Open Then oleConnection.Close()
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Private Sub lnkUploadGoalsheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkUploadGoalsheet.Click
        pnlGSCopy.Visible = False
        pnlGSUpload.Visible = True
        ProjectTitleFill(GoalSaveFile, "Goalsheet", ddlGoalProject, ddlGoalTitle)
    End Sub

#End Region

    Protected Sub lnkCheckEmail_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lnkCheckEmail.Click
        UpdateEmployeeEmail()
    End Sub
End Class
