Imports MySql.Data.MySqlClient

Partial Class krarevchange
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String
    Dim i As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Connection.Open()
            If Not IsPostBack Then
                strSQL = "select Name, Project, Title, ProjectID, TitleID from userinfo where EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and year='" & Session("Year") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Reader.Read()
                Session("KRAUserTitleID") = Reader("TitleID")
                Session("KRAUserProjectID") = Reader("ProjectID")
                lblHeader.Text = "Emp No: " & Session("KRAUserID") & "  |  Emp Name: " & Reader("Name") & "  |  Project: " & Reader("Project") & "  |  Title: " & Reader("Title")
                Reader.Close()
                'Connection.Close()
                grdEmployee.Visible = True
                BindGrid()
                'Connection.Open()
                strSQL = "select * from tb_tran_empfeedback where M_FEEDBACK_MONTH='" & Session("Month") & "' and M_FEEDBACK_YEAR='" & Session("Year") & "' and M_FEEDBACK_EMPID='" & Session("KRAUserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                While Reader.Read()
                    txt_appcomm.Text = Reader("M_FEEDBACK_APPCOMM")
                    txtidtec.Text = Reader("M_FEEDBACK_IDENT_TECH")
                    txtidcer.Text = Reader("M_FEEDBACK_IDENT_CERT")
                    txtidskill.Text = Reader("M_FEEDBACK_IDENT_SKILL")
                    If Reader("M_FEEDBACK_REL_EMP") = "Good" Then
                        radiogood.Checked = True
                    ElseIf Reader("M_FEEDBACK_REL_EMP") = "Un - Satisfactory" Then
                        radioun.Checked = True
                    Else
                        radioexcellent.Checked = True
                    End If
                    If Reader("M_FEEDBACK_REL_SUP") = "Good" Then
                        radiogood1.Checked = True
                    ElseIf Reader("M_FEEDBACK_REL_SUP") = "Un - Satisfactory" Then
                        radioun1.Checked = True
                    Else
                        radioexcellent1.Checked = True
                    End If
                    If Reader("M_FEEDBACK_COMP") = "Improved" Then
                        radioexcellent2.Checked = True
                    ElseIf Reader("M_FEEDBACK_COMP") = "No change" Then
                        radiogood2.Checked = True
                    Else
                        radioun2.Checked = True
                    End If
                End While
                Reader.Close()
            End If
            txt_params.Text = FeedbackParam(pnlParam, Session("KRAUserID"), Session("Month"), Session("Year"))
            Dim ParamList() As String
            Dim Parameter() As String
            Dim validation As String = ""
            ParamList = Split(txt_params.Text, ";")
            For i = 0 To ParamList.Length - 2
                Parameter = Split(ParamList(i), ",")
                validation &= "frmvalidator.addValidation('" & CType(pnlParam.FindControl(Parameter(0)), TextBox).ClientID & "','req','Please fill all the parameter comments');" & vbCrLf
            Next
            Session("validation") = validation
            strSQL = "select * from tb_tran_paramfeedback where M_PFEEDBACK_MONTH='" & Session("Month") & "' and M_PFEEDBACK_YEAR='" & Session("Year") & "' and M_PFEEDBACK_EMPID='" & Session("KRAUserID") & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            While Reader.Read()
                For i = 0 To ParamList.Length - 2
                    Parameter = Split(ParamList(i), ",")
                    If Parameter(1) = Reader("M_PFEEDBACK_PARAM") Then
                        CType(pnlParam.FindControl(Parameter(0)), TextBox).Text = Reader("M_PFEEDBACK_COMMENT")
                    End If
                Next
            End While
            Reader.Close()
            Connection.Close()
        Catch ex3 As Exception
            errLabel.Text = ex3.Message
            Connection.Close()
        End Try
    End Sub
    Private Sub BindGrid()
        Dim objQuery As New Support.QuerySet
        Dim myDataset As DataSet
        Dim WeightTotal As Double = 0.0
        Dim ScoreTotal As Double = 0.0
        
        Try
            Dim status As String
            status = objQuery.SelectAValue(Connection, "count(tran_empid)", "tb_tran_storerating", "tran_empid  = " & Session("KRAUserID") & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & " and tran_apptime<>''")
            If status = "0" Then
                errLabel.Text = "Related entries not found"
                errLabel.Visible = True
                Exit Sub
            End If
            GridPanel.Visible = True
            errLabel.Visible = False
            myDataset = objQuery.SelectDataset(Connection, "*", "tb_tran_storerating", "tran_empid  = " & Session("KRAUserID") & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & " and tran_apptime<>''")
            grdEmployee.DataSource = myDataset.Tables("tb_tran_storerating").DefaultView
            grdEmployee.DataBind()
            Dim DemoGridItem As DataGridItem
            Dim Param As String = ""
            For Each DemoGridItem In grdEmployee.Items
                If Param = DemoGridItem.Cells(0).Text Then
                    DemoGridItem.Cells(0).Text = ""
                Else
                    Param = DemoGridItem.Cells(0).Text
                    DemoGridItem.Cells(15).Text = objQuery.SelectAValue(Connection, "round((sum(tran_revscore)/(tran_weightage/100)))", "tb_tran_storerating", "tran_param='" & Param & "' and tran_empid='" & Session("KRAUserID") & "' and tran_month='" & Session("Month") & "' and tran_year='" & Session("Year") & "'")
                End If
                WeightTotal += CDbl(Replace(DemoGridItem.Cells(2).Text, "%", "") / 100)
                ScoreTotal += CDbl(DemoGridItem.Cells(8).Text)
                lblRating.Text = "Review Rating: " & ScoreTotal & "  |  Final Rating: " & Math.Round((ScoreTotal / (WeightTotal * 100)) * 100, 1)
                lblRating.Visible = True
            Next
            objQuery = Nothing
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_EditCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.EditCommand
        grdEmployee.EditItemIndex = CInt(e.Item.ItemIndex)
        Connection.Open()
        BindGrid()
        Connection.Close()
    End Sub

    Private Sub grdEmployee_UpdateCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.UpdateCommand
        Try
            Dim Actual As TextBox = e.Item.Cells(4).FindControl("txtactual")
            If Actual.Text = "" Then
                errLabel.Text = "Rating cannot be blank"
                errLabel.Visible = True
                Exit Sub
            End If
            Actual.Text = Replace(Actual.Text, "$", "")
            Actual.Text = Replace(Actual.Text, ",", "")
            Dim Goal As String = e.Item.Cells(3).Text
            'Dim Length As Integer = Len(Actual1.Text)
            If Actual.Text.EndsWith("%") Then
                If Not Goal.EndsWith("%") Then
                    Actual.Text = Actual.Text.Replace("%", "")
                End If
            Else
                If Goal.EndsWith("%") Then
                    Actual.Text = Actual.Text & "%"
                End If
            End If
            Dim Remark As TextBox = e.Item.Cells(7).FindControl("txtremarks")
            strSQL = ""
            'Dim actual As Double
            Dim weight As Double = CDbl(e.Item.Cells(2).Text.Replace("%", ""))
            Dim intID As String = e.Item.Cells(0).Text
            'Dim doesnotmeet As Double
            'Dim meetexp As Double
            'Dim exceed As Double
            'Dim role As Double
            Dim PL As String = e.Item.Cells(9).Text & "|" & e.Item.Cells(10).Text & "|" & e.Item.Cells(11).Text & "|" & e.Item.Cells(12).Text
            If e.Item.Cells(16).Text <> "" Then
                PL &= "|" & e.Item.Cells(16).Text
            End If
            Dim Opr As String = e.Item.Cells(13).Text
            Dim id As Integer = CInt(e.Item.Cells(14).Text)
            Dim Score As Double
            Dim Rating As Double
            Dim objSupport As New Support.Common
            'Dim arr As String()
            errLabel.Visible = False
            'If (Actual1.Text.IndexOf("%") > -1) Then
            '    actual = CDbl(Actual1.Text.Substring(0, Len(Actual1.Text) - 1)) / 100
            '    doesnotmeet = CDbl(e.Item.Cells(9).Text)
            '    meetexp = CDbl(e.Item.Cells(10).Text)
            '    exceed = CDbl(e.Item.Cells(11).Text)
            '    role = CDbl(e.Item.Cells(12).Text)
            'ElseIf (Actual1.Text.IndexOf(":") > -1) Then
            '    actual = objSupport.ToSeconds(Actual1.Text)
            '    doesnotmeet = objSupport.ToSeconds(e.Item.Cells(9).Text)
            '    meetexp = objSupport.ToSeconds(e.Item.Cells(10).Text)
            '    exceed = objSupport.ToSeconds(e.Item.Cells(11).Text)
            '    role = objSupport.ToSeconds(e.Item.Cells(12).Text)
            'Else
            '    actual = CDbl(Actual1.Text)
            '    doesnotmeet = CDbl(e.Item.Cells(9).Text)
            '    meetexp = CDbl(e.Item.Cells(10).Text)
            '    exceed = CDbl(e.Item.Cells(11).Text)
            '    role = CDbl(e.Item.Cells(12).Text)
            'End If
            'objSupport = Nothing
            'Calculation of Rating
            Connection.Open()
            Dim objQuery As New Support.QuerySet
            Dim NestingCheck As String = objQuery.SelectAValue(Connection, "NestingCheck", "userinfo", "EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'")
            Dim Tenurity As String = objQuery.SelectAValue(Connection, "TenurityDays", "userinfo", "EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'")
            objQuery = Nothing
            'Connection.Close()
            If Tenurity = "" Then
                Tenurity = "92"
            End If
            Dim GoalThreshold As Integer
            If Val(Tenurity) > 90 Or NestingCheck = "0" Then
                GoalThreshold = 0
            Else
                GoalThreshold = 10
            End If

            Rating = KeyRating(Actual.Text, Goal, Opr, PL, GoalThreshold)
            'If Val(Tenurity) > 90 Or NestingCheck = "0" Then
            '    rate = KRAClass.Rating(opt, actual, meetexp, doesnotmeet, exceed, role)
            'Else
            '    rate = KRAClass.Rating(opt, actual, meetexp * 0.9, doesnotmeet * 0.9, exceed * 0.9, role * 0.9)
            'End If

            Score = Rating * (weight / 100)
            'Dim objSupport As New Support.Common
            'If (Actual1.Text.IndexOf("%") > -1) Then
            '    strSQL = " Update tb_tran_storerating set tran_actual='" & actual * 100 & "%',tran_revrating = " & rate & " ,tran_revscore= " & rating & ",tran_remark='" & objSupport.FormatData(Remark.Text, "-") & "' where tran_id = " & id & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & ""
            'ElseIf (Actual1.Text.IndexOf(":") > -1) Then
            strSQL = " Update tb_tran_storerating set tran_actual='" & Actual.Text & "',tran_revrating = " & Rating & " ,tran_revscore= " & Score & ",tran_remark='" & objSupport.FormatData(Remark.Text, "-") & "' where tran_id = " & id & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & ""
            'Else
            '    strSQL = " Update tb_tran_storerating set tran_actual='" & actual & "',tran_revrating = " & rate & " ,tran_revscore= " & rating & ",tran_remark='" & objSupport.FormatData(Remark.Text, "-") & "' where tran_id = " & id & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & ""
            'End If
            objSupport = Nothing
            'Connection.Open()
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()
            grdEmployee.EditItemIndex = -1
            BindGrid()
            Connection.Close()
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_CancelCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.CancelCommand
        grdEmployee.EditItemIndex = -1
        Connection.Open()
        BindGrid()
        Connection.Close()
    End Sub
    'Private Sub printlink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Dim Month_disp As Integer
    '    Dim Year_disp As Integer
    '    Dim empid As Integer
    '    Month_disp = Session("Month")
    '    Year_disp = Session("Year")
    '    empid = Request.QueryString("id")
    '    Response.Redirect("krareportdisplay.aspx?id=status&mo=" & Month_disp & "&ye=" & Year_disp & "&empid=" & empid)
    'End Sub

    Private Sub bttupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttupdate.Click
        Dim relation As String = ""
        Dim relationsup As String = ""
        Dim comparison As String = ""
        Try
            If radioexcellent.Checked Then
                relation = "Excellent"
            ElseIf radiogood.Checked Then
                relation = "Good"
            ElseIf radioun.Checked Then
                relation = "Un - Satisfactory"
            End If

            If radioexcellent1.Checked Then
                relationsup = "Excellent"
            ElseIf radiogood1.Checked Then
                relationsup = "Good"
            ElseIf radioun1.Checked Then
                relationsup = "Un - Satisfactory"
            End If
            If radioexcellent2.Checked Then
                comparison = "Improved"
            ElseIf radiogood2.Checked Then
                comparison = "No change"
            ElseIf radioun2.Checked Then
                comparison = "Decline"
            End If
            Connection.Open()
            Dim objSupport As New Support.Common
            strSQL = "update tb_tran_empfeedback set " & _
                        "M_FEEDBACK_REL_EMP='" & relation.ToString() & "', " & _
                        "M_FEEDBACK_REL_SUP='" & relationsup.ToString() & "', " & _
                        "M_FEEDBACK_COMP='" & comparison.ToString() & "', " & _
                        "M_FEEDBACK_IDENT_TECH='" & objSupport.FormatData(txtidtec.Text.ToString(), "-") & "', " & _
                        "M_FEEDBACK_IDENT_CERT='" & objSupport.FormatData(txtidcer.Text.ToString(), "-") & "', " & _
                        "M_FEEDBACK_IDENT_SKILL='" & objSupport.FormatData(txtidskill.Text.ToString(), "-") & "', " & _
                        "M_FEEDBACK_REVCOMM='" & objSupport.FormatData(txt_revcomm.Text.ToString, "-") & "' " & _
                        " where " & _
                        "M_FEEDBACK_MONTH='" & Session("Month") & "' and " & _
                        "M_FEEDBACK_YEAR='" & Session("Year") & "' and " & _
                        "M_FEEDBACK_EMPID='" & Session("KRAUserID") & "' "
            Command.CommandText = strSQL
            Command.Connection = Connection
            Command.ExecuteNonQuery()
            Dim ParamList() As String
            Dim Parameter() As String
            ParamList = Split(txt_params.Text, ";")
            For i = 0 To ParamList.Length - 2
                Parameter = Split(ParamList(i), ",")
                strSQL = "update tb_tran_paramfeedback set " & _
                        "M_PFEEDBACK_COMMENT=' " & objSupport.FormatData(Request(Parameter(0)), "-") & "'" & _
                        " where " & _
                        "M_PFEEDBACK_PARAM='" & Parameter(1) & "' and " & _
                        "M_PFEEDBACK_EMPID='" & Session("KRAUserID") & "' and  " & _
                        "M_PFEEDBACK_MONTH='" & Session("Month") & "' and " & _
                        "M_PFEEDBACK_YEAR='" & Session("Year") & "'"
                Command.CommandText = strSQL
                Command.Connection = Connection
                Command.ExecuteNonQuery()
            Next
            objSupport = Nothing

            Dim objQuery As New Support.QuerySet
            Dim altReviewer As String = "0"
            Dim Reviewer As String
            Reviewer = objQuery.SelectAValue(Connection, "M_APPRAISER_ID", "tb_tran_employee", "M_EMPL_ID_PK=(SELECT M_APPRAISER_ID FROM tb_tran_employee WHERE M_EMPL_ID_PK='" & Session("KRAUserID") & "' and M_EMPL_MONTH='" & Session("Month") & "' and M_EMPL_YEAR ='" & Session("Year") & "') and M_EMPL_MONTH='" & Session("Month") & "' and M_EMPL_YEAR ='" & Session("Year") & "'")
            If Reviewer = "" Then Reviewer = "0"
            If Session("UserCurRole") = "Super Admin" Then
                altReviewer = Session("UserID")
            End If
            objQuery = Nothing
            strSQL = "Update tb_tran_storerating set tran_revtime=now(), tran_revid='" & Reviewer & "', tran_alt_revid='" & altReviewer & "' where tran_empid='" & Session("KRAUserID") & "' and tran_month='" & Session("Month") & "' and tran_year ='" & Session("Year") & "'"
            Command.CommandText = strSQL
            Command.Connection = Connection
            Command.ExecuteNonQuery()
            lblresult.Visible = True
            lblresult.Text = "Updated Successfully"
            bttupdate.Enabled = False
            Connection.Close()
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdEmployee.ItemDataBound
        'Dim temp As String = e.Item.Cells(4).Text
        Dim length As Integer = Len(e.Item.Cells(4).Text)
        If e.Item.Cells(4).Text.EndsWith("%") Then
            e.Item.Cells(4).Text = e.Item.Cells(4).Text.Substring(0, length - 1)
            'e.Item.Cells(4).Text = temp
        End If
        grdEmployee.Visible = True
    End Sub

End Class
