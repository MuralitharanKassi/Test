Imports MySql.Data.MySqlClient

Partial Class title_add
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            BindGrid()
        End If
    End Sub

    Private Sub dgTitle_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgTitle.ItemCommand
        lblError.Text = ""
        lblStatus.Text = ""
        Select Case e.CommandName
            Case "doAdd"
                Try
                    Dim count As String
                    Dim objSupport As New Support.QuerySet
                    Connection.Open()
                    Dim titlebox As TextBox
                    Dim titlename As String = ""
                    Dim nestingcheck As CheckBox
                    Dim nestingvalue As Integer = 0
                    titlebox = CType(e.Item.FindControl("txtTitle"), TextBox)
                    titlename = titlebox.Text.Trim()
                    nestingcheck = CType(e.Item.FindControl("cbTenurity"), CheckBox)
                    If nestingcheck.Checked Then
                        nestingvalue = 1
                    End If
                    If (titlename <> "") Then
                        count = objSupport.SelectAValue(Connection, "count(TITL_ID_PK)", "tb_master_title", "TITL_NAME='" & titlename & "'")
                        If count = "0" Then
                            strSQL = "insert into tb_master_title(TITL_NAME,TITL_NESTING_CHK) values('" & titlename & "','" & nestingvalue & "')"
                            Dim Command As New MySqlCommand(strSQL, Connection)
                            Command.ExecuteNonQuery()
                            titlebox.Text = ""
                            nestingcheck.Checked = False
                            lblStatus.Text = "Title added successfully"
                        Else
                            lblError.Text = "Title already exist"
                        End If
                    Else
                        lblError.Text = "Please enter a valid Title"
                    End If
                    objSupport = Nothing
                    Connection.Close()
                Catch Ex As Exception
                    If Connection.State = ConnectionState.Open Then Connection.Close()
                    lblError.Text = Ex.Message
                End Try
            Case "doEdit"
                dgTitle.EditItemIndex = CInt(e.Item.ItemIndex)
                dgTitle.ShowFooter = False
            Case "doUpdate"
                Try
                    Connection.Open()
                    Dim txtTitleID As String = e.Item.Cells(0).Text.Trim
                    Dim txtTitle As String = CType(e.Item.FindControl("txtTitle"), TextBox).Text.Trim
                    If txtTitle = "" Then
                        lblError.Text = "Title name cannot be empty"
                    Else
                        Dim result As String
                        Dim objSupport As New Support.QuerySet
                        result = objSupport.SelectAValue(Connection, "TITL_NAME", "tb_master_title", "TITL_NAME='" & txtTitle & "' and TITL_ID_PK<>'" & txtTitleID & "'")
                        If result.ToLower = txtTitle.ToLower Then
                            lblError.Text = "Cannot update Title. Name already exists"
                        Else
                            Dim Tenurity As String = "0"
                            If CType(e.Item.FindControl("cbTenurity"), CheckBox).Checked = True Then
                                Tenurity = "1"
                            End If
                            Dim strSQL As String = "update tb_master_title set TITL_NAME='" & txtTitle & "', TITL_NESTING_CHK='" & Tenurity & "' where TITL_ID_PK='" & txtTitleID & "'"
                            Dim Command As New MySqlCommand(strSQL, Connection)
                            Command.ExecuteNonQuery()
                            lblStatus.Text = "Record successfully updated"
                            dgTitle.EditItemIndex = -1
                            dgTitle.ShowFooter = True
                        End If
                        objSupport = Nothing
                    End If
                    Connection.Close()
                Catch ex As Exception
                    lblError.Text = ex.Message
                    If Connection.State = ConnectionState.Open Then Connection.Close()
                End Try
            Case "doCancel"
                dgTitle.EditItemIndex = -1
                dgTitle.ShowFooter = True
        End Select
        BindGrid()
    End Sub

    Private Sub DataGrid1_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgTitle.PageIndexChanged
        dgTitle.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub BindGrid()
        Try
            Dim myDataset As New DataSet
            Dim objSupport As New Support.QuerySet
            Connection.Open()
            myDataset = objSupport.SelectDataset(Connection, "distinct TITL_ID_PK as TitleID, TITL_NAME as Title, TITL_NESTING_CHK as Tenurity", "tb_master_title", , "Title")
            dgTitle.DataSource = myDataset.Tables(0).DefaultView
            dgTitle.DataBind()
            Connection.Close()
            objSupport = Nothing
        Catch Ex As Exception
            lblError.Text = Ex.Message
        End Try
    End Sub

    'Private Sub dgTitle_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgTitle.DeleteCommand
    '    Try
    '        Connection.Open()
    '        Dim txtTitleID As String = e.Item.Cells(0).Text.Trim
    '        Dim txtTitle As String = e.Item.Cells(1).Text.Trim 'CType(e.Item.Cells(1).Controls(0), TextBox).Text.Trim
    '        If txtTitle = "" Then
    '            'lblError.Visible = True
    '            lblError.Text = "Title name cannot be empty"
    '            Exit Sub
    '        End If
    '        Dim result As String
    '        Dim objSupport As New Support.QuerySet
    '        result = objSupport.SelectAValue(Connection, "TITL_NAME", "tb_master_title", "TITL_NAME='" & txtTitle & "' and TITL_ID_PK<>'" & txtTitleID & "'")
    '        If result.ToLower = txtTitle.ToLower Then
    '            lblError.Text = "Cannot upRemovedate Title."
    '            'lblError.Visible = True
    '            'lblStatus.Visible = False
    '            Exit Sub
    '        End If
    '        objSupport = Nothing
    '        Dim Tenurity As String = "0"
    '        'If CType(e.Item.Cells(2).Controls(1), CheckBox).Checked = True Then
    '        '    Tenurity = "1"
    '        'End If
    '        Dim strSQL As String = "delete from tb_master_title where TITL_ID_PK='" & txtTitleID & "'"
    '        Dim Command As New MySqlCommand(strSQL, Connection)
    '        Command.ExecuteNonQuery()
    '        lblStatus.Text = "Record successfully Removed"
    '        'lblStatus.Visible = True
    '        'lblError.Visible = False
    '        'close connection by suresh p
    '        Connection.Close()
    '    Catch ex2 As Exception
    '        lblError.Text = ex2.Message
    '    End Try
    '    dgTitle.EditItemIndex = -1
    '    BindGrid()
    'End Sub

End Class
