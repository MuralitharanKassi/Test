Partial Class kraerror
    Inherits System.Web.UI.Page
    Dim pageRedirect As String = "krahome.aspx"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        If Request.QueryString("status") = "do" Then
            lblMessage.Text = "KRA Generated Successfully"
            pageRedirect = "kra_appraiser.aspx"
        ElseIf Request.QueryString("status") = "did" Then
            lblMessage.Text = "KRA Already Generated"
            pageRedirect = "kra_appraiser.aspx"
        ElseIf Request.QueryString("status") = "er" Then
            imgIcon.Src = "images/critical.gif"
            lblMessage.Text = "Error Occured"
            pageRedirect = "krahome.aspx"
        End If
    End Sub

    Private Sub lnkContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkContinue.Click
        Response.Redirect(pageRedirect)
    End Sub
End Class
