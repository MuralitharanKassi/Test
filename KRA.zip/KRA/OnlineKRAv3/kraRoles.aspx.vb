Imports MySql.Data.MySqlClient
Imports System.Text.StringBuilder
Partial Class kraRoles_aspx
    Inherits System.Web.UI.Page
    Dim i As Integer
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Try
                lblStatus.Text = ""
                btn_save.Enabled = False
                btn_moveone.Enabled = False
                btn_moveall.Enabled = False
                btn_removeall.Enabled = False
                btn_removeone.Enabled = False
                Dim objControl As New Support.DataControl
                Connection.Open()
                objControl.FillDropDown(Connection, ddlProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                objControl.FillDropDown(Connection, ddlroles, "tb_mast_role", "role_name", "role_id")
                Connection.Close()
                objControl = Nothing
            Catch ex1 As Exception
                lblErrorMSg.Text = ex1.Message
            End Try

        End If
    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        Try
            Dim rowCount As Integer = 0
            Dim errorstatus As Integer = 0
            Connection.Open()
            Dim objQuery As New Support.QuerySet
            Dim title As String
            If lst_selected.Items.Count > 0 Then
                strSQL = "DELETE FROM tb_tran_titlerole WHERE titlerole_project='" & txtproject.Text & "' and titlerole_role='" & txtrole.Text & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Command.ExecuteNonQuery()

                For i = 0 To lst_selected.Items.Count - 1
                    If lst_selected.Items(i).Value <> "" Then
                        title = objQuery.SelectAValue(Connection, "TITL_ID_PK", "tb_master_title", "TITL_NAME='" & lst_selected.Items(i).Value & "'")
                        strSQL = "INSERT INTO tb_tran_titlerole(titlerole_project, titlerole_title, titlerole_role) VALUES('" & txtproject.Text & "','" & title & "','" & txtrole.Text & "')"
                        Command = New MySqlCommand(strSQL, Connection)
                        Command.ExecuteNonQuery()
                    End If
                Next
                lblStatus.Text = "Updated Successfully"
                lblStatus.Visible = True
                ddlProject.SelectedValue = "0"
                ddlroles.SelectedValue = "0"
                lst_selected.Items.Clear()
                lst_all.Items.Clear()
                'Response.Write(strSQL)
            End If
            objQuery = Nothing
            Connection.Close()
        Catch ex As Exception
            lblErrorMSg.Text = ex.Message
        End Try
    End Sub
    Public Sub BindGrid()
        Dim objQuery As New Support.QuerySet
        Dim RoleTitles As String()
        Dim ListedRoles As Integer
        Try
            'lblStatus.Text = ""
            'lst_selected.Items.Clear()
            'lst_all.Items.Clear()
            Connection.Open()
            Reader = objQuery.SelectReader(Connection, "distinct TITL_NAME as Titles", "tb_master_title,tb_tran_titlerole", "titlerole_project='" & ddlProject.SelectedItem.Value & "' and titlerole_title=TITL_ID_PK and titlerole_role='" & ddlroles.SelectedValue & "'")

            ListedRoles = -1
            While (Reader.Read())
                ListedRoles = ListedRoles + 1
                ReDim Preserve RoleTitles(ListedRoles)
                RoleTitles(ListedRoles) = Reader("Titles")
            End While
            Reader.Close()
            lst_selected.DataSource = RoleTitles
            lst_selected.DataBind()

            strSQL = "SELECT distinct Title FROM userinfo WHERE Project='" & ddlProject.SelectedItem.Text & "' and CONCAT(YEAR,MONTH)=(SELECT MAX(CONCAT(YEAR,MONTH)) FROM userinfo WHERE Project='" & ddlProject.SelectedItem.Text & "') ORDER BY Title"
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            
            Dim Title_Count As Integer = 0
            Dim Titles(0) As String
            Dim Exists As Boolean = False
            If Reader.HasRows() Then
                While Reader.Read()
                    ReDim Preserve Titles(Title_Count)
                    Exists = False
                    If ListedRoles >= 0 Then
                        For i = 0 To UBound(RoleTitles)
                            If RoleTitles(i) = Reader(0) Then
                                Exists = True
                                Exit For
                            End If
                        Next
                    End If
                    If Not Exists Then
                        Titles(Title_Count) = Reader(0)
                        Title_Count = Title_Count + 1
                    End If
                End While
            End If
            lst_all.DataSource = Titles
            lst_all.DataBind()
            Connection.Close()
        Catch chkboxselection As Exception
            lblErrorMSg.Text = chkboxselection.Message
            lblErrorMSg.Visible = True
        End Try

    End Sub

    Private Sub ddlProject_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlProject.SelectedIndexChanged
        lblStatus.Visible = False
    End Sub

    Private Sub btn_roles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_roles.Click
        Try
            'btn_save.Visible = True
            lst_selected.Items.Clear()
            lst_all.Items.Clear()
            Dim objQuery As New Support.QuerySet
            Dim ds As New DataSet
            Dim titlecnt As String
            lblErrorMSg.Text = ""
            Connection.Open()
            titlecnt = objQuery.SelectAValue(Connection, "count(distinct Title)", "userinfo", "Project='" & ddlProject.SelectedItem.Text & "' and CONCAT(YEAR,MONTH)=(SELECT MAX(CONCAT(YEAR,MONTH)) FROM userinfo WHERE Project='" & ddlProject.SelectedItem.Text & "')")
            Connection.Close()
            If (titlecnt = "0") Then
                btn_save.Visible = False
                lblErrorMSg.Text = "Title not found for selected Project"
                Exit Sub
            Else
                BindGrid()
                lblErrorMSg.Text = ""
                lblErrorMSg.Visible = False
                txtproject.Text = ddlProject.SelectedValue
                txtrole.Text = ddlroles.SelectedValue
                'btn_save.Visible = True
                btn_save.Enabled = True
                btn_moveone.Enabled = True
                btn_moveall.Enabled = True
                btn_removeall.Enabled = True
                btn_removeone.Enabled = True
            End If
            'Label1.Visible = False
            lblStatus.Visible = False
        Catch ex As Exception
            lblErrorMSg.Text = ex.Message
        End Try
    End Sub

    Private Sub btn_moveall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_moveall.Click
        Try
            lblErrorMSg.Text = ""
            lblStatus.Text = ""
            For Each item As ListItem In lst_all.Items
                lst_selected.Items.Add(item.Text)
            Next

            lst_all.Items.Clear()
            Dim objSupport As New Support.DataControl
            objSupport.SortListControl(lst_all, True)
            objSupport.SortListControl(lst_selected, True)
            objSupport = Nothing
        Catch ex As Exception
            lblErrorMSg.Text = ex.Message
        End Try
    End Sub

    Private Sub btn_moveone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_moveone.Click
        Try
            lblErrorMSg.Text = ""
            lblStatus.Text = ""
            For Each item As ListItem In lst_all.Items
                If item.Selected = True Then
                    lst_selected.Items.Add(item.Text)
                End If
            Next
            For i = lst_all.Items.Count - 1 To 0 Step -1
                If lst_all.Items.Item(i).Selected Then
                    lst_all.Items.RemoveAt(i)
                End If
            Next
            Dim objSupport As New Support.DataControl
            objSupport.SortListControl(lst_all, True)
            objSupport.SortListControl(lst_selected, True)
            objSupport = Nothing
        Catch ex As Exception
            lblErrorMSg.Text = ex.Message
        End Try
    End Sub

    Private Sub btn_removeone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_removeone.Click
        Try
            lblErrorMSg.Text = ""
            lblStatus.Text = ""
            For Each item As ListItem In lst_selected.Items
                If item.Selected = True Then
                    lst_all.Items.Add(item.Text)
                End If
            Next
            For i = lst_selected.Items.Count - 1 To 0 Step -1
                If lst_selected.Items.Item(i).Selected Then
                    lst_selected.Items.RemoveAt(i)
                End If
            Next
            Dim objSupport As New Support.DataControl
            objSupport.SortListControl(lst_all, True)
            objSupport.SortListControl(lst_selected, True)
            objSupport = Nothing
        Catch ex As Exception
            lblErrorMSg.Text = ex.Message
        End Try
    End Sub

    Private Sub btn_removeall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_removeall.Click
        Try
            lblErrorMSg.Text = ""
            lblStatus.Text = ""
            For Each item As ListItem In lst_selected.Items
                lst_all.Items.Add(item.Text)
            Next
            lst_selected.Items.Clear()
            Dim objSupport As New Support.DataControl
            objSupport.SortListControl(lst_all, True)
            objSupport.SortListControl(lst_selected, True)
            objSupport = Nothing
        Catch ex As Exception
            lblErrorMSg.Text = ex.Message
        End Try
    End Sub

End Class
