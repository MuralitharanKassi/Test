Imports MySql.Data.MySqlClient

Partial Class parameter
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            If Not IsPostBack Then
                gridbind()
            End If
        Catch ex2 As Exception
            lblError.Text = ex2.Message
        End Try
    End Sub

    Private Sub dgKRA_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgKRA.ItemCommand
        lblError.Text = ""
        lblStatus.Text = ""
        Select e.CommandName
            Case "doAdd"
                Try
                    Dim projectbox As TextBox
                    Dim projectname As String
                    projectbox = CType(e.Item.FindControl("txtKRA"), TextBox)
                    projectname = projectbox.Text.Trim()
                    If projectname <> "" Then
                        Dim result As String
                        Dim objSupport As New Support.QuerySet
                        Connection.Open()
                        result = objSupport.SelectAValue(Connection, "mast_parameter_name", "tb_mast_parameter", "mast_parameter_name='" & projectname & "'")
                        If LCase(result) <> LCase(projectname) Then
                            Dim cmd As New MySqlCommand("insert into tb_mast_parameter(mast_parameter_name) values('" & projectname & "')", Connection)
                            cmd.ExecuteNonQuery()
                            projectbox.Text = ""
                            lblStatus.Text = "Successfully Added"
                        Else
                            lblError.Text = "Cannot add parameter. Name already exists"
                        End If
                        Connection.Close()
                        objSupport = Nothing
                    Else
                        lblError.Text = "Parameter name cannot be empty"
                    End If
                Catch ex2 As Exception
                    If Connection.State = ConnectionState.Open Then Connection.Close()
                    lblError.Text = ex2.Message
                End Try
            Case "doEdit"
                dgKRA.EditItemIndex = CInt(e.Item.ItemIndex)
                dgKRA.ShowFooter = False
            Case "doUpdate"
                Try
                    Connection.Open()
                    Dim projectbox As TextBox
                    Dim projectname As String
                    projectbox = CType(e.Item.FindControl("txtKRA"), TextBox)
                    projectname = projectbox.Text.Trim()
                    If projectname <> "" Then
                        Dim result As String
                        Dim objSupport As New Support.QuerySet
                        result = objSupport.SelectAValue(Connection, "mast_parameter_name", "tb_mast_parameter", "mast_parameter_name='" & projectname & "'")
                        If LCase(result) <> LCase(projectname) Then
                            Dim strSQL As String = "update tb_mast_parameter set mast_parameter_name='" & projectname & "' where mast_parameter_id='" & e.Item.Cells(0).Text & "'"
                            Dim kraCommand As New MySqlCommand(strSQL, Connection)
                            kraCommand.ExecuteNonQuery()
                            lblStatus.Text = "Successfully Modified"
                            dgKRA.EditItemIndex = -1
                            dgKRA.ShowFooter = True
                        Else
                            lblError.Text = "Cannot update parameter. Name already exists"
                        End If
                        objSupport = Nothing
                    Else
                        lblError.Text = "Parameter name cannot be empty"
                    End If
                    Connection.Close()
                Catch ex2 As Exception
                    If Connection.State = ConnectionState.Open Then Connection.Close()
                    lblError.Text = ex2.Message
                End Try
            Case "doCancel"
                dgKRA.EditItemIndex = -1
                dgKRA.ShowFooter = True
        End Select
        gridbind()
    End Sub

    Private Sub DataGrid1_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgKRA.PageIndexChanged
        dgKRA.CurrentPageIndex = e.NewPageIndex
        gridbind()
    End Sub

    Private Sub gridbind()
        Try
            Dim myDataset As New DataSet
            Connection.Open()
            Dim myData As New MySqlDataAdapter("SELECT mast_parameter_name, mast_parameter_id from tb_mast_parameter ORDER BY mast_parameter_name", Connection)
            myData.Fill(myDataset)
            dgKRA.DataSource = myDataset.Tables(0).DefaultView
            dgKRA.DataBind()
            Connection.Close()
        Catch ex2 As Exception
            lblError.Text = ex2.Message
        End Try

    End Sub

    'Private Sub DataGrid1_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.DeleteCommand
    '    Try
    '        Connection.Open()
    '        'Dim txtPrjName As TextBox = e.Item.Cells(0).Controls(0)
    '        Dim txtPrjName As String = e.Item.Cells(0).Text
    '        If txtPrjName <> "" Then
    '            Dim result As String
    '            Dim objSupport As New Support.QuerySet
    '            result = objSupport.SelectAValue(Connection, "mast_parameter_name", "tb_mast_parameter", "mast_parameter_name='" & Trim(txtPrjName) & "'")
    '            If LCase(result) <> LCase(txtPrjName) Then
    '                Dim strSQL As String = "delete from tb_mast_parameter where mast_parameter_id='" & e.Item.Cells(2).Text & "'"
    '                Dim kraCommand As New MySqlCommand(strSQL, Connection)
    '                Dim kraReader As MySqlDataReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
    '                lblstatus.Text = "Successfully Removed"
    '                lblstatus.Visible = True
    '                lblerr.Visible = False
    '            Else
    '                lblerr.Text = "Cannot Remove parameter"
    '                lblerr.Visible = True
    '                lblstatus.Visible = False
    '            End If
    '            objSupport = Nothing
    '        Else
    '            lblerr.Visible = True
    '            lblerr.Text = "Parameter name cannot be empty"
    '        End If
    '        'close connection by suresh p
    '        Connection.Close()
    '    Catch ex2 As Exception
    '        lblerr.Text = ex2.Message
    '    End Try
    '    DataGrid1.EditItemIndex = -1
    '    gridbind()
    'End Sub

End Class
