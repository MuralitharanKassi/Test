Imports System.Data.Odbc
Partial Class krarating
    Inherits System.Web.UI.Page
    Dim Connection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    Dim Command As OdbcCommand
    Dim Reader As OdbcDataReader
    Dim status As String
    Dim TCount As Integer
    Dim ArrParameter(14, 0) As String 'Actual, Key_Weightage(Weightage), PL1(does_not_meet), PL2(meets_expectation), PL3(exceeds_expectation), PL4(role_model), Opr1, Rating, Score, Project, Title, Key_Deter, Param_Weightage(weight), Parameter, Goal
    Dim weighttotal As Double
    Dim HRavg As Double
    Dim relEmp As String
    Dim relSup As String
    Dim Comp As String
    Dim txtReamrks As New TextBox
    Dim strSQL As String
    Dim i As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim actual As String
        Dim rate As Integer
        Dim score(), total As Double
        Dim seconds As Integer
        Try
            If rbRel_Emp1.Checked Then
                relEmp = "Excellent"
            ElseIf rbRel_Emp2.Checked Then
                relEmp = "Good"
            ElseIf rbRel_Emp3.Checked Then
                relEmp = "Un - Satisfactory"
            End If

            If rbRel_Sup1.Checked Then
                relSup = "Excellent"
            ElseIf rbRel_Sup2.Checked Then
                relSup = "Good"
            ElseIf rbRel_Sup3.Checked Then
                relSup = "Un - Satisfactory"
            End If
            If rbCompare1.Checked Then
                Comp = "Improved"
            ElseIf rbCompare2.Checked Then
                Comp = "No change"
            ElseIf rbCompare3.Checked Then
                Comp = "Decline"
            End If
            weighttotal = 0.0

            TCount = CInt(Request.QueryString("c"))
            ReDim ArrParameter(13, TCount - 1)
            For i = 1 To TCount
                ArrParameter(0, i - 1) = Request.QueryString("a" & i)
            Next

            If Not IsPostBack Then
                Connection.Open()
                lblHeader.Text = "Emp No:<b> " & Session("kraempno") & "</b>  |  " & "Emp Name: <b>" & SelectAValue(Connection, "M_EMPL_NAME", "tb_mast_employee", "M_EMPL_ID_PK = '" & Session("kraempno") & "' ") & "</b>  |  " & "Project: <b>" & SelectAValue(Connection, "PROJ_NAME", "tb_master_project", "PROJ_ID_PK = '" & Session("kraproject") & "' ") & "</b>  |  " & "Title: <b>" & SelectAValue(Connection, "TITL_NAME", "tb_master_title", "TITL_ID_PK = '" & Session("kratitle") & "' ") & "</b>"
                Connection.Close()
            End If

            Call PopulateRating(pnlTxtPanel, Session("kratitle"))
            txt_params.Text = FeedbackParam(pnlParam, "0", Session("KRAMonth"), Session("KRAYear"), Session("kratitle"), Session("kraproject"), False)

            ReDim score(TCount - 1)

            For i = 0 To TCount - 1
                seconds = 0
                actual = ArrParameter(0, i)
                Dim dontmeet = ArrParameter(2, i)
                Dim meets = ArrParameter(3, i)
                Dim exceeds = ArrParameter(4, i)
                Dim rolmodel = ArrParameter(5, i)

                If actual.IndexOf("%") > -1 Then
                    actual = CDbl(Replace(actual, "%", "")) / 100
                ElseIf actual.IndexOf(":") > -1 Then
                    actual = ToSeconds(actual)
                    dontmeet = ToSeconds(dontmeet)
                    meets = ToSeconds(meets)
                    exceeds = ToSeconds(exceeds)
                    rolmodel = ToSeconds(rolmodel)
                Else
                    actual = CDbl(actual)
                    dontmeet = CDbl(dontmeet)
                    meets = CDbl(meets)
                    exceeds = CDbl(exceeds)
                    rolmodel = CDbl(rolmodel)

                End If
                Connection.Open()
                Dim NestingCheck As String = SelectAValue(Connection, "NestingCheck", "userinfo", "EmpID='" & Session("kraempno") & "' and Month='" & Session("KRAMonth") & "' and Year='" & Session("KRAYear") & "'")
                Dim Tenurity As String = SelectAValue(Connection, "TenurityDays", "userinfo", "EmpID='" & Session("kraempno") & "' and Month='" & Session("KRAMonth") & "' and Year='" & Session("KRAYear") & "'")
                Connection.Close()
                If Tenurity = "" Then
                    Tenurity = "92"
                End If
                Dim GoalThreshold As Double = 0.9
                If ArrParameter(6, i) = "2" Then GoalThreshold = 1.1
                If ArrParameter(6, i) = "4" Then GoalThreshold = 1
                If Val(Tenurity) > 90 Or NestingCheck = "0" Then
                    rate = KRAClass.Rating(ArrParameter(6, i), actual, meets, dontmeet, exceeds, rolmodel)
                Else
                    rate = KRAClass.Rating(ArrParameter(6, i), actual, meets * GoalThreshold, dontmeet * GoalThreshold, exceeds * GoalThreshold, rolmodel * GoalThreshold)
                End If

                ArrParameter(7, i) = rate
                ArrParameter(8, i) = rate * CDbl(ArrParameter(1, i)) / 100
                total = total + (rate * CDbl(ArrParameter(1, i)) / 100)
            Next

            lblEmpScore.Text = total
            lblAppScore.Text = total
            lblWeight.Text = weighttotal & "%"
            If Not IsPostBack Then
                Try
                    If Connection.State = ConnectionState.Closed Then Connection.Open()
                    Command = New OdbcCommand("truncate tb_temp_storerating", Connection)
                    Command.ExecuteNonQuery()
                    Connection.Close()
                    Dim ratetotal(10) As Double
                    Dim k As Integer = -1
                    Dim parameter As String = ""

                    'For calculating the sum of review rates based on parameter
                    For i = 0 To TCount - 1
                        If (parameter <> ArrParameter(13, i)) Then
                            parameter = ArrParameter(13, i)
                            k = k + 1
                            ratetotal(k) = ArrParameter(8, i)
                        Else
                            ratetotal(k) = ratetotal(k) + ArrParameter(8, i)
                        End If
                    Next
                    parameter = ""

                    'For calculating the HRrating based on parameter
                    Dim index As Double = 0.0
                    For i = 0 To TCount - 1
                        If (parameter <> ArrParameter(13, i)) Then
                            parameter = ArrParameter(13, i)
                            If ArrParameter(12, i) = 0 Then
                                ratetotal(index) = 0
                            Else
                                ratetotal(index) = ratetotal(index) / (ArrParameter(12, i) / 100)
                            End If

                            index = index + 1
                        End If
                    Next
                    For i = 0 To TCount - 1
                        HRavg = HRavg + ArrParameter(8, i)
                    Next
                    If weighttotal = 0 Then
                        lblHRrating.Text = "0"
                    Else
                        lblHRrating.Text = Math.Round((HRavg / weighttotal) * 100, 1)
                    End If

                    Dim intloop As Integer = 0
                    parameter = ""
                    ' Insering rating values to temporary table
                    For i = 0 To TCount - 1
                        If ArrParameter(0, i).IndexOf("%") > -1 Then
                            If (ArrParameter(14, i) < 1) Then
                                ArrParameter(14, i) = ArrParameter(14, i) * 100 & "%"
                            ElseIf (ArrParameter(14, i) = 100) Then
                                ArrParameter(14, i) = ArrParameter(14, i) & "%"
                            End If
                        End If
                        ArrParameter(12, i) = ArrParameter(12, i) & "%"
                        If (parameter <> ArrParameter(13, i)) Then
                            parameter = ArrParameter(13, i)
                            strSQL = "insert into tb_temp_storerating( " & _
                                        "tran_empid, " & _
                                        "tran_proj, " & _
                                        "tran_title, " & _
                                        "tran_keydeter, " & _
                                        "tran_weightage, " & _
                                        "tran_param, " & _
                                        "tran_goal, " & _
                                        "tran_opt, " & _
                                        "tran_doesnotmeet, " & _
                                        "tran_meetexpectation, " & _
                                        "tran_exceeds, " & _
                                        "tran_rolemodel, " & _
                                        "tran_weight, " & _
                                        "tran_actual, " & _
                                        "tran_emprating, " & _
                                        "tran_empscore, " & _
                                        "tran_apprating, " & _
                                        "tran_appscore, " & _
                                        "tran_revrating, " & _
                                        "tran_revscore, " & _
                                        "tran_hrrating " & _
                                     ") values( " & _
                                        "'" & Session("kraempno") & "', " & _
                                        "'" & ArrParameter(9, i) & "', " & _
                                        "'" & ArrParameter(10, i) & "', " & _
                                        "'" & ArrParameter(11, i) & "', " & _
                                        "'" & ArrParameter(12, i) & "', " & _
                                        "'" & ArrParameter(13, i) & "', " & _
                                        "'" & ArrParameter(14, i) & "', " & _
                                        "'" & ArrParameter(6, i) & "', " & _
                                        "'" & ArrParameter(2, i) & "', " & _
                                        "'" & ArrParameter(3, i) & "', " & _
                                        "'" & ArrParameter(4, i) & "', " & _
                                        "'" & ArrParameter(5, i) & "', " & _
                                        "'" & ArrParameter(1, i) & "%', " & _
                                        "'" & ArrParameter(0, i) & "', " & _
                                        "'" & ArrParameter(7, i) & "', " & _
                                        "'" & Math.Round(CDbl(ArrParameter(8, i)), 1) & "', " & _
                                        "'" & ArrParameter(7, i) & "', " & _
                                        "'" & Math.Round(CDbl(ArrParameter(8, i)), 1) & "', " & _
                                        "'" & ArrParameter(7, i) & "', " & _
                                        "'" & Math.Round(CDbl(ArrParameter(8, i)), 1) & "', " & _
                                        "'" & ratetotal(intloop) & "')"
                            intloop = intloop + 1
                        Else
                            strSQL = "insert into tb_temp_storerating ( " & _
                                        "tran_empid, " & _
                                        "tran_proj, " & _
                                        "tran_title, " & _
                                        "tran_keydeter, " & _
                                        "tran_weightage, " & _
                                        "tran_param, " & _
                                        "tran_goal, " & _
                                        "tran_opt, " & _
                                        "tran_doesnotmeet, " & _
                                        "tran_meetexpectation, " & _
                                        "tran_exceeds, " & _
                                        "tran_rolemodel, " & _
                                        "tran_weight, " & _
                                        "tran_actual, " & _
                                        "tran_emprating, " & _
                                        "tran_empscore, " & _
                                        "tran_apprating, " & _
                                        "tran_appscore, " & _
                                        "tran_revrating, " & _
                                        "tran_revscore " & _
                                     ") values( " & _
                                        "'" & Session("kraempno") & "', " & _
                                        "'" & ArrParameter(9, i) & "', " & _
                                        "'" & ArrParameter(10, i) & "', " & _
                                        "'" & ArrParameter(11, i) & "', " & _
                                        "'" & ArrParameter(12, i) & "', " & _
                                        "'" & ArrParameter(13, i) & "', " & _
                                        "'" & ArrParameter(14, i) & "', " & _
                                        "'" & ArrParameter(6, i) & "', " & _
                                        "'" & ArrParameter(2, i) & "', " & _
                                        "'" & ArrParameter(3, i) & "', " & _
                                        "'" & ArrParameter(4, i) & "', " & _
                                        "'" & ArrParameter(5, i) & "', " & _
                                        "'" & ArrParameter(1, i) & "%', " & _
                                        "'" & ArrParameter(0, i) & "', " & _
                                        "'" & ArrParameter(7, i) & "', " & _
                                        "'" & Math.Round(CDbl(ArrParameter(8, i)), 1) & "', " & _
                                        "'" & ArrParameter(7, i) & "', " & _
                                        "'" & Math.Round(CDbl(ArrParameter(8, i)), 1) & "', " & _
                                        "'" & ArrParameter(7, i) & "', " & _
                                        "'" & Math.Round(CDbl(ArrParameter(8, i)), 1) & "')"
                        End If
                        If Connection.State = ConnectionState.Closed Then Connection.Open()
                        Command = New OdbcCommand(strSQL, Connection)
                        Command.ExecuteNonQuery()
                        Connection.Close()
                    Next

                Catch ex4 As Exception
                    lblError.Text = ex4.Message
                    If Session("UserCurRole") = "Administrator" Then lblError.Text = "Error storing KRA in temp table: " & ex4.Message
                End Try

            End If
            BindGrid()
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            lbllastkra.Text = SelectAValue(Connection, "ifnull(ROUND(SUM(tran_revscore),1),'--') AS HrScore ", "tb_tran_storerating ", "tran_empid='" & Session("kraempno") & "' and 100*tran_year+tran_month>'" & (Session("KRAYear") * 100) + Session("KRAMonth") & "'")
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            'If hidDoValidate.Value = "Y" Then
            '    save()
            'End If
        Catch ex6 As Exception
            lblError.Text = ex6.Message
            If Session("UserCurRole") = "Administrator" Then lblError.Text = "Error in Page Load Function: " & ex6.Message
        End Try

    End Sub
    Public Sub BindGrid()
        Try
            Dim myDataset As New DataSet
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            Dim myData As New OdbcDataAdapter("Select tran_param,tran_weightage,tran_keydeter,tran_weight,tran_goal,tran_actual,tran_emprating,tran_empscore,tran_apprating,tran_appscore,tran_hrrating from tb_temp_storerating", Connection)
            myData.Fill(myDataset)
            grdRating.DataSource = myDataset.Tables(0).DefaultView
            grdRating.DataBind()
        Catch ex1 As Exception
            lblError.Text = ex1.Message
            If Session("UserCurRole") = "Administrator" Then lblError.Text = "Error binding datagrid: " & ex1.Message
        End Try

    End Sub

    Public Sub PopulateRating(ByVal pnlTxtPnl As Panel, ByVal strWhereCondValue As String)
        Try
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            strSQL = "select Weightage, does_not_meet, meets_expectation, exceeds_expectation, role_model, Opr1,project,Title,Key_Deter,weight,Parameter,goal from tb_mast_service where Title='" & strWhereCondValue & "' and role_month='" & Session("KRAMonth") & "' and role_year='" & Session("KRAYear") & "' and Project='" & Session("kraproject") & "'"
            Command = New OdbcCommand(strSQL, Connection)
            Reader = Command.ExecuteReader(CommandBehavior.CloseConnection)
            Dim intLoop As Integer = 0
            While Reader.Read()
                intLoop = intLoop + 1
                ArrParameter(1, intLoop - 1) = Reader(0)
                ArrParameter(2, intLoop - 1) = Reader(1)
                ArrParameter(3, intLoop - 1) = Reader(2)
                ArrParameter(4, intLoop - 1) = Reader(3)
                ArrParameter(5, intLoop - 1) = Reader(4)
                ArrParameter(6, intLoop - 1) = Reader(5)
                ArrParameter(9, intLoop - 1) = Reader(6)
                ArrParameter(10, intLoop - 1) = Reader(7)
                ArrParameter(11, intLoop - 1) = Reader(8)
                ArrParameter(12, intLoop - 1) = Reader(9)
                ArrParameter(13, intLoop - 1) = Reader(10)
                ArrParameter(14, intLoop - 1) = Reader(11)
                weighttotal = weighttotal + Reader(0)
            End While

            Reader.Close()
            Connection.Close()
        Catch ex2 As Exception
            lblError.Text = ""
            If Session("UserCurRole") = "Administrator" Then lblError.Text = "Error populating PL values in Array: " & ex2.Message
        End Try

    End Sub

    Private Sub editlink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles editlink.Click
        Session("EditKRA") = "1"
        Response.Redirect("kravalues.aspx")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Try
            Dim dsEmployee As String
            Connection.Open()
            dsEmployee = SelectAValue(Connection, "count(tran_empid)", "tb_tran_storerating", "tran_empid='" & Session("kraempno") & "' and tran_month='" & Session("KRAMonth") & "' and tran_year='" & Session("KRAYear") & "'")
            If dsEmployee <> "0" Then
                Response.Redirect("kraerror.aspx?status=did")
                Exit Sub
            End If

            Command = New OdbcCommand("TRUNCATE tb_temp_storerating", Connection)
            Command.ExecuteNonQuery()
            Dim curTime As DateTime
            curTime = DateTime.Now
            Command = New OdbcCommand("LOCK TABLES tb_tran_storerating WRITE", Connection)
            Command.ExecuteNonQuery()
            For i = 0 To TCount - 1
                'percentagecheck = ArrParameter(0, i).IndexOf("%")
                If ArrParameter(0, i).IndexOf("%") > -1 Then
                    If (ArrParameter(14, i) < 1) Then
                        ArrParameter(14, i) = ArrParameter(14, i) * 100 & "%"
                    ElseIf (ArrParameter(14, i) = 100) Then
                        ArrParameter(14, i) = ArrParameter(14, i) & "%"
                    End If
                End If
                ArrParameter(12, i) = ArrParameter(12, i) & "%"
                Dim altAppraiser As String = "0"
                Dim Appraiser As String
                Appraiser = SelectAValue(Connection, "M_APPRAISER_ID", "tb_tran_employee", "M_EMPL_ID_PK='" & Session("kraempno") & "' and M_EMPL_MONTH='" & Session("KRAMonth") & "' and M_EMPL_YEAR='" & Session("KRAYear") & "'")
                If Appraiser = "" Then Appraiser = "0"
                If Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Administrator" Then
                    altAppraiser = Session("UserID")
                End If
                strSQL = "insert into tb_tran_storerating( " & _
                             "tran_empid " & _
                             ",tran_proj " & _
                             ",tran_title " & _
                             ",tran_keydeter " & _
                             ",tran_weightage " & _
                             ",tran_param " & _
                             ",tran_goal " & _
                             ",tran_opt " & _
                             ",tran_doesnotmeet " & _
                             ",tran_meetexpectation " & _
                             ",tran_exceeds " & _
                             ",tran_rolemodel " & _
                             ",tran_weight " & _
                             ",tran_actual " & _
                             ",tran_emprating " & _
                             ",tran_empscore " & _
                             ",tran_apprating " & _
                             ",tran_appscore " & _
                             ",tran_revrating " & _
                             ",tran_revscore " & _
                             ",tran_month " & _
                             ",tran_year " & _
                             ",tran_apptime " & _
                             ",tran_appid " & _
                             ",tran_alt_appid " & _
                             ") values( " & _
                             "'" & Session("kraempno") & "' " & _
                             ",'" & ArrParameter(9, i) & "' " & _
                             ",'" & ArrParameter(10, i) & "' " & _
                             ",'" & ArrParameter(11, i) & "' " & _
                             ",'" & ArrParameter(12, i) & "' " & _
                             ",'" & ArrParameter(13, i) & "' " & _
                             ",'" & ArrParameter(14, i) & "' " & _
                             ",'" & ArrParameter(6, i) & "' " & _
                             ",'" & ArrParameter(2, i) & "' " & _
                             ",'" & ArrParameter(3, i) & "' " & _
                             ",'" & ArrParameter(4, i) & "' " & _
                             ",'" & ArrParameter(5, i) & "' " & _
                             ",'" & ArrParameter(1, i) & "%' " & _
                             ",'" & ArrParameter(0, i) & "' " & _
                             ",'" & ArrParameter(7, i) & "' " & _
                             ",'" & ArrParameter(8, i) & "' " & _
                             ",'" & ArrParameter(7, i) & "' " & _
                             ",'" & ArrParameter(8, i) & "' " & _
                             ",'" & ArrParameter(7, i) & "' " & _
                             ",'" & ArrParameter(8, i) & "' " & _
                             ",'" & Session("KRAMonth") & "' " & _
                             ",'" & Session("KRAYear") & "' " & _
                             ",'" & MSDateTime(curTime) & "' " & _
                             ",'" & Appraiser & "' " & _
                             ",'" & altAppraiser & "')"
                Command = New OdbcCommand(strSQL, Connection)
                Command.ExecuteNonQuery()
            Next

            Command = New OdbcCommand("UNLOCK TABLES", Connection)
            Command.ExecuteNonQuery()

            strSQL = "insert into tb_tran_empfeedback (" & _
                            "M_FEEDBACK_EMPID, " & _
                            "M_FEEDBACK_REL_EMP, " & _
                            "M_FEEDBACK_REL_SUP, " & _
                            "M_FEEDBACK_COMP, " & _
                            "M_FEEDBACK_IDENT_TECH, " & _
                            "M_FEEDBACK_IDENT_CERT, " & _
                            "M_FEEDBACK_IDENT_SKILL, " & _
                            "M_FEEDBACK_MONTH, " & _
                            "M_FEEDBACK_YEAR, " & _
                            "M_FEEDBACK_APPCOMM " & _
                            ") values(" & _
                            "'" & Session("kraempno") & "', " & _
                            "'" & relEmp.ToString() & "', " & _
                            "'" & relSup.ToString() & "', " & _
                            "'" & Comp.ToString() & "', " & _
                            "'" & FormatData(txtTrainingFeedback1.Text.ToString(), "-") & "', " & _
                            "'" & FormatData(txtTrainingFeedback2.Text.ToString(), "-") & "', " & _
                            "'" & FormatData(txtTrainingFeedback3.Text.ToString(), "-") & "', " & _
                            "'" & Session("KRAMonth") & "', " & _
                            "'" & Session("KRAYear") & "', " & _
                            "'" & FormatData(txtAppComment.Text, "-") & "')"
            Command = New OdbcCommand(strSQL, Connection)
            Command.ExecuteNonQuery()

            Dim ParamList() As String
            Dim Parameter() As String
            ParamList = Split(txt_params.Text, ";")
            For i = 0 To ParamList.Length - 1
                Parameter = Split(ParamList(i), ",")
                strSQL = "insert into tb_tran_paramfeedback (" & _
                        "M_PFEEDBACK_EMPID, " & _
                        "M_PFEEDBACK_PARAM," & _
                        "M_PFEEDBACK_COMMENT," & _
                        "M_PFEEDBACK_MONTH," & _
                        "M_PFEEDBACK_YEAR" & _
                        ") values(" & _
                        "'" & Session("kraempno") & "', " & _
                        "'" & Parameter(1) & "', " & _
                        "'" & FormatData(Request(Parameter(0)), "-") & "', " & _
                        "'" & Session("KRAMonth") & "', " & _
                        "'" & Session("KRAYear") & "')"
                Command = New OdbcCommand(strSQL, Connection)
                Command.ExecuteNonQuery()
            Next
            'lblresult.Visible = True
            'lblresult.Text = "KRA Generated Successfully"
            Response.Redirect("kraerror.aspx?status=do")
        Catch ex As Exception
            lblError.Text = ex.Message
            If Session("UserCurRole") = "Administrator" Then lblError.Text = "Error storing KRA in database: " & ex.Message
        End Try
    End Sub
End Class
