Imports MySql.Data.MySqlClient

Partial Class home
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents pnl As System.Web.UI.WebControls.Panel

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        'BindGrid()
    End Sub

    Public Sub BindGrid()
        Try
            Connection.Open()
            strSQL = "call KRACompletionReport('','','','','','','" & Session("Month") & "','" & Session("Year") & "','','')"
            Dim myDataset As New DataSet
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)
            If myDataset.Tables(0).Rows.Count > 0 Then
                rptList.DataSource = myDataset.Tables(0).DefaultView
                rptList.DataBind()
            Else
                rptList.DataSource = Nothing
                rptList.Visible = False
                divReport.Visible = False
            End If
            Connection.Close()
        Catch ex1 As Exception
            lblError.Text = ex1.Message
        End Try
    End Sub

    Function KRAStatus(ByVal status As String) As String
        Select Case LCase(status)
            Case "completed"
                Return "<span class='status-green'>" & status & "</span>"
            Case "kra not eligible", "goalsheet not available"
                Return "<span class='status-gray'>" & status & "</span>"
            Case "pending with appraiser"
                Return "<span class='status-red'>" & status & "</span>"
            Case "pending with reviewer"
                Return "<span class='status-orange'>" & status & "</span>"
            Case Else
                Return "<span class='status-black'>" & status & "</span>"
        End Select
    End Function
    
    'Private Sub Export(ByVal CacheName As String, ByVal PreAppend As String, ByVal PostAppend As String)
    '    Response.Clear()
    '    Response.Charset = ""
    '    Response.Cache.SetCacheability(HttpCacheability.NoCache)
    '    Response.ContentType = "application/vnd.xls"
    '    Response.AddHeader("content-disposition", "attachment;filename=" & "Report.xls")

    '    Dim sw As New System.IO.StringWriter
    '    Dim htw As New HtmlTextWriter(sw)
    '    DirectCast(Cache(CacheName), Repeater).RenderControl(htw)
    '    Dim sb1 As New System.Text.StringBuilder
    '    sb1 = sb1.Append(PreAppend & sw.ToString() & PostAppend)

    '    sw = Nothing
    '    htw = Nothing
    '    Response.Write(sb1.ToString())
    '    sb1.Remove(0, sb1.Length)
    '    Response.Flush()
    '    Response.End()
    'End Sub

    Protected Sub imgbtnExcel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnXLS.Click
        Dim strPreAppend As String = "<table border='1' class='bluegradient'><tr class='header'><th>Sl.No.</th><th>Emp ID</th><th>Name</th><th>Appraiser</th><th>Project</th><th>Title</th><th>Status</th></tr>"
        Dim strPostAppend As String = "</table>"
        Export.Repeater2Excel(DirectCast(Cache("Report"), Repeater), "user_list", strPreAppend, strPostAppend, "export.css")
    End Sub

    Protected Sub imgbtnDOC_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDOC.Click
        Dim strPreAppend As String = "<table border='1' class='bluegradient'><tr class='header'><th>Sl.No.</th><th>Emp ID</th><th>Name</th><th>Appraiser</th><th>Project</th><th>Title</th><th>Status</th></tr>"
        Dim strPostAppend As String = "</table>"
        Export.Repeater2Word(DirectCast(Cache("Report"), Repeater), "user_list", strPreAppend, strPostAppend, "export.css")
    End Sub

    Protected Sub imgbtnPDF_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnPDF.Click
        Dim strPreAppend As String = "<table border='1' class='bluegradient'><tr class='header'><th>Sl.No.</th><th>Emp ID</th><th>Name</th><th>Appraiser</th><th>Project</th><th>Title</th><th>Status</th></tr>"
        Dim strPostAppend As String = "</table>"
        Export.Repeater2PDF(DirectCast(Cache("Report"), Repeater), "user_list", strPreAppend, strPostAppend, "export.css")
    End Sub
End Class
