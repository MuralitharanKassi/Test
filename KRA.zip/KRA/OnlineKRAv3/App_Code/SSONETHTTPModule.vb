Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports SSO_NET
Imports System.Collections 
Imports System.IO
''' <summary>
''' Summary description for SSONETHTTPModule
''' </summary>
Public Class SSONETHTTPModule
    Implements IHttpModule

    Private userDetails As Hashtable
    Private ssoObject As SSO
    Dim Logfile As String = HttpContext.Current.Server.MapPath("LogFile") & "\Report_Log_" & Format(Now, "MM_dd_yyyy") & ".log"
    Public Sub New()
        '
        ' TODO: Add constructor logic here
        '
        ssoObject = SSO.Instance
        Dim propertiesFilePath As String = HttpContext.Current.Server.MapPath("URLDetails_live.xml")
        Dim propertyReaderObject As New PropertyReader(propertiesFilePath)
        ssoObject.LoginURL = propertyReaderObject.GetPropertyValue("loginurl")
        ssoObject.LogoutURL = propertyReaderObject.GetPropertyValue("logouturl")
        ssoObject.RedirectPageURL = propertyReaderObject.GetPropertyValue("redirectpageurl")
        ssoObject.LoginValidate = propertyReaderObject.GetPropertyValue("loginvalidate")
        ssoObject.SessionRefresh = propertyReaderObject.GetPropertyValue("sessionrefresh")
        ssoObject.SubDomain = propertyReaderObject.GetPropertyValue("subdomain")
        ssoObject.VersionID = propertyReaderObject.GetPropertyValue("versionid")
        ssoObject.ApplicationID = propertyReaderObject.GetPropertyValue("applicationid")
        ssoObject.DominoLogout = propertyReaderObject.GetPropertyValue("dominologout")
    End Sub

    Public Sub Dispose() Implements System.Web.IHttpModule.Dispose

    End Sub

    Public Sub Init(ByVal application As System.Web.HttpApplication) Implements System.Web.IHttpModule.Init
        AddHandler application.AcquireRequestState, AddressOf Application_OnAcquireRequest
    End Sub

    Private Sub Application_OnAcquireRequest(ByVal source As [Object], ByVal e As EventArgs)
        Dim application As HttpApplication = DirectCast(source, HttpApplication)
        Dim context As HttpContext = application.Context
        Dim linkForlogin As String
        linkForlogin = ((((ssoObject.LoginURL & "?redirectpage=") + ssoObject.RedirectPageURL & "&appid=") + ssoObject.ApplicationID & "&logouturl=") + ssoObject.LogoutURL & "&versionid=") + ssoObject.VersionID
        'If Not context.Session("SSO") Is Nothing Then
        '    If context.Session("SSO") <> "1" Then
        '        context.Session("SSO") = "1"
        '    End If
        'End If
        If context.Session IsNot Nothing AndAlso context.Session("Token") IsNot Nothing Then
            WriteToLog("step1")
            Dim SSOTest As Boolean = ssoObject.IsTokenPresent()
            If Not SSOTest Then
                WriteToLog("step2")
                context.Session.Abandon()
                context.Response.Redirect(linkForlogin)
            End If
        Else
            If context.Request.Cookies("LtpaToken") IsNot Nothing Then
                WriteToLog("step3")
                userDetails = ssoObject.CheckForToken()
                If userDetails("status").ToString() = "PASS" Then
                    WriteToLog("step4")
                    'context.Session("SSO_UserName") = userDetails("username")
                    'context.Session("type") = 1
                    'context.Session("loginname") = userDetails("commonname")
                    'context.Session("empid") = "1345"
                    context.Session("emailaddress") = userDetails("emailaddress")
                    'ElseIf userDetails("status").ToString() = "FAIL" Then
                    '    context.Response.Redirect(linkForlogin)
                Else
                    context.Response.Redirect(linkForlogin)
                    WriteToLog("step5")
                End If
            Else
                context.Response.Redirect(linkForlogin)
                WriteToLog("step6")
            End If
        End If
    End Sub
    Public Sub WriteToLog(ByVal pContent As String)
        Try
            Dim mFWriter As StreamWriter
            If File.Exists(Logfile) Then
                mFWriter = File.AppendText(Logfile)
            Else
                mFWriter = File.CreateText(Logfile)
            End If
            mFWriter.WriteLine(pContent)
            mFWriter.Flush()
            mFWriter.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
End Class

