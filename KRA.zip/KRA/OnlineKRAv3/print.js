var da = (document.all) ? 1 : 0;
var pr = (window.print) ? 1 : 0;
var mac = (navigator.userAgent.indexOf("Mac") != -1); 

function printFrame() {
  if (pr && da) { // IE5
	parent.score.focus();
    window.print();
    parent.score.focus();
  } else if (pr) { // NS4
    parent.frames["score"].print();
  } else if (da && !mac) { // IE4 (Windows)
    parent.print_form.focus();
    setTimeout("vbPrintPage(); parent.score.focus();", 100);
  } else { // other browsers
    alert("Sorry, your browser does not support this feature.");
  }
}

