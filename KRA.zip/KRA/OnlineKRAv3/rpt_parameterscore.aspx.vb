Imports MySql.Data.MySqlClient

Partial Class rpt_parameterscore
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As New MySqlCommand
    Protected ParamList() As String
    Dim strSQL As String
 
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Try
                Dim objSupport As New Support.DataControl
                Connection.Open()
                objSupport.FillDropDown(Connection, ddlProject, "tb_master_project", "proj_name", "proj_id_pk")
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlMonth, Session("Month"), Session("Year"))
                Connection.Close()
                objSupport = Nothing
                ddlMonth.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
            Catch ex3 As Exception
                lblError.Text = ex3.Message
            End Try
        End If
    End Sub

    Private Sub getReport()
        Try
            Dim objQuery As New Support.QuerySet
            Dim objSupport As New Support.Common
            Dim counter As String
            Connection.Open()
            Dim cond As String = ""
            If ddlProject.SelectedValue <> "0" Then
                cond = " and tran_proj ='" & ddlProject.SelectedValue & "'"
            End If
            counter = objQuery.SelectAValue(Connection, "count(DISTINCT tran_empid)", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'" & cond)
            'lnkExport.Visible = True
            'Dim myDataset As New DataSet
            'Dim errorData As String = ""
            'ddlProject.Visible = True
            'lblProject.Visible = True
            Dim curIter As Integer = 0
            ParamList = Split(objQuery.SelectArrayList(Connection, "distinct tran_param", "tb_tran_storerating", "tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'"), ",")
            Dim rating(counter, 5 + ParamList.Length) As String
            strSQL = "select round(sum(tran_revscore),1) from tb_tran_storerating where tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' " & cond & " group by tran_empid order by tran_empid"
            'If Session("UserCurRole") = "Administrator" Then Response.Write(strSQL & "<br>")
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            While (Reader.Read())
                rating(curIter, 4 + ParamList.Length) = Reader(0)
                curIter = curIter + 1
            End While
            Reader.Close()
            curIter = -1
            'strSQL = "select EmpId, Name as EmpName, Project, Title, s.tran_param as Parameter, round(sum(s.tran_revrating*(s.tran_weight/100))/(s.tran_weightage/100),1) as Score, Status from tb_tran_storerating s, userinfo u where s.tran_empid=u.EmpID and Month='" & getMonth(ddlMonth.SelectedValue) & "' and Year='" & getYear(ddlMonth.SelectedValue) & "' and tran_month='" & getMonth(ddlMonth.SelectedValue) & "' and tran_year='" & getYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' " & cond & " group by tran_empid, tran_param order by tran_empid, tran_param"
            strSQL = "select EmpId, Name as EmpName, Project, Title, s.tran_param as Parameter, round(100*sum(s.tran_revscore)/sum(s.tran_weight),1) as Score, Status from tb_tran_storerating s, userinfo u where s.tran_empid=u.EmpID and Month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and Year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_month='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and tran_year='" & objSupport.GetYear(ddlMonth.SelectedValue) & "' and tran_signofftime<>'' " & cond & " group by tran_empid, tran_param order by tran_empid, tran_param"
            'If Session("UserCurRole") = "Administrator" Then Response.Write(strSQL & "<br>")
            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Dim curEmp As Integer = 0
            Dim i As Integer
            While (Reader.Read())
                If curEmp <> Reader("EmpId") Then
                    curIter = curIter + 1
                    rating(curIter, 0) = Reader("EmpId")
                    rating(curIter, 1) = Reader("EmpName")
                    rating(curIter, 2) = Reader("Project")
                    rating(curIter, 3) = Reader("Title")
                    rating(curIter, 5 + ParamList.Length) = Reader("Status")
                    For i = 4 To 3 + ParamList.Length
                        rating(curIter, i) = ""
                    Next
                    curEmp = Reader("EmpId")
                End If
                For i = 0 To ParamList.Length - 1
                    If ParamList(i) = Reader("Parameter") Then
                        If Not Reader("Score") Is DBNull.Value Then
                            rating(curIter, 4 + i) = Reader("Score")
                        End If
                    End If
                Next
            End While
            'grdReport.DataSource = New Mommo.Data.ArrayDataView(rating)
            'grdReport.DataBind()

            objSupport = Nothing
            objQuery = Nothing
            Connection.Close()
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        getReport()
    End Sub

    Private Sub grdReport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        Try
            If e.Item.ItemType = ListItemType.Header Then
                e.Item.Cells(0).Text = "EmpID"
                e.Item.Cells(1).Text = "Emp Name"
                e.Item.Cells(2).Text = "Project"
                e.Item.Cells(3).Text = "Title"
                Dim i As Integer
                For i = 0 To ParamList.Length - 1
                    e.Item.Cells(4 + i).Text = ParamList(i)
                Next
                e.Item.Cells(4 + ParamList.Length).Text = "Overall"
                e.Item.Cells(5 + ParamList.Length).Text = "Status"
            End If
        Catch ex3 As Exception
            lblError.Text = ex3.Message
        End Try
    End Sub
End Class
