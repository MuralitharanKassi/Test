Imports MySql.Data.MySqlClient

Partial Class add_employee
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblError.Text = ""
        lblStatus.Text = ""
        If Not IsPostBack Then
            Try
                Dim objSupport As New Support.DataControl
                Connection.Open()
                objSupport.FillDropDown(Connection, ddlProject, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                objSupport.FillDropDown(Connection, ddlTitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                objSupport.FillDropDown(Connection, ddlStatus, "tb_mast_empstatus", "empstat_name", "empstat_id")
                objSupport = Nothing
                FillMonth(Connection, "", "", ddlMonth, Session("Month"), Session("Year"), 6)
                Connection.Close()
                ddlMonth.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
            Catch ex As Exception
                lblError.Text = "Exception Occured"
                If Connection.State = ConnectionState.Open Then Connection.Close()
                If Session("UserCurRole") = "Administrator" Then lblError.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        Try
            Dim empcheck As String
            Dim appcheck As String
            Dim objSupport As New Support.Common
            Dim objQuery As New Support.QuerySet
            Dim objCrypto As New Support.Crypto
            Connection.Open()
            empcheck = objQuery.SelectAValue(Connection, "count(M_EMPL_ID_PK)", "tb_tran_employee", "M_EMPL_ID_PK='" & Trim(txtEmpID.Text) & "' and M_EMPL_MONTH='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and M_EMPL_YEAR='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'")
            If empcheck <> "0" Then
                lblError.Text = "Employee already exists for selected month"
                Exit Sub
            End If
            appcheck = objQuery.SelectAValue(Connection, "count(M_EMPL_ID_PK)", "tb_tran_employee", "M_EMPL_ID_PK='" & Trim(txtAppraiserID.Text) & "' and M_EMPL_MODE<>'5' and M_EMPL_MONTH='" & objSupport.GetMonth(ddlMonth.SelectedValue) & "' and M_EMPL_YEAR='" & objSupport.GetYear(ddlMonth.SelectedValue) & "'")
            If appcheck = "0" Then
                lblError.Text = "Appraiser ID does not exist or inactive for selected month. Please enter valid Appraiser ID"
                Exit Sub
            End If
            empcheck = objQuery.SelectAValue(Connection, "count(M_EMPL_ID_PK)", "tb_mast_employee", "M_EMPL_ID_PK='" & Trim(txtEmpID.Text) & "'")
            If empcheck <> "0" Then
                objQuery.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_NAME='" & Trim(txtEmpName.Text) & "'", "M_EMPL_ID_PK='" & Trim(txtEmpID.Text) & "'")
            Else
                objQuery.InsertValue(Connection, "tb_mast_employee", "M_EMPL_ID_PK, M_EMPL_NAME, M_EMPL_PASSWORD, M_EMPL_ENCRYPT", "'" & Trim(txtEmpID.Text) & "','" & Trim(txtEmpName.Text) & "','" & objCrypto.Encrypt("password") & "','1'")
            End If
            objQuery.InsertValue(Connection, "tb_tran_employee", "M_EMPL_ID_PK, M_EMPL_PROJECT, M_EMPL_TITLE, M_APPRAISER_ID, M_EMPL_MODE, M_EMPL_MONTH, M_EMPL_YEAR", "'" & Trim(txtEmpID.Text) & "','" & ddlProject.SelectedValue & "','" & ddlTitle.SelectedValue & "', '" & txtAppraiserID.Text & "', '" & ddlStatus.SelectedValue & "','" & objSupport.GetMonth(ddlMonth.SelectedValue) & "','" & objSupport.GetYear(ddlMonth.SelectedValue) & "'")
            lblStatus.Text = "Employee details added successfully"
            Connection.Close()
            objSupport = Nothing
            objCrypto = Nothing
            objQuery = Nothing
        Catch ex As Exception
            If Connection.State = ConnectionState.Open Then Connection.Close()
            lblError.Text = "Exception Occured"
            If Session("UserCurRole") = "Administrator" Then lblError.Text = ex.Message
        End Try
    End Sub
End Class
