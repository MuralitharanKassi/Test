Imports MySql.Data.MySqlClient

Partial Class kra_appraiser_old
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Or Session("UserCurRole") = "Director" Then
                txtempid.Enabled = True
                combotitle.Enabled = True
                comboProj.Enabled = True
                txtapp.Enabled = True
            ElseIf Session("UserCurRole") = "Project Admin" Or Session("UserCurRole") = "Viewer" Or Session("UserCurRole") = "Data Admin" Or Session("UserCurRole") = "User" Then
                txtempid.Enabled = False
                combotitle.Enabled = False
                comboProj.Enabled = False
                txtapp.Enabled = False
            ElseIf Session("UserCurRole") = "Appraiser" Or Session("UserCurRole") = "Reviewer" Then
                txtempid.Enabled = True
                combotitle.Enabled = False
                comboProj.Enabled = False
                txtapp.Enabled = False
            End If
            If Request("app") <> "" Then txtapp.Text = Request("app")
            If Not IsPostBack Then
                Try
                    Connection.Open()
                    Dim objControl As New Support.DataControl
                    objControl.FillDropDown(Connection, comboProj, "tb_master_project", "PROJ_NAME", "PROJ_ID_PK")
                    objControl.FillDropDown(Connection, combotitle, "tb_master_title", "TITL_NAME", "TITL_ID_PK")
                    objControl = Nothing
                    Connection.Close()
                Catch ex3 As Exception
                    Label7.Text = ex3.Message
                End Try
            End If
            BindGrid()
        Catch ex As Exception
            Label7.Text = "Error occured"
        End Try
    End Sub
    Public Sub BindGrid(Optional ByVal EmpID As Integer = 0)
        Dim DemoGridItem As DataGridItem
        Dim Project As String = ""
        Dim Title As String = ""
        Dim Appraiser As String = ""
        Dim Emp_ID As String = ""
        Dim EmpName As String = ""
        Dim ExclEmp As String = ""
        Try
            If Session("UserCurRole") = "Administrator" Or Session("UserCurRole") = "Super Admin" Then
                If comboProj.SelectedValue <> "0" Then Project = comboProj.SelectedValue
                If combotitle.SelectedValue <> "0" Then Title = combotitle.SelectedValue
                Appraiser = txtapp.Text
                Emp_ID = txtempid.Text
            Else
                ExclEmp = Session("UserID")
                If Request("app") <> "" Then
                    Appraiser = Request("app")
                Else
                    Appraiser = Session("UserID")
                End If
                Emp_ID = txtempid.Text
            End If

            Connection.Open()
            strSQL = "call KRACompletionReport('" & Emp_ID & "','" & ExclEmp & "','" & EmpName & "','" & Appraiser & "','" & Title & "','" & Project & "','" & Session("Month") & "','" & Session("Year") & "','','" & ddlStatus.SelectedValue & "')"
            Dim myDataset As New DataSet
            Dim myData As New MySqlDataAdapter(strSQL, Connection)

            myData.Fill(myDataset)
            grdEmployee.DataSource = myDataset.Tables(0).DefaultView
            grdEmployee.DataBind()
            Connection.Close()
            For Each DemoGridItem In grdEmployee.Items
                DemoGridItem.Cells(1).Text = "<span title='Appraiser: " & DemoGridItem.Cells(9).Text & "(" & DemoGridItem.Cells(8).Text & ")'>" & DemoGridItem.Cells(1).Text & "</span>"
                If DemoGridItem.Cells(6).Text = "0" Then
                    DemoGridItem.Cells(5).ForeColor = Color.WhiteSmoke
                    DemoGridItem.Cells(5).Text = ""
                End If
                DemoGridItem.Cells(4).Font.Bold = True
                Select Case LCase(DemoGridItem.Cells(4).Text)
                    Case "completed"
                        DemoGridItem.Cells(4).ForeColor = Color.Green
                        DemoGridItem.Cells(0).Text = DemoGridItem.Cells(7).Text
                    Case "kra not eligible", "goalsheet not available"
                        DemoGridItem.Cells(4).ForeColor = Color.Gray
                        DemoGridItem.Cells(0).Text = DemoGridItem.Cells(7).Text
                    Case "pending with appraiser"
                        DemoGridItem.Cells(4).ForeColor = Color.Red
                        'Display alert if the Employee belongs to different project
                        If Session("UserCurRole") <> "Administrator" And Session("UserCurRole") <> "Super Admin" Then
                            If Session("UserProjectName") <> DemoGridItem.Cells(2).Text Then
                                DemoGridItem.Cells(0).Attributes.Add("onClick", "return confirm('Employee does not belong to your project, Do you want to continue?')")
                            End If
                        End If
                    Case "pending with reviewer"
                        DemoGridItem.Cells(4).ForeColor = Color.Orange
                        DemoGridItem.Cells(0).Text = DemoGridItem.Cells(7).Text
                End Select
            Next
            'If grdEmployee.HeaderRow <> Nothing And grdEmployee.FooterRow <> Nothing Then
            '    grdEmployee.HeaderRow.TableSection = TableRowSection.TableHeader
            '    grdEmployee.FooterRow.TableSection = TableRowSection.TableFooter
            'End If
        Catch ex As Exception
            Label7.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.ItemCommand
        If e.CommandName = "doKRA" Then
            Session("KRAUserID") = CType(e.Item.Cells(0).Controls(0), LinkButton).Text
            Response.Redirect("kra_appraisal.aspx")
        End If
    End Sub

    Private Sub grdEmployee_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdEmployee.PageIndexChanged
        grdEmployee.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        grdEmployee.CurrentPageIndex = 0
        BindGrid()
    End Sub

End Class
