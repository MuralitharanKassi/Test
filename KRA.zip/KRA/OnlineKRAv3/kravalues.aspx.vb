Imports System.Data.Odbc

Partial Class kravalues
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Connection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Dim Command As OdbcCommand
        Dim Reader As OdbcDataReader
        Dim strSQL As String
        Connection.Open()
        Try
            lblError.Text = ""
            Dim prjLocked As String
            If Not IsPostBack Then
                If Request.QueryString("id") <> "" Then
                    Session("kraempno") = Request.QueryString("id")
                Else
                    Response.Redirect("krahome.aspx")
                End If
            End If
            If Session("EditKRA") <> "1" Then
                DeleteValue(Connection, "tb_temp_storerating", "tran_empid='" & Session("kraempno") & "'")
            End If
            strSQL = "select EmpID, Name, ProjectID, Project, TitleID, Title from userinfo where EmpID='" & Session("kraempno") & "' AND Month= '" & Session("KRAMonth") & "' AND Year='" & Session("KRAYear") & "'"
            Command = New OdbcCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            If Reader.HasRows Then
                Reader.Read()
                Session("kraempname") = Reader.GetString(1)
                Session("kraproject") = Reader.GetString(2)
                Session("kratitle") = Reader.GetString(4)
                Session("kraprojectname") = Reader.GetString(3)
                Session("kratitlename") = Reader.GetString(5)
            Else
                lblError.Text = "Employee details not available"
                Exit Sub
            End If
            Reader.Close()
            prjLocked = SelectAValue(Connection, "kra_locked", "tb_mast_service", "project='" & Session("kraproject") & "' and Title='" & Session("kratitle") & "' and role_month='" & Session("KRAMonth") & "' and role_year='" & Session("KRAYear") & "'")
            If prjLocked = "1" And Session("UserCurRole") <> "Super Admin" And Session("UserCurRole") <> "Administrator" Then
                lblError.Text = "The KRA Entry is Locked for this Project. Please contact your KRA Administrator"
                Exit Sub
            End If
            lblHeader.Text = "Emp No: <b>" & Session("kraempno") & "</b>" & " Name: <b>" & Session("kraempname") & "</b><br>" & "Project: <b>" & Session("kraprojectname") & "</b>" & " Title: <b>" & Session("kratitlename") & "</b>"

            strSQL = "SELECT COUNT(tran_empid) FROM tb_tran_storerating WHERE tran_empid='" & Session("kraempno") & "' AND tran_month= '" & Session("KRAMonth") & "' AND tran_year='" & Session("KRAYear") & "'"
            Command = New OdbcCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()
            Reader.Read()
            If Reader.HasRows Then
                If Reader(0) <> "0" Then
                    lblStatus.Text = "KRA rating already present"
                    Exit Sub
                End If
            End If
            Reader.Close()
            Connection.Close()
            Session("validation") = PopulateKRA(Session("KRAMonth"), Session("KRAYear"), Session("kraempno"), Session("kratitle"), Session("kraproject"), CStr(Session("EditKRA")))
            cmdGenerate.Visible = True

        Catch ex1 As Exception
            lblStatus.Text = "Goal sheet may not be available. Please contact the Administrator."
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
        Connection.Close()

    End Sub

    Private Sub cmdGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim count As Integer
        Dim strActual, strParameter As String
        strParameter = "c=" & gvKRA.Rows.Count
        Try
            For Each gvItem As GridViewRow In gvKRA.Rows
                strActual = CType(gvItem.Cells(5).FindControl("txtActual"), TextBox).Text
                strActual = Replace(strActual, "$", "")
                strActual = Replace(strActual, ",", "")
                If InStr(gvItem.Cells(4).Text, "%") > 0 And InStr(strActual, "%") <= 0 Then
                    strActual = strActual & "%"
                End If
                count += 1
                strParameter &= "&a" & count & "=" & strActual
            Next
            Session("EditKRA") = "0"
            Response.Redirect("krarating.aspx?" & strParameter)
        Catch ex As Exception
            lblStatus.Text = ex.Message
        End Try
    End Sub

    Public Function PopulateKRA(ByVal Month As Integer, ByVal Year As Integer, ByVal EmpID As Integer, ByVal TitleID As Integer, ByVal ProjectID As Integer, Optional ByVal EditKRA As String = "") As String
        Dim Connection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        Dim ActualSet As New DataSet
        Dim DataAdapter As OdbcDataAdapter
        Dim strSQL As String = ""
        Dim FormValidation As String = ""
        Dim rfvActual As RequiredFieldValidator
        Dim revActual As RegularExpressionValidator
        Try
            Connection.Open()
            strSQL = "select parameter as Parameter, convert(concat(weight,'%') using utf8) as Param_Weight, key_deter as Key_Item, convert(concat(Weightage,'%') using utf8) as Key_Weight, case when (Goal<1 and Goal<>0) then concat(100*Goal,'%') when (Goal=100 and role_model<1) then concat(Goal,'%') else Goal end as Goal, role_model as PL4 from tb_mast_service where role_month='" & Month & "' and role_year= '" & Year & "' and Title='" & TitleID & "' and project='" & ProjectID & "' order by parameter"
            DataAdapter = New OdbcDataAdapter(strSQL, Connection)
            DataAdapter.Fill(ActualSet)
            If ActualSet.Tables(0).Rows.Count <> 0 Then
                gvKRA.DataSource = ActualSet
                gvKRA.DataBind()
            End If
            gvKRA.HeaderRow.CssClass = "header"
            If EditKRA = "1" Then
                strSQL = "Select tran_keydeter as KeyItem, tran_actual as Actual from tb_temp_storerating where tran_empid='" & EmpID & "'"
            Else
                strSQL = "Select Key_Deter as KeyItem, actual as Actual from tb_tran_actuals where act_month='" & Month & "' and act_year='" & Year & "' and empid='" & EmpID & "'"
            End If
            DataAdapter = New OdbcDataAdapter(strSQL, Connection)
            DataAdapter.Fill(ActualSet)
            Dim ParamWeightTotal As Integer = 0
            Dim KeyWeightTotal As Integer = 0
            For Each gvItem As GridViewRow In gvKRA.Rows
                ParamWeightTotal += CInt(Replace(gvItem.Cells(1).Text, "%", ""))
                KeyWeightTotal += CInt(Replace(gvItem.Cells(3).Text, "%", ""))
                Dim View As DataView = ActualSet.Tables(0).DefaultView
                View.RowFilter = "KeyItem='" & gvItem.Cells(2).Text & "'"
                If View.Count > 0 Then
                    CType(gvItem.Cells(5).FindControl("txtActual"), TextBox).Text = View.Item(0).ToString
                End If
                FormValidation = FormValidation & "frmvalidator.addValidation('" & CType(gvItem.Cells(5).FindControl("txtActual"), TextBox).ClientID & "','req','Please fill all the fields');" & vbCrLf
                'rfvActual = New RequiredFieldValidator
                'rfvActual.ControlToValidate = CType(gvItem.Cells(5).FindControl("txtActual"), TextBox).ID
                'gvItem.Cells(6).Controls.Add(rfvActual)
                'revActual = New RegularExpressionValidator
                'revActual.ControlToValidate = CType(gvItem.Cells(5).FindControl("txtActual"), TextBox).ID
                'If gvItem.Cells(4).Text.LastIndexOf(":") >= 0 Then
                '    revActual.ValidationExpression = "(\d)?\d:\d\d:\d\d"
                '    revActual.Text = "Improper time format"
                'ElseIf gvItem.Cells(4).Text.LastIndexOf("%") >= 0 Then
                '    revActual.ValidationExpression = "[\d\d]\d(%)?"
                '    revActual.Text = "Use goal format"
                'Else
                '    revActual.ValidationExpression = "[0-9,:,.]+"
                '    revActual.Text = "Invalid entry. Avoid spl chars"
                'End If
                'gvItem.Cells(6).Controls.Add(revActual)
            Next
            CType(gvKRA.FindControl("lblParamWeightTotal"), Label).Text = ParamWeightTotal
            CType(gvKRA.FindControl("lblKeyWeightTotal"), Label).Text = KeyWeightTotal
            Connection.Close()
            Return FormValidation
        Catch ex As Exception
            lblError.Text = ex.Message
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Function

    Private Sub gvKRA_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvKRA.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            'Dim txtRef As TextBox = CType(e.Row.FindControl("txtActual"), TextBox)
            'txtRef.Attributes.Add("ItemType", "item")
            'txtRef.Attributes.Add("onblur", "return updateControls('" + gvKRA.ClientID + "');")
        End If
    End Sub

    Private Sub gvKRA_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvKRA.RowCreated
        If e.Row.RowType = DataControlRowType.Footer Then
            'Dim lblRef As Label = CType(e.Row.FindControl("lblRating"), Label)
            'lblRef.Attributes.Add("ItemType", "total")
        End If
    End Sub

End Class
