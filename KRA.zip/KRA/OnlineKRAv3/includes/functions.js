﻿function DisableControls()
{
	document.body.style.cursor = "wait";
	nr = document.forms[0].all.length;
	for(i=0;i<nr;i++)
	{
		if(document.forms[0].all(i).tagName == "SELECT" ||
            (document.forms[0].all(i).tagName == "INPUT" &&
            (document.forms[0].all(i).type == "radio" || 
            document.forms[0].all(i).type == "checkbox" || 
            document.forms[0].all(i).type == "button") ))
            document.forms[0].all(i).disabled = true;
	}
}

function textboxStyle() 
	{   
		var inputs = document.getElementsByTagName('INPUT');
		for (var i=0;i<inputs.length;i++) {
		    if (inputs[i].type.toLowerCase() == 'text' || inputs[i].type.toLowerCase() == 'password')
            {
                if (inputs[i].className == '') inputs[i].className += 'textbox';
            }
            if (inputs[i].type.toLowerCase() == 'button' || inputs[i].type.toLowerCase() == 'submit')
            {
                if (inputs[i].className == '') inputs[i].className += 'button';
            }
		}
		var inputs = document.getElementsByTagName('SELECT');
		for (var i=0;i<inputs.length;i++) 
		{
		    if (inputs[i].className == '') inputs[i].className += 'textbox';
		}
		/*
		var inputs = document.getElementsByTagName('TEXTAREA');
		for (var i=0;i<inputs.length;i++) 
		{
    		inputs[i].className += ' textbox';
		}
		*/
	} 
	
//window.onresize=setSize;

function loadPage(url)
{
	if(url!="") 
	{
		showLoader();
		window.location = url;
	}
}

function setSize()
{
	Width =  window.innerWidth || document.body.offsetWidth;
	Height =  window.innerHeight || document.body.offsetHeight;
	document.getElementById("bodypanel").style.height=Height-155;
	document.getElementById("bodypanel").style.width=screen.width-244;
}

function showLoader()
{
	document.getElementById("loader").style.display = "block";
}

function hideLoader()
{
	document.getElementById("loader").style.display = "none";
}
window.onunload=function()
{
	document.getElementById("loader").style.display = "block";
}
