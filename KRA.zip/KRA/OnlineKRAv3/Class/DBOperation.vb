﻿Imports System.Data.Odbc

Public Class DBOperation
    Public Function SelectDataset(ByRef OdbcConn As OdbcConnection, ByVal FieldName As String, ByVal TableName As String, Optional ByVal Condition As String = "", Optional ByVal OrderBy As String = "", Optional ByVal GroupBy As String = "") As DataSet
        Dim ds As New DataSet
        Dim strSQL As String = " SELECT " & FieldName & " FROM " & TableName
        If Condition <> "" Then strSQL = strSQL & " WHERE " & Condition
        If GroupBy <> "" Then strSQL = strSQL & " GROUP BY " & GroupBy
        If OrderBy <> "" Then strSQL = strSQL & " ORDER BY " & OrderBy
        Dim datKRA As New OdbcDataAdapter(strSQL, OdbcConn)
        datKRA.Fill(ds, TableName)
        Return ds
    End Function

    Public Function SelectReader(ByRef OdbcConn As OdbcConnection, ByVal FieldName As String, ByVal TableName As String, Optional ByVal Condition As String = "", Optional ByVal OrderBy As String = "", Optional ByVal GroupBy As String = "") As OdbcDataReader
        Dim Reader As OdbcDataReader
        Dim strSQL As String = " SELECT " & FieldName & " FROM " & TableName
        If Condition <> "" Then strSQL = strSQL & " WHERE " & Condition
        If GroupBy <> "" Then strSQL = strSQL & " GROUP BY " & GroupBy
        If OrderBy <> "" Then strSQL = strSQL & " ORDER BY " & OrderBy
        Dim Command As New OdbcCommand(strSQL, OdbcConn)
        Reader = Command.ExecuteReader()
        Return Reader
    End Function

    Public Function SelectValue(ByRef OdbcConn As OdbcConnection, ByVal FieldName As String, ByVal TableName As String, Optional ByVal Condition As String = "", Optional ByVal OrderBy As String = "", Optional ByVal GroupBy As String = "") As String
        Dim strSQL As String = " SELECT " & FieldName & " FROM " & TableName
        If Condition <> "" Then strSQL = strSQL & " WHERE " & Condition
        If GroupBy <> "" Then strSQL = strSQL & " GROUP BY " & GroupBy
        If OrderBy <> "" Then strSQL = strSQL & " ORDER BY " & OrderBy
        Dim Command As New OdbcCommand(strSQL, OdbcConn)
        Dim Reader As OdbcDataReader = Command.ExecuteReader()
        If Reader.HasRows Then
            Reader.Read()
            Return Reader.GetString(0)
        Else
            Return ""
        End If
        Reader.Close()
    End Function

    Public Function SelectValueList(ByRef OdbcConn As OdbcConnection, ByVal FieldName As String, ByVal TableName As String, Optional ByVal Condition As String = "", Optional ByVal OrderBy As String = "", Optional ByVal GroupBy As String = "") As String
        Dim strSQL As String = " SELECT " & FieldName & " FROM " & TableName
        If Condition <> "" Then strSQL = strSQL & " WHERE " & Condition
        If GroupBy <> "" Then strSQL = strSQL & " GROUP BY " & GroupBy
        If OrderBy <> "" Then strSQL = strSQL & " ORDER BY " & OrderBy
        Dim Command As New OdbcCommand(strSQL, OdbcConn)
        Dim Reader As OdbcDataReader = Command.ExecuteReader()
        Dim ResultList As String = ""
        While Reader.Read()
            ResultList = ResultList & "," & Reader.GetString(0)
        End While
        Reader.Close()
        If ResultList <> "" Then
            Return Mid(ResultList, 2, Len(ResultList) - 1)
        Else
            Return ""
        End If
    End Function

    Public Sub Insert(ByRef OdbcConn As OdbcConnection, ByVal TableName As String, ByVal FieldList As String, ByVal ValueList As String)
        Dim strSQL As String = "INSERT INTO " & TableName & "(" & FieldList & ") VALUE(" & ValueList & ")"
        Dim kraCommand As New OdbcCommand(strSQL, OdbcConn)
        kraCommand.ExecuteNonQuery()
    End Sub

    Public Sub Update(ByRef OdbcConn As OdbcConnection, ByVal TableName As String, ByVal FieldValueList As String, Optional ByVal Condition As String = "")
        Dim strSQL As String = "UPDATE " & TableName & " SET " & FieldValueList
        If Condition <> "" Then strSQL = strSQL & " WHERE " & Condition
        Dim kraCommand As New OdbcCommand(strSQL, OdbcConn)
        kraCommand.ExecuteNonQuery()
    End Sub

    Public Sub Delete(ByRef OdbcConn As OdbcConnection, ByVal TableName As String, ByVal Condition As String)
        Dim strSQL As String = "DELETE FROM " & TableName & " WHERE " & Condition
        Dim kraCommand As New OdbcCommand(strSQL, OdbcConn)
        kraCommand.ExecuteNonQuery()
    End Sub

    Public Sub Truncate(ByRef OdbcConn As OdbcConnection, ByVal TableName As String)
        Dim strSQL As String = "Truncate " & TableName
        Dim kraCommand As New OdbcCommand(strSQL, OdbcConn)
        kraCommand.ExecuteNonQuery()
    End Sub
End Class
