Imports System.Data.Odbc
Imports System.Data.OleDb

Module reportadmin

    Public Function adminParam(ByVal pnlTxtPnl As Panel, ByVal strWhereCondValue As String, Optional ByVal strOptCondValue As String = "", Optional ByVal strempid As String = "") As Integer
        Dim actual As String
        Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        kraConnection.Open()
        Dim strSQL As String = "select parameter, weight, key_deter, Weightage, Goal from tb_mast_service where " & strWhereCondValue & " and Project='" & strOptCondValue & "'"
        Dim kraCommand As New OdbcCommand(strSQL, kraConnection)
        Dim kraReader As OdbcDataReader = kraCommand.ExecuteReader(CommandBehavior.CloseConnection)
        'Dim kraConnection1 As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        'kraConnection1.Open()
        'Dim strSQL1 As String = "select distinct (D_EMPL_Actual) from tb_mast_service, m_actual where title=D_EMPL_TITLE and D_EMPL_ID='" & strempid & "'"
        'Dim kraCommand1 As New OdbcCommand(strSQL1, kraConnection1)
        Dim xlconn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\onlinekra\acuals.xls;Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
        xlconn.Open()
        Dim empno As Integer
        empno = strempid
        Dim xlda As String = "select * from [acual$] where EmpID=" & empno & ""
        Dim acualcommand As New OleDbCommand(xlda, xlconn)
        Dim actualReader As OleDbDataReader = acualcommand.ExecuteReader(CommandBehavior.CloseConnection)
        'Dim actualReader As OdbcDataReader = kraCommand1.ExecuteReader(CommandBehavior.CloseConnection)
       
        Dim intLoop As Integer = 0
        Dim strParameter As String = ""
        Dim strWeightage As String = ""
        Dim i As Integer
        i = 4
        'Dim value As String()
        'value = Split(actual, ",")
        'actual = value(0)
        'For i = 1 To UBound(value)
        '    actual = value(i)
        While actualReader.Read()

            While kraReader.Read()
                i = i + 1
                intLoop = intLoop + 1

                If intLoop = 1 Then
                    Dim txtHParameter As New Label
                    Dim txtHParameterWeight As New Label
                    Dim txtHKeyDeter As New Label
                    Dim txtHKeyDeterWeight As New Label
                    Dim txtHKeyDeterGoal As New Label
                    Dim txtHKeyDeterActual As New Label

                    pnlTxtPnl.Controls.Add(txtHParameter)
                    txtHParameter.CssClass = "kravalueslabel"
                    txtHParameter.Text = "Parameter"

                    pnlTxtPnl.Controls.Add(txtHParameterWeight)
                    txtHParameterWeight.Text = "Weight"
                    txtHParameterWeight.CssClass = "kravaluesweightlabel"

                    pnlTxtPnl.Controls.Add(txtHKeyDeter)
                    txtHKeyDeter.Text = "Key Deteminant"
                    txtHKeyDeter.CssClass = "kravalueskralabel"

                    pnlTxtPnl.Controls.Add(txtHKeyDeterWeight)
                    txtHKeyDeterWeight.Text = "Weight"
                    txtHKeyDeterWeight.CssClass = "kravaluesweightlabel"

                    pnlTxtPnl.Controls.Add(txtHKeyDeterGoal)
                    txtHKeyDeterGoal.Text = "Goal"
                    txtHKeyDeterGoal.CssClass = "kravaluesweightlabel"

                    pnlTxtPnl.Controls.Add(txtHKeyDeterActual)
                    txtHKeyDeterActual.Text = "Actual"
                    txtHKeyDeterActual.CssClass = "actuallabel"
                End If
                Dim txtParameter As New Label
                pnlTxtPnl.Controls.Add(txtParameter)
                txtParameter.CssClass = "paramhideinput"
                If strParameter <> kraReader.GetString(0) Then
                    txtParameter.CssClass = "paraminput"
                    txtParameter.ID = "param" & intLoop
                    txtParameter.Text = kraReader.GetString(0)
                    strParameter = kraReader.GetString(0)
                End If

                Dim txtParameterWeight As New Label
                pnlTxtPnl.Controls.Add(txtParameterWeight)
                txtParameterWeight.CssClass = "weighthideinput"
                If strWeightage <> kraReader.GetString(0) Then
                    txtParameterWeight.CssClass = "weightinput"
                    txtParameterWeight.Text = kraReader.GetString(1) & "%"
                    strWeightage = kraReader.GetString(0)
                End If

                Dim txtKeyDeter As New Label
                pnlTxtPnl.Controls.Add(txtKeyDeter)
                txtKeyDeter.CssClass = "krainput"
                txtKeyDeter.Text = kraReader.GetString(2)

                Dim txtKeyDeterWeight As New Label
                pnlTxtPnl.Controls.Add(txtKeyDeterWeight)
                txtKeyDeterWeight.CssClass = "weightinput"
                txtKeyDeterWeight.Text = kraReader.GetString(3) & "%"

                Dim txtKeyDeterGoal As New Label
                pnlTxtPnl.Controls.Add(txtKeyDeterGoal)
                txtKeyDeterGoal.ID = "goal" & intLoop
                txtKeyDeterGoal.CssClass = "weightinput"
                If (kraReader.GetString(4).LastIndexOf(":") >= 0) Then
                    txtKeyDeterGoal.Text = kraReader.GetString(4)
                Else
                    If (kraReader.GetString(4) < 1) Then
                        txtKeyDeterGoal.Text = kraReader.GetString(4) * 100 & "%"
                    ElseIf (kraReader.GetString(4) = 100) Then
                        txtKeyDeterGoal.Text = kraReader.GetString(4) & "%"
                    Else
                        txtKeyDeterGoal.Text = kraReader.GetString(4)
                    End If
                End If

                Dim txtKeyDeterActual As New TextBox
                pnlTxtPnl.Controls.Add(txtKeyDeterActual)
                txtKeyDeterActual.ID = "actual" & intLoop

                While actualReader(i) Is DBNull.Value
                    i = i + 1
                End While
                'txtKeyDeterActual.Text = i
                If (kraReader.GetString(4).LastIndexOf(":") >= 0) Then
                    Dim arr As String()
                    Dim write As String
                    write = actualReader(i)
                    arr = write.Split(" ")
                    arr = arr(0).Split(":")
                    'If arr(0) >= 0 Then
                    '    txtKeyDeterActual.Text = write
                    'Else
                        If arr(0) >= 12 Then
                            write = (0 & ":" & arr(1) & ":" & arr(2))
                            txtKeyDeterActual.Text = write
                        ElseIf arr(0) < 12 Then
                            write = (arr(0) & ":" & arr(1) & ":" & arr(2))
                            txtKeyDeterActual.Text = write
                        'End If
                        End If
                Else
                    Dim arrper As String()
                    Dim writeper As String
                    writeper = actualReader(i)
                    arrper = writeper.Split("%")
                    If (kraReader.GetString(4) < 1) Then
                        If arrper(0) > 1 Then
                            'Dim value As Double
                            'value = Math.Round(CDbl(arrper(0)))
                            'txtKeyDeterActual.Text = value.ToString
                            txtKeyDeterActual.Text = Math.Round(CDbl(arrper(0))).ToString
                        Else
                            txtKeyDeterActual.Text = Math.Round((arrper(0) * 100))
                        End If
                    ElseIf (kraReader.GetString(4) = 100) Then
                        If arrper(0) > 1 Then
                            txtKeyDeterActual.Text = Math.Round(CDbl(arrper(0))).ToString
                        Else
                            txtKeyDeterActual.Text = Math.Round((arrper(0) * 100))
                        End If
                    Else
                        txtKeyDeterActual.Text = arrper(0)
                    End If
                    End If
                    txtKeyDeterActual.CssClass = "activetxtbox"
            End While
            'Next
        End While
        kraReader.Close()
        adminParam = intLoop
    End Function
    Public Function ActualValueValidation(ByVal strFieldName As String, ByVal strTablename As String, Optional ByVal strCondition As String = "") As String()
        Dim kraConnection1 As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
        kraConnection1.Open()
        Dim strSQL As String = "select " & strFieldName & " from " & strTablename & " where " & strCondition
        Dim kraCommand1 As New OdbcCommand(strSQL, kraConnection1)
        Dim kraReader1 As OdbcDataReader = kraCommand1.ExecuteReader(CommandBehavior.CloseConnection)
        Dim strActual() As String
        Dim i As Integer = 0
        ReDim strActual(100)
        While kraReader1.Read()
            strActual(i) = kraReader1(0)
            i = i + 1
        End While
        kraReader1.Close()
        ActualValueValidation = strActual
    End Function
End Module
