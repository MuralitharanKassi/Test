Public Class SortListArray
    Implements IComparer
    Private _Ascending As Boolean = True
    Public Sub New()
    End Sub
    Public Sub New(ByVal Ascending As Boolean)
        _Ascending = Ascending
    End Sub
    Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements IComparer.Compare
        If _Ascending Then
            Return New CaseInsensitiveComparer().Compare(x.ToString, y.ToString)
        Else
            Return New CaseInsensitiveComparer().Compare(y.ToString, x.ToString)
        End If
    End Function
End Class
