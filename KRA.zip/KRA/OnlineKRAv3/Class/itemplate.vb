Public Class DataGridTemplate
    Implements ITemplate
    Dim templateType As ListItemType
    Protected columnName As String

    Sub New(ByVal type As ListItemType, ByVal ColName As String)
        templateType = type
        columnName = ColName
    End Sub

    Protected Sub ValueChange(ByVal sender As Object, ByVal e As EventArgs)
        Dim tb As TextBox
        tb = CType(sender, TextBox)
        Dim dgi As DataGridItem
        dgi = CType(tb.NamingContainer, DataGridItem)
        CType(dgi.DataItem, DataRowView).Row.Item(Me.columnName) = tb.Text
    End Sub

    Protected Sub DataBind(ByVal sender As Object, ByVal e As EventArgs)
        Dim tb As TextBox
        tb = CType(sender, TextBox)
        Dim dgi As DataGridItem
        dgi = CType(tb.NamingContainer, DataGridItem)
        tb.Text = CType(CType(dgi.DataItem, DataRowView).Row.Item(Me.columnName), String) ' , DataSetDept.DEPTRow).DNAME
    End Sub

    Sub InstantiateIn(ByVal container As Control) _
      Implements ITemplate.InstantiateIn
        Dim lc As New Literal
        Select Case templateType
            Case ListItemType.Header
                lc.Text = "<B>" & columnName & "</B>"
                container.Controls.Add(lc)
            Case ListItemType.Item
                lc.Text = "Item " & columnName
                container.Controls.Add(lc)
            Case ListItemType.EditItem
                Dim tb As New TextBox
                tb.Text = ""
                container.Controls.Add(tb)
            Case ListItemType.Footer
                lc.Text = "<I>Footer</I>"
                container.Controls.Add(lc)
        End Select
    End Sub
End Class

