Imports MySql.Data.MySqlClient
Imports System.Text

Module KRAClass
    Public Function FeedbackParam(ByVal pnl As Panel, ByVal strEmpId As String, ByVal kraMonth As String, ByVal kraYear As String, Optional ByVal Title As String = "0", Optional ByVal Project As String = "0", Optional ByVal Displayer As Boolean = False) As String
        Try
            Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
            Dim Connection As New MySqlConnection(conString)
            Dim Reader As MySqlDataReader
            Dim Command As MySqlCommand
            Dim objSupport As New Support.Common
            Connection.Open()
            Dim strSQL As String
            If strEmpId <> "0" Then
                strSQL = "select distinct tran_param from tb_tran_storerating where tran_empid='" & strEmpId & "' and tran_month='" & kraMonth & "' and tran_year='" & kraYear & "'"
            Else
                strSQL = "select distinct Parameter from tb_mast_service where Title='" & Title & "' and role_month='" & kraMonth & "' and role_year='" & kraYear & "' and Project='" & Project & "' order by role_id_pk"
            End If

            Command = New MySqlCommand(strSQL, Connection)
            Reader = Command.ExecuteReader()

            Dim intLoop As Integer = 0
            intLoop = 0
            Dim ParamList As String = ""
            Dim kraTable As Table
            Dim kraRow As TableRow
            Dim kraCell As TableCell
            'Dim i As Integer
            kraTable = New Table
            If Reader.HasRows Then
                While Reader.Read()
                    intLoop = intLoop + 1
                    If intLoop = 1 Then
                        kraRow = New TableRow
                        objSupport.AddTableCell(kraRow, "Parameter Feedback")
                        kraRow.CssClass = "titlecell"
                        kraTable.Rows.Add(kraRow)
                    End If
                    kraRow = New TableRow
                    objSupport.AddTableCell(kraRow, Reader.GetString(0))
                    kraTable.Rows.Add(kraRow)
                    kraRow = New TableRow
                    kraCell = New TableCell
                    kraCell.Text = ""
                    Dim txtParameter As New TextBox
                    kraCell.Controls.Add(txtParameter)
                    'txtParameter.CssClass = "feedbackparam"
                    txtParameter.TextMode = TextBoxMode.MultiLine
                    txtParameter.ReadOnly = Displayer
                    txtParameter.ID = "txt_Param" & intLoop
                    ParamList = ParamList & "txt_Param" & intLoop & "," & Reader.GetString(0) & ";"
                    kraRow.Cells.Add(kraCell)
                    kraTable.Rows.Add(kraRow)
                End While
            End If
            Reader.Close()
            Connection.Close()
            kraTable.CellPadding = 2
            kraTable.Width = Unit.Percentage(100)
            pnl.Controls.Add(kraTable)
            FeedbackParam = Mid(ParamList, 1, Len(ParamList) - 1)
            'add below code by suresh p
            Return ParamList
            objSupport = Nothing
        Catch ex As Exception
            'Label2.Text = "Error retrieving parameter list"
            'If Session("UserCurRole") = "Administrator" Then
            '    Label2.Text = "Error Occured in Fucntion FeedbackParam. Error: " & ex.Message
            'End If
        End Try
        'Return="" 'comment by suresh p
    End Function

    Public Function CheckRoles(ByVal strusername As String, ByVal struserempno As String, ByVal status As String, Optional ByVal strmonth As String = "", Optional ByVal stryear As String = "") As String
        strmonth = MonthName(strmonth)
        Dim strUserDetails As String
        'Dim ApprDetails As String
        'Dim clsAppraiser As New clsGeneral
        'ApprDetails = clsAppraiser.SelectAvalue("count(M_EMPL_ID_PK)", "tb_mast_employee", "M_APPRAISER_ID ='" & LCase(struserempno) & "'")
        strUserDetails = "Welcome "
        If status = "Administrator" Then
            strUserDetails = strUserDetails & "Admin"
        Else
            strUserDetails = strUserDetails & strusername
        End If
        'strUserDetails = strUserDetails & ",<br>" & "Emp No: " & struserempno & "<br>" & "Month: " & strmonth & " - " & stryear & "<br>Current Role: " & status
        'strUserDetails = "  | Month: " & strmonth & " '" & stryear & "  |  " & strUserDetails
        CheckRoles = strUserDetails
    End Function

    'Function ParseGoalValue(ByVal goalval As String) As String
    '    'Data Type - Integer, Float, Integer%, Float%, Time, Currency
    '    'Value  Return String
    '    'A%	    P0,A
    '    'A.B%	P1,A,B
    '    'A	    F0,A
    '    'A.B	F1,A,B
    '    'A:B:C  D, A, B, C
    '    '$A     C0,A
    '    '$A.B   C1,A.B
    '    If InStr(goalval, "%") >= 0 Then

    '    End If
    'End Function

    Public Function KeyRating(ByVal Actual As String, ByVal Goal As String, ByVal Opr As String, ByVal PL As String, Optional ByVal ThresholdPercentage As Integer = 0, Optional ByVal Splitter As String = "|") As Integer
        'This function is flexible to calculate with any number of PL/Opr Values

        'Data Types     :   Samples
        '-------------------------------------------
        'Percentage     :   0.5%, 5%, 50%, 50.5%
        'Integer        :   5, 50
        'Time           :   00:05:50, 05:50:05
        'Float          :   0.5, 5.5, 50.5
        'Currency       :   $500, $500.50, $5,500.50

        'Sample PL      :   Sample Operators
        '-----------------------------------
        '80,90,100,100  :   <,<,<,>=
        '30,25,20,20    :   >,>,>.<=
        '1,2,3,4        :   <=,<=,<=,<=

        'For case when only high or low rating to be considered
        '4,4,4,4        :   <,<,<,>=
        'Less than 4 returns 1 and greater than 4 returns 4

        'Sample Validation
        '------------------
        'If a<80 Then 1
        'ElseIf a<90 Then 2
        'ElseIf a<100 Then 3
        'ElseIf a>=100 Then 4
        'Else 1
        'End If

        'compare(opr1,a,pl1)
        Dim i As Integer
        Dim GoalThreshold As Double = 0
        Dim Operators() As String = Opr.Split(Splitter)
        Dim PLValues() As String = PL.Split(Splitter)
        Dim objSupport As New Support.Common
        Dim Evaluator As New DataTable("Evaluator")
        If Operators(0) = "<" Then
            GoalThreshold = 1 - (ThresholdPercentage / 100)
        ElseIf Operators(1) = ">" Then
            GoalThreshold = 1 + (ThresholdPercentage / 100)
        Else
            GoalThreshold = 1
        End If
        If InStr(Goal, ":") > 0 Then
            Actual = objSupport.ToSeconds(Actual)
            For i = 0 To PLValues.Length - 1
                PLValues(i) = objSupport.ToSeconds(PLValues(i))
            Next
        ElseIf InStr(Goal, "%") > 0 Then
            Actual = Replace(Actual, "%", "")
            For i = 0 To Operators.Length - 1
                PLValues(i) = Replace(PLValues(i), "%", "")
            Next
        ElseIf InStr(Goal, "$") > 0 Then
            Actual = Replace(Actual, "$", "")
            Actual = Replace(Actual, ",", "")
            For i = 0 To Operators.Length - 1
                PLValues(i) = Replace(PLValues(i), "$", "")
                PLValues(i) = Replace(PLValues(i), ",", "")
            Next
        End If
        objSupport = Nothing
        For i = 0 To Operators.Length - 1
            If PLValues(i) <> "" Then
                PLValues(i) = CDbl(PLValues(i) * GoalThreshold)
            End If
        Next
        For i = 0 To Operators.Length - 1
            If Operators(i) <> "" And PLValues(i) <> "" Then
                If Evaluator.Compute(CDbl(Actual) & Operators(i) & CDbl(PLValues(i)), False) = True Then
                    Return (i + 1)
                    Exit Function
                End If
            End If
        Next
        Return 1
    End Function

    Public Function GetOperatorCode(ByVal strOperator As String) As String
        Dim Opr As String = strOperator.Split("|")(0)
        Select Case Opr
            Case "<"
                Return "1"
            Case ">"
                Return "2"
            Case ">="
                Return "3"
            Case "<="
                Return "4"
            Case Else
                Return "1"
        End Select
    End Function

    Public Function Rating(ByVal Opt As String, ByVal Actual As Double, ByVal Meets As Double, ByVal DontMeet As Double, ByVal Exceeds As Double, ByVal RoleModel As Double) As Integer
        Select Case Opt
            Case "1"
                'The value is in increasing order in the master table
                If (Actual < DontMeet) Then
                    Rating = 1
                ElseIf (Actual < Meets) And (Actual >= DontMeet) Then
                    Rating = 2
                ElseIf (Actual < Exceeds) And (Actual >= Meets) Then
                    Rating = 3
                ElseIf (Actual >= RoleModel) Then
                    Rating = 4
                Else
                    Rating = 0
                End If

            Case "2"
                'The value is in decreasing order in the master table
                If (Actual > DontMeet) Then
                    Rating = 1
                ElseIf (Actual > Meets) And (Actual <= DontMeet) Then
                    Rating = 2
                ElseIf (Actual > Exceeds) And (Actual <= Meets) Then
                    Rating = 3
                ElseIf (Actual <= RoleModel) Then
                    Rating = 4
                Else
                    Rating = 0
                End If
                'Case "partial"
                '    'has only two values of 1 or 4
                '    If (actual <> dontmeet) Then
                '        rate = 1
                '    Else
                '        rate = 4
                '    End If

            Case "4"
                If (Actual < DontMeet) Then
                    Rating = 1
                ElseIf Actual > 4 Then
                    Rating = 4
                Else
                    Rating = Actual
                End If
        End Select
    End Function

  
    'Public Function Transpose(ByVal aData)
    '    'Transpose()
    '    '
    '    ' Changes the data in a two dimensional array from:
    '    ' (x,y) => (y,x). This can be useful if you don't
    '    ' like the way RECORDSET.getrows() works. Calling
    '    ' Transpose() is a quick way to get your array into
    '    ' the proper form for QSort2().
    '    '
    '    ' Parameters:
    '    '
    '    ' aData array to be transposed
    '    '
    '    ' Returns:
    '    '
    '    ' New transposed array.
    '    '
    '    ' Performance on a P233MMX with 64M of RAM:
    '    ' ~5 seconds to transpose 100,000 rows.
    '    '
    '    ' e.g. a2 = Transpose(a1)

    '    Dim i, j, aTmp
    '    ' Dimension Tmp the opposite of A
    '    ReDim aTmp(ubound(aData, 2), ubound(aData))
    '    ' Transpose
    '    For i = 0 To ubound(aData, 2)
    '        For j = 0 To ubound(aData)
    '            aTmp(i, j) = aData(j, i)
    '        Next
    '    Next
    '    Transpose = aTmp
    'End Function

    'Public Function TransposeArray(ByVal myArray(,) As String) As String(,)
    '    Dim startRow As Integer = 0
    '    Dim startCol As Integer = 0
    '    Dim endRow As Integer = 0
    '    Dim endCol As Integer = 0
    '    Dim r As Long = 0
    '    Dim c As Long = 0
    '    Dim tmp As Double = 0
    '    ' get size of original matrix
    '    startRow = myArray.GetLowerBound(0)
    '    endRow = myArray.GetUpperBound(0)
    '    startCol = myArray.GetLowerBound(1)
    '    endCol = myArray.GetUpperBound(1)
    '    ' prepare the result matrix
    '    Dim arraySize(startCol, startRow) As String
    '    'Array res1 = Array.CreateInstance(typeof(double), endCol, endRow);
    '    Dim result(endCol + 1, endRow + 1) As String
    '    ' transpose the array
    '    r = startRow
    '    Do While (r <= endRow)
    '        c = startCol
    '        Do While (c <= endCol)
    '            'res(c, r) = arr[r, c];
    '            result(c, r) = myArray(r, c)
    '            c = (c + 1)
    '        Loop
    '        r = (r + 1)
    '    Loop
    '    ' return the transposed result
    '    Return result
    'End Function

    'Public Function FlipDataSet(ByVal myDataSet As DataSet) As DataSet
    '    Dim ds As DataSet = New DataSet
    '    Dim table As DataTable = New DataTable
    '    For Each dt As DataTable In myDataSet.Tables
    '        Dim i As Integer = 0
    '        Do While (i <= dt.Rows.Count)
    '            table.Columns.Add(Convert.ToString(i))
    '            i = (i + 1)
    '        Loop
    '        Dim r As DataRow
    '        Dim k As Integer = 0
    '        Do While (k < dt.Columns.Count)
    '            r = table.NewRow
    '            r(0) = dt.Columns(k).ToString
    '            Dim j As Integer = 1
    '            Do While (j <= dt.Rows.Count)
    '                r(j) = dt.Rows((j - 1))(k)
    '                j = (j + 1)
    '            Loop
    '            k = (k + 1)
    '        Loop
    '        table.Rows.Add(r)
    '    Next
    '    ds.Tables.Add(table)
    '    FlipDataSet = ds
    'End Function

    'Public Function DS2Array(ByVal myArray(,) As Array) As DataSet
    '    Dim dsTemp As DataSet = New DataSet
    '    Dim Tables As DataTable = New DataTable
    '    dsTemp.Tables.Add(Tables)
    '    dsTemp.Tables(0).Columns.Add("val", System.Type.GetType("System.String"))
    '    For Each str As String In myArray
    '        If (str <> String.Empty) Then
    '            Dim myRow As DataRow = dsTemp.Tables(0).NewRow
    '            myRow(0) = str
    '            dsTemp.Tables(0).Rows.Add(myRow)
    '        End If
    '    Next
    'End Function

    Public Sub FillMonth(ByRef Connection As MySqlConnection, ByVal EmpID As String, ByVal Role As String, ByVal ddlMonthYear As DropDownList, ByVal curMonth As Integer, ByVal curYear As Integer, Optional ByVal listCount As Integer = 12)
        Dim count As Integer = 0
        ddlMonthYear.Items.Clear()
        'If Role = "Administrator" Or Role = "Super Admin" Then
        If EmpID = "" And Role = "" Then
            curMonth = Microsoft.VisualBasic.DateAndTime.Month(Now) - 1
            curYear = Year(Now)
            If curMonth = 0 Then
                curMonth = 12
                curYear = curYear - 1
            End If
            While count < listCount
                count += 1
                ddlMonthYear.Items.Add(New ListItem(MonthName(curMonth, True) & "-" & Mid(CStr(curYear), 3, 2), 100 * curYear + curMonth))
                curMonth = curMonth - 1
                If curMonth = 0 Then
                    curMonth = 12
                    curYear = curYear - 1
                End If
            End While
        End If
        'Else
        '    Dim strSQL As String
        '    strSQL = "select Month,Year from userinfo where EmpID='" & EmpID & "' and HaveLogin='1' order by 100*Year+Month desc"
        '    Dim Command As New MySqlCommand(strSQL, Connection)
        '    Dim Reader As MySqlDataReader = Command.ExecuteReader()
        '    count = 0
        '    While Reader.Read() And count < listCount
        '        count += 1
        '        ddlMonthYear.Items.Add(New ListItem(MonthName(Reader("Month"), True) & "-" & Mid(CStr(Reader("Year")), 3, 2), 100 * CInt(Reader("Year")) + CInt(Reader("Month"))))
        '    End While
        '    Reader.Close()
        'End If
        'Dim count As Integer = 0
        Dim strSQL As String
        If Role = "Administrator" Or Role = "Super Admin" Then
            strSQL = "select distinct Month,Year from userinfo order by 100*Year+Month desc"
        Else
            strSQL = "select Month,Year from userinfo where EmpID='" & EmpID & "' and HaveLogin='1' order by 100*Year+Month desc"
        End If
        Dim Command As New MySqlCommand(strSQL, Connection)
        Dim Reader As MySqlDataReader = Command.ExecuteReader()
        count = 0
        While Reader.Read() And count < listCount
            count += 1
            ddlMonthYear.Items.Add(New ListItem(MonthName(Reader("Month"), True) & "-" & Mid(CStr(Reader("Year")), 3, 2), 100 * CInt(Reader("Year")) + CInt(Reader("Month"))))
        End While
        Reader.Close()
    End Sub

    Public Function getGoalType(ByVal goal As String) As String
        'code comes here
        Return ""
    End Function

    Function isManager(ByRef Connection As MySqlConnection, ByVal Employee As String, ByVal Manager As String, ByVal Month As Integer, ByVal Year As Integer) As Boolean
        If Employee = Manager Then
            Return True
            Exit Function
        End If
        Dim strSQL As String = "select M_APPRAISER_ID from tb_tran_employee where M_EMPL_MONTH='" & Month & "' and M_EMPL_YEAR='" & Year & "' and M_EMPL_ID_PK='" & Employee & "'"
        Dim Command As New MySqlCommand(strSQL, Connection)
        Dim Reader As MySqlDataReader = Command.ExecuteReader()
        Dim Appraiser As String
        Reader.Read()

        Appraiser = Reader(0)
        If Appraiser = "0" Then
            Reader.Close()
            Return False
        End If
        If Appraiser = Manager Then
            Reader.Close()
            Return True
        Else
            Return isManager(Connection, Appraiser, Manager, Month, Year)
        End If
        Reader.Close()
    End Function

    'Public Function ToSeconds(ByVal Time As String) As Integer
    '    Dim arr As String()
    '    arr = Time.Split(":")
    '    If IsNumeric(arr(0)) And IsNumeric(arr(1)) And IsNumeric(arr(2)) Then
    '        Return (CInt(arr(0)) * 3600) + (CInt(arr(1)) * 60) + (CInt(arr(2)))
    '    End If
    'End Function

    Public Sub ExportGridView(ByVal Page As page, ByRef TargetGrid As GridView, ByVal FileName As String, Optional ByVal ExportType As String = "Excel")
        Try
            Page.Response.Clear()
            Page.Response.AddHeader("content-disposition", "attachment;filename=" & FileName)
            Page.Response.Charset = ""
            Page.Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Page.Response.ContentType = "application/vnd.xls"
            Dim stringWrite As New System.IO.StringWriter
            Dim htmlWrite As New System.Web.UI.HtmlTextWriter(stringWrite)
            TargetGrid.RenderControl(htmlWrite)
            Page.Response.Write(stringWrite.ToString())
            Page.Response.End()
        Catch ex As Exception
            'Label7.Text = ex.Message
        End Try
    End Sub

    Public Sub ExportDataGrid(ByRef TargetGrid As DataGrid, ByVal FileName As String, Optional ByVal ExportType As String = "Excel")
        Try
            With HttpContext.Current.Response
                .Clear()
                .AddHeader("content-disposition", "attachment;filename=" & FileName)
                .Charset = ""
                .Cache.SetCacheability(HttpCacheability.NoCache)
                .ContentType = "application/vnd.xls"
                Dim stringWrite As New System.IO.StringWriter
                Dim htmlWrite As New System.Web.UI.HtmlTextWriter(stringWrite)
                TargetGrid.RenderControl(htmlWrite)
                .Write(stringWrite.ToString())
                .End()
                TargetGrid.Visible = False
            End With
        Catch ex As Exception
            'Label7.Text = ex.Message
            TargetGrid.Visible = False
        End Try
    End Sub

    Public Sub ErrorCatch(ByVal ErrorLabel As Label, ByVal Exception As Exception, Optional ByVal ErrorMessage As String = "", Optional ByVal Connection As MySqlConnection = Nothing, Optional ByVal UserRole As String = "")
        If UserRole = "Administrator" Then
            ErrorLabel.Text = Exception.Message
        Else
            If ErrorMessage <> "" Then
                ErrorLabel.Text = ErrorMessage
            End If
        End If
        If Connection IsNot Nothing AndAlso Connection.State = ConnectionState.Open Then
            Connection.Close()
        End If
    End Sub

    Public Sub ErrorLog(ByVal Connection As MySqlConnection, ByVal Exception As Exception, ByVal UserID As String, ByVal UserRole As String, ByVal PageName As String, ByVal ModuleName As String, Optional ByVal Month As String = "", Optional ByVal Year As String = "")
        Try
            If Connection.State = ConnectionState.Closed Then Connection.Open()
            Dim objQuery As New Support.QuerySet
            objQuery.InsertValue(Connection, "tb_tran_error", "err_userid,err_userrole,err_month,err_year,err_page,err_module,err_message,err_datetime", "'" & UserID & "','" & UserRole & "','" & Month & "','" & Year & "','" & PageName & "','" & ModuleName & "','" & Exception.Message & "',now()")
            objQuery = Nothing
            Connection.Close()
        Catch

        End Try
    End Sub
End Module
