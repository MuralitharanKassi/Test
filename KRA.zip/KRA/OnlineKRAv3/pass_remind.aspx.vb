Imports MySql.Data.MySqlClient

Partial Class pass_remind
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        Try
            If Session("UserDOB") Is Nothing Then
                lblStatus.Text = "Please fill the password reminder form"
            End If
            If Not IsPostBack Then
                Dim objSupport As New Support.Common
                For i = 1 To 31
                    ddlDate.Items.Add(objSupport.StringFill(i, 2))
                Next
                For i = 1 To 12
                    ddlMonth.Items.Add(New ListItem(MonthName(i), objSupport.StringFill(i, 2)))
                Next
                For i = 1949 To 1999
                    ddlYear.Items.Add(objSupport.StringFill(i, 4))
                Next
                objSupport = Nothing
                Connection.Open()
                strSQL = "select M_EMPL_DOB, M_EMPL_REMQUES, M_EMPL_REMANS from tb_mast_employee where M_EMPL_ID_PK='" & Session("UserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                If Reader.HasRows() Then
                    Reader.Read()
                    If Not IsDBNull(Reader("M_EMPL_DOB")) Then
                        ddlDate.SelectedValue = Day(Reader("M_EMPL_DOB"))
                        ddlMonth.SelectedValue = Month(Reader("M_EMPL_DOB"))
                        ddlYear.SelectedValue = Year(Reader("M_EMPL_DOB"))
                        txtQuestion.Text = Reader("M_EMPL_REMQUES")
                        txtAnswer.Text = Reader("M_EMPL_REMANS")
                    End If
                End If
            End If
        Catch ex As Exception
            lblError.Text = "Error Occured: " & ex.Message
        End Try
    End Sub

    Private Sub bttpass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttpass.Click
        Try
            Connection.Open()
            strSQL = "update tb_mast_employee set M_EMPL_DOB='" & ddlYear.SelectedValue & "-" & ddlMonth.SelectedValue & "-" & ddlDate.SelectedValue & "', M_EMPL_REMQUES='" & txtQuestion.Text & "', M_EMPL_REMANS='" & txtAnswer.Text & "' where M_EMPL_ID_PK='" & Session("UserID") & "'"
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()
            lblStatus.Text = "Password reminder data updated successfully"
        Catch ex As Exception
            lblError.Text = "Error updating security question: " & ex.Message
        End Try
    End Sub

End Class
