Imports MySql.Data.MySqlClient

Partial Class kra_rating
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Command As MySqlCommand
    Dim Reader As MySqlDataReader
    Dim KeyWeightTotal As Integer
    Dim strSQL As String
    Dim i As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'Session("KRAUserID") = "90403"
            lblError.Text = ""
            If Not IsPostBack Then
                Connection.Open()
                If Session("KRAUserID") = "" Then
                    Response.Redirect("krahome.aspx")
                End If
                strSQL = "select EmpID, Name, ProjectID, Project, TitleID, Title from userinfo where EmpID='" & Session("KRAUserID") & "' AND Month= '" & Session("Month") & "' AND Year='" & Session("Year") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                If Not Reader.HasRows Then
                    lblError.Text = "Employee details not available"
                    Session("KRAUserID") = ""
                    Response.Redirect("krahome.aspx")
                    Exit Sub
                End If
                Reader.Read()
                Session("KRAUserName") = Reader("Name")
                Session("KRAUserProjectID") = Reader("ProjectID")
                Session("KRAUserTitleID") = Reader("TitleID")
                Session("KRAUserProjectName") = Reader("Project")
                Session("KRAUserTitleName") = Reader("Title")
                Reader.Close()

                Dim prjLocked As String
                Dim objSupport As New Support.QuerySet
                prjLocked = objSupport.SelectAValue(Connection, "kra_locked", "tb_mast_service", "project='" & Session("KRAUserProjectID") & "' and Title='" & Session("KRAUserTitleID") & "' and role_month='" & Session("Month") & "' and role_year='" & Session("Year") & "'")
                If prjLocked = "1" And Session("UserCurRole") <> "Super Admin" And Session("UserCurRole") <> "Administrator" Then
                    lblError.Text = "The KRA Entry is Locked for this Project. Please contact your KRA Administrator"
                    Exit Sub
                End If
                lblHeader.Text = "Emp No: " & Session("KRAUserID") & " | Name: " & Session("KRAUserName") & " | Project: " & Session("KRAUserProjectName") & " | Title: " & Session("KRAUserTitleName")

                Dim KRA_Exist As String
                KRA_Exist = objSupport.SelectAValue(Connection, "COUNT(tran_empid)", "tb_tran_storerating", "tran_empid='" & Session("KRAUserID") & "' AND tran_month= '" & Session("Month") & "' AND tran_year='" & Session("Year") & "'")
                If KRA_Exist <> "0" Then
                    lblError.Text = "KRA rating already present"
                    Exit Sub
                End If
                objSupport = Nothing
                Try
                    strSQL = "SELECT ifnull(tran_month,'') as Month, ifnull(tran_year,'') as Year, IFNULL(ROUND(SUM(tran_revscore),1),'--') AS FinalScore FROM tb_tran_storerating WHERE tran_empid='" & Session("KRAUserID") & "' GROUP BY 100*tran_year+tran_month ORDER BY 100*tran_year+tran_month DESC LIMIT 1"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader
                    If Reader.HasRows Then
                        Reader.Read()
                        If Reader("Month") <> "" And Reader("Year") <> "" And Reader("FinalScore") <> "--" Then
                            lbllastkra.Text = Reader("FinalScore").ToString & " (" & MonthName(Reader("Month"), True) & "-" & Reader("Year") & ")"
                        Else
                            lbllastkra.Text = "--"
                        End If
                    End If
                    Reader.Close()
                Catch ex As Exception

                End Try
                Connection.Close()
                Session("validation") = PopulateKRA(Session("Month"), Session("Year"), Session("KRAUserID"), Session("KRAUserTitleID"), Session("KRAUserProjectID"))
            End If
            hfParameterList.Value = FeedbackParam(pnlParam, "0", Session("Month"), Session("Year"), Session("KRAUserTitleID"), Session("KRAUserProjectID"), False)
            Dim ParamList() As String
            Dim Parameter() As String
            Dim validation As String = ""
            ParamList = Split(hfParameterList.Value, ";")
            For i = 0 To ParamList.Length - 2
                Parameter = Split(ParamList(i), ",")
                validation &= "frmvalidator.addValidation('" & CType(pnlParam.FindControl(Parameter(0)), TextBox).ClientID & "','req','Please fill all the parameter comments');" & vbCrLf
            Next
            Session("validation") &= validation
        Catch ex1 As Exception
            lblError.Text = "Error loading page. Please contact the Administrator."
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Try
            Dim relEmp As String = ""
            Dim relSup As String = ""
            Dim Comp As String = ""
            If rbRel_Emp1.Checked Then
                relEmp = "Excellent"
            ElseIf rbRel_Emp2.Checked Then
                relEmp = "Good"
            ElseIf rbRel_Emp3.Checked Then
                relEmp = "Un - Satisfactory"
            End If
            If rbRel_Sup1.Checked Then
                relSup = "Excellent"
            ElseIf rbRel_Sup2.Checked Then
                relSup = "Good"
            ElseIf rbRel_Sup3.Checked Then
                relSup = "Un - Satisfactory"
            End If
            If rbCompare1.Checked Then
                Comp = "Improved"
            ElseIf rbCompare2.Checked Then
                Comp = "No change"
            ElseIf rbCompare3.Checked Then
                Comp = "Decline"
            End If
            Dim objSupport As New Support.QuerySet
            Dim objSupport2 As New Support.Common
            Dim dsEmployee As String
            Connection.Open()
            dsEmployee = objSupport.SelectAValue(Connection, "count(tran_empid)", "tb_tran_storerating", "tran_empid='" & Session("KRAUserID") & "' and tran_month='" & Session("Month") & "' and tran_year='" & Session("Year") & "'")
            If dsEmployee <> "0" Then
                Response.Redirect("krastatus.aspx?status=did")
                Exit Sub
            End If

            Dim curTime As DateTime
            Dim gvItem As GridViewRow
            Dim PL() As String
            curTime = DateTime.Now
            Dim altAppraiser As String = "0"
            Dim Appraiser As String
            Appraiser = objSupport.SelectAValue(Connection, "M_APPRAISER_ID", "tb_tran_employee", "M_EMPL_ID_PK='" & Session("KRAUserID") & "' and M_EMPL_MONTH='" & Session("Month") & "' and M_EMPL_YEAR='" & Session("Year") & "'")
            If Appraiser = "" Then Appraiser = "0"
            If Session("UserCurRole") = "Super Admin" Then
                altAppraiser = Session("UserID")
            End If
            If Session("UserCurRole") = "Administrator" Then
                altAppraiser = "1"
            End If
            Command = New MySqlCommand("LOCK TABLES tb_tran_storerating WRITE", Connection)
            Command.ExecuteNonQuery()
            objSupport = Nothing

            For Each gvItem In gvKRA.Rows
                PL = Server.HtmlDecode(gvItem.Cells(6).Text).Split("|")
                strSQL = "insert into tb_tran_storerating( " & _
                             "tran_empid " & _
                             ",tran_proj " & _
                             ",tran_title " & _
                             ",tran_param " & _
                             ",tran_weightage " & _
                             ",tran_keydeter " & _
                             ",tran_weight " & _
                             ",tran_goal " & _
                             ",tran_opt " & _
                             ",tran_doesnotmeet " & _
                             ",tran_meetexpectation " & _
                             ",tran_exceeds " & _
                             ",tran_rolemodel " & _
                             ",tran_PL5 " & _
                             ",tran_actual " & _
                             ",tran_emprating " & _
                             ",tran_empscore " & _
                             ",tran_apprating " & _
                             ",tran_appscore " & _
                             ",tran_revrating " & _
                             ",tran_revscore " & _
                             ",tran_month " & _
                             ",tran_year " & _
                             ",tran_apptime " & _
                             ",tran_appid " & _
                             ",tran_alt_appid " & _
                             ") values( " & _
                             "'" & Session("KRAUserID") & "' " & _
                             ",'" & Session("KRAUserProjectID") & "' " & _
                             ",'" & Session("KRAUserTitleID") & "' " & _
                             ",'" & Server.HtmlDecode(gvItem.Cells(0).Text) & "' " & _
                             ",'" & CType(gvItem.Cells(1).FindControl("lblParamWeight"), Label).Text & "' " & _
                             ",'" & Server.HtmlDecode(gvItem.Cells(2).Text) & "' " & _
                             ",'" & CType(gvItem.Cells(3).FindControl("lblKeyWeight"), Label).Text & "' " & _
                             ",'" & Server.HtmlDecode(gvItem.Cells(4).Text) & "' " & _
                             ",'" & Server.HtmlDecode(gvItem.Cells(5).Text) & "' " & _
                             ",'" & PL(0) & "' " & _
                             ",'" & PL(1) & "' " & _
                             ",'" & PL(2) & "' " & _
                             ",'" & PL(3) & "' " & _
                             ",'" & PL(4) & "' " & _
                             ",'" & CType(gvItem.Cells(7).FindControl("txtActual"), TextBox).Text & "' " & _
                             ",'" & gvItem.Cells(8).Text & "' " & _
                             ",'" & gvItem.Cells(9).Text & "' " & _
                             ",'" & gvItem.Cells(8).Text & "' " & _
                             ",'" & gvItem.Cells(9).Text & "' " & _
                             ",'" & gvItem.Cells(8).Text & "' " & _
                             ",'" & gvItem.Cells(9).Text & "' " & _
                             ",'" & Session("Month") & "' " & _
                             ",'" & Session("Year") & "' " & _
                             ",'" & objSupport2.MSDateTime(curTime) & "' " & _
                             ",'" & Appraiser & "' " & _
                             ",'" & altAppraiser & "')"
                Command = New MySqlCommand(strSQL, Connection)
                Command.ExecuteNonQuery()
            Next

            Command = New MySqlCommand("UNLOCK TABLES", Connection)
            Command.ExecuteNonQuery()

            strSQL = "insert into tb_tran_empfeedback (" & _
                            "M_FEEDBACK_EMPID, " & _
                            "M_FEEDBACK_REL_EMP, " & _
                            "M_FEEDBACK_REL_SUP, " & _
                            "M_FEEDBACK_COMP, " & _
                            "M_FEEDBACK_IDENT_TECH, " & _
                            "M_FEEDBACK_IDENT_CERT, " & _
                            "M_FEEDBACK_IDENT_SKILL, " & _
                            "M_FEEDBACK_MONTH, " & _
                            "M_FEEDBACK_YEAR, " & _
                            "M_FEEDBACK_APPCOMM " & _
                            ") values(" & _
                            "'" & Session("KRAUserID") & "', " & _
                            "'" & relEmp & "', " & _
                            "'" & relSup & "', " & _
                            "'" & Comp & "', " & _
                            "'" & objSupport2.FormatData(txtTrainingFeedback1.Text, "-") & "', " & _
                            "'" & objSupport2.FormatData(txtTrainingFeedback2.Text, "-") & "', " & _
                            "'" & objSupport2.FormatData(txtTrainingFeedback3.Text, "-") & "', " & _
                            "'" & Session("Month") & "', " & _
                            "'" & Session("Year") & "', " & _
                            "'" & objSupport2.FormatData(txtAppComment.Text, "-") & "')"
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()

            Dim ParamList() As String
            Dim Parameter() As String
            ParamList = Split(hfParameterList.Value, ";")
            For i = 0 To ParamList.Length - 2
                Parameter = Split(ParamList(i), ",")
                If Parameter(0) <> "" Then
                    strSQL = "insert into tb_tran_paramfeedback (" & _
                            "M_PFEEDBACK_EMPID, " & _
                            "M_PFEEDBACK_PARAM," & _
                            "M_PFEEDBACK_COMMENT," & _
                            "M_PFEEDBACK_MONTH," & _
                            "M_PFEEDBACK_YEAR" & _
                            ") values(" & _
                            "'" & Session("KRAUserID") & "', " & _
                            "'" & Parameter(1) & "', " & _
                            "'" & objSupport2.FormatData(CType(pnlParam.FindControl(Parameter(0)), TextBox).Text, "-") & "', " & _
                            "'" & Session("Month") & "', " & _
                            "'" & Session("Year") & "')"
                    Command = New MySqlCommand(strSQL, Connection)
                    Command.ExecuteNonQuery()
                End If
            Next
            objSupport2 = Nothing
            'lblresult.Visible = True
            'lblresult.Text = "KRA Generated Successfully"
            Session("KRAUserID") = ""
            Session("KRAUserName") = ""
            Session("KRAUserProjectID") = ""
            Session("KRAUserTitleID") = ""
            Session("KRAUserProjectName") = ""
            Session("KRAUserTitleName") = ""
            Response.Redirect("krastatus.aspx?status=do")
        Catch ex As Exception
            lblError.Text = ex.Message
            If Session("UserCurRole") = "Administrator" Then lblError.Text = "Error storing KRA in database: " & ex.Message
        End Try
    End Sub

    Public Function PopulateKRA(ByVal Month As Integer, ByVal Year As Integer, ByVal EmpID As Integer, ByVal TitleID As Integer, ByVal ProjectID As Integer) As String
        Dim ActualSet As New DataSet
        Dim DataAdapter As MySqlDataAdapter
        Dim strSQL As String = ""
        Dim FormValidation As String = ""
        Dim Parameter As String = ""
        Dim ParameterCount As Integer = 0
        Dim ParameterCountList As String = ""
        Try
            Connection.Open()
            strSQL = "CALL KRAGoalsheet('" & EmpID & "','" & ProjectID & "','" & TitleID & "','" & Month & "','" & Year & "')"
            DataAdapter = New MySqlDataAdapter(strSQL, Connection)
            DataAdapter.Fill(ActualSet)
            If ActualSet.Tables(0).Rows.Count <> 0 Then
                gvKRA.DataSource = ActualSet
                gvKRA.DataBind()
            End If
            gvKRA.HeaderRow.CssClass = "header"
            For Each gvItem As GridViewRow In gvKRA.Rows
                CType(gvItem.Cells(7).FindControl("txtActual"), TextBox).Attributes.Add("onchange", "actualchange=1;")
                If Parameter <> gvItem.Cells(0).Text And ParameterCount <> 0 Then
                    ParameterCountList &= ParameterCount & ","
                    Parameter = gvItem.Cells(0).Text
                ElseIf Parameter <> gvItem.Cells(0).Text Then
                    Parameter = gvItem.Cells(0).Text
                ElseIf Parameter = gvItem.Cells(0).Text Then
                    'gvItem.Cells(0).Text = ""
                End If
                Dim OprValue As String = gvItem.Cells(5).Text
                If Right(OprValue, 1) = "," Then
                    gvItem.Cells(5).Text = Mid(OprValue, 1, Len(OprValue) - 1)
                End If
                Dim PLValue As String = gvItem.Cells(6).Text
                If Right(PLValue, 1) = "," Then
                    gvItem.Cells(6).Text = Mid(PLValue, 1, Len(PLValue) - 1)
                End If
                ParameterCount += 1
                FormValidation = FormValidation & "frmvalidator.addValidation('" & CType(gvItem.Cells(5).FindControl("txtActual"), TextBox).ClientID & "','req','Please fill all the fields');" & vbCrLf
            Next
            If ParameterCountList <> "" Then
                hfParameterCountList.Value = ParameterCountList & ParameterCount
            End If
            Connection.Close()
            Return FormValidation
        Catch ex As Exception
            lblError.Text = ex.Message
            If Connection.State = ConnectionState.Open Then Connection.Close()
            Return ""
        End Try
    End Function

    Private Sub gvKRA_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvKRA.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            KeyWeightTotal += Convert.ToInt32(Replace(DataBinder.Eval(e.Row.DataItem, "KPI_Weight"), "%", ""))
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(3).Text = KeyWeightTotal & "%"
        End If
    End Sub

    Private Sub gvKRA_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvKRA.RowCreated
        e.Row.Cells(1).Visible = False
        e.Row.Cells(5).Visible = False
        e.Row.Cells(6).Visible = False
        e.Row.Cells(9).Visible = False
    End Sub

    Protected Sub lnkCalculate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lnkCalculate.Click
        Dim Rating As Integer
        Dim Score, SubTotal, Total As Double
        Dim KeyWeight As Integer = 0
        Dim KeyWeightTotal As Integer = 0
        Dim ParameterCount() As String = hfParameterCountList.Value.Split(",")
        Dim curParamItem As Integer = 0
        Dim curItem As Integer = 0
        Dim objSupport As New Support.QuerySet
        Connection.Open()
        Dim NestingCheck As String = objSupport.SelectAValue(Connection, "NestingCheck", "userinfo", "EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'")
        Dim Tenurity As String = objSupport.SelectAValue(Connection, "TenurityDays", "userinfo", "EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'")
        Connection.Close()
        objSupport = Nothing
        If Tenurity = "" Then
            Tenurity = "92"
        End If
        Dim GoalThreshold As Integer
        Dim gvItem As GridViewRow
        If Val(Tenurity) > 90 Or NestingCheck = "0" Then
            GoalThreshold = 0
        Else
            GoalThreshold = 10
        End If
        Total = 0
        Try
            For Each gvItem In gvKRA.Rows
                curItem += 1
                KeyWeight = CInt(Replace(CType(gvItem.Cells(3).FindControl("lblKeyWeight"), Label).Text, "%", ""))
                KeyWeightTotal += KeyWeight
                Rating = KeyRating(CType(gvItem.Cells(7).FindControl("txtActual"), TextBox).Text, gvItem.Cells(4).Text, Server.HtmlDecode(gvItem.Cells(5).Text), Server.HtmlDecode(gvItem.Cells(6).Text), GoalThreshold)
                gvItem.Cells(8).Text = Rating
                Score = (Rating * KeyWeight) / 100
                gvItem.Cells(9).Text = Math.Round(Score, 1)
                SubTotal += Score
                Total += Score
                If ParameterCount.Length > 0 Then
                    If ParameterCount(curParamItem) = CStr(curItem) Then
                        curParamItem += 1
                        gvItem.Cells(10).Text = Math.Round((SubTotal * 100) / CInt(Replace(CType(gvItem.Cells(1).FindControl("lblParamWeight"), Label).Text, "%", "")), 1)
                        SubTotal = 0
                    End If
                End If
            Next
            CType(gvKRA.FooterRow.FindControl("lblFinalRating"), Label).Text = Math.Round(Total, 1)
            gvKRA.FooterRow.Cells(3).Text = KeyWeightTotal & "%"
            btnSave.Enabled = True
        Catch ex As Exception
            lblError.Text = ex.Message
            lblError.Text = "Please check the input format and try again"
        End Try
    End Sub

End Class
