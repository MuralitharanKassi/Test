Imports SSO_NET
Imports System.IO

Partial Class logout
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Response.CacheControl = "no-cache"
        Response.AddHeader("Pragma", "no-cache")
        Response.Expires = -1
        If Session("SSO") = "1" Then
            SSOLogout()
        Else
            Logout()
        End If
    End Sub

    Sub Logout()
        Session.RemoveAll()
        Session.Abandon()
        Response.Redirect("index.aspx")
    End Sub

    Sub SSOLogout()
        Dim SSOObject As SSO = SSO.Instance

        Dim propertiesFilePath As String = HttpContext.Current.Server.MapPath("URLDetails.xml")
        Dim propertyReaderObject As New PropertyReader(propertiesFilePath)
        ssoObject.ApplicationID = propertyReaderObject.GetPropertyValue("applicationid")
        SSOObject.DominoLogout = propertyReaderObject.GetPropertyValue("dominologout")

        Dim CookieName As String = "ASP.NET_SessionId_" & SSOObject.ApplicationID
        Dim LogFile As New FileStream(Server.MapPath("log") & "\sso_log.txt", FileMode.Append, FileAccess.Write)
        Dim sw As New StreamWriter(LogFile)
        sw.WriteLine((DateTime.Now.ToString() & "  :  " & "User : ") + Session("emailaddress").ToString())
        sw.WriteLine("Logout session id : " & Session.SessionID)
        sw.Close()
        LogFile.Close()
        If Session("emailaddress") IsNot Nothing AndAlso Session("emailaddress").ToString().Length > 0 Then
            Session.RemoveAll()
            Session.Abandon()
        End If
        Response.Redirect(SSOObject.DominoLogout)
    End Sub
End Class
