var tmenuItems = [

    ["+General","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|Home","javascript:loadPage('home.aspx')", "", "", "", "Home Page", "", "", "", "", ],
    ["Reports","", "images/kra_image_49.jpg", "", "", "", "", "0", "0", "", ],
        ["|My KRA Score","javascript:loadPage('krareportdisplay.aspx')", "", "", "", "", "", "", "", "", ],
        ["|KRA Report","javascript:loadPage('krareport.aspx')", "", "", "", "", "", "", "", "", ],
        ["|Final Rating","javascript:loadPage('rpt_hrscore.aspx')", "", "", "", "", "", "", "", "", ],
];

dtree_init();