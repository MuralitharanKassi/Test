Imports MySql.Data.MySqlClient

Partial Class forgot_pass
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        txtnewpass.Attributes.Add("onBlur", "return checklength('txtnewpass')")
        Dim check, result As String
        Dim maxTry As Integer = 5
        Label2.Visible = False
        Label3.Visible = False
        If IsPostBack Then
            Dim objSupport As New Support.QuerySet
            Try
                Connection.Open()
                If txt_try.Text = maxTry - 1 Then
                    objSupport.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_BLOCK='1'", "M_EMPL_ID_PK='" & Session("empid") & "'")
                    Label6.Visible = True
                    pnldob.Visible = False
                    pnlpass.Visible = False
                    bttpass.Visible = False
                    Label6.Text = "Your Account is Locked. " & vbCrLf & "You have exceeded the maximum try. Please contact Administrator."
                    Exit Sub
                End If
                Select Case txtstep.Text
                    Case "pnldob"
                        Session("empid") = txtempid.Text
                        Session("empdob") = ddlyear.SelectedValue & "-" & ddlmonth.SelectedValue & "-" & ddldate.SelectedValue
                        result = objSupport.SelectAValue(Connection, "M_EMPL_BLOCK", "tb_mast_employee", "M_EMPL_ID_PK='" & Session("empid") & "'")
                        If result <> "1" Then
                            check = "SELECT Count(M_EMPL_ID_PK) FROM tb_mast_employee WHERE M_EMPL_DOB='" & Session("empdob") & "' and M_EMPL_REMQUES='" & txtques.SelectedValue & "' and M_EMPL_REMANS='" & txtans.Text & "' and M_EMPL_ID_PK='" & Session("empid") & "'"
                            check = objSupport.SelectAValue(Connection, "Count(M_EMPL_ID_PK)", "tb_mast_employee", "M_EMPL_DOB='" & Session("empdob") & "' and M_EMPL_REMQUES='" & txtques.SelectedValue & "' and M_EMPL_REMANS='" & txtans.Text & "' and M_EMPL_ID_PK='" & Session("empid") & "'")
                            If check <> "0" Then
                                pnldob.Visible = False
                                txtstep.Text = "pnlpass"
                                pnlpass.Visible = True
                                bttpass.Visible = True
                                Label6.Visible = False
                            Else
                                Label2.Visible = True
                                Label2.Text = "Data does not match"
                                txt_try.Text = CStr(CInt(txt_try.Text) + 1)
                                Label6.Visible = True
                                Label6.Text = "You have " & maxTry - CInt(txt_try.Text) & " try left"
                            End If
                        Else
                            Label6.Visible = True
                            pnldob.Visible = False
                            pnlpass.Visible = False
                            bttpass.Visible = False
                            Label6.Text = "Your Account is Locked. " & vbCrLf & "You have exceeded the maximum try. Please contact Administrator."
                        End If
                    Case "pnlpass"
                        Dim objCrypto As New Support.Crypto
                        objSupport.UpdateValue(Connection, "tb_mast_employee", "M_EMPL_PASSWORD='" & objCrypto.Encrypt(txtnewpass.Text) & "',M_EMPL_ENCRYPT='1',M_EMPL_BLOCK='0'", "M_EMPL_ID_PK='" & Session("empid") & "'")
                        objCrypto = Nothing
                        txtstep.Text = "pnlsuccess"
                        Label3.Visible = True
                        Label3.Text = "Your password changed successfully"
                        lnklogin.Visible = True
                        pnldob.Visible = False
                        pnlpass.Visible = False
                        bttpass.Visible = False
                    Case "pnlsuccess"
                        Response.Redirect("index.aspx")
                End Select
                Connection.Close()
            Catch ex As Exception
                Label2.Visible = True
                Label2.Text = "Error Occured." & ex.Message
            End Try
            objSupport = Nothing
        Else
            Dim objSupport As New Support.Common
            For i = 1 To 31
                ddldate.Items.Add(objSupport.StringFill(i, 2))
            Next
            For i = 1 To 12
                ddlmonth.Items.Add(New ListItem(MonthName(i), objSupport.StringFill(i, 2)))
            Next
            For i = 1949 To 1999
                ddlyear.Items.Add(objSupport.StringFill(i, 4))
            Next
            objSupport = Nothing
        End If
    End Sub

End Class
