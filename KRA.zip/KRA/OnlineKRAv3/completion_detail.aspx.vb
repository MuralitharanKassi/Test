Imports MySql.Data.MySqlClient

Partial Class completion_detail
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Session("UserCurRole") <> "Administrator" And Session("UserCurRole") <> "Super Admin" And Session("UserCurRole") <> "Project Admin" And Session("UserCurRole") <> "Director" Then
            lblMsg.Text = "You are not authorized to view this report"
            Exit Sub
        End If
        Dim status As String = ""
        Dim project As String = ""
        Select Case Request.QueryString("s")
            Case "1"
                status = "Completed"
            Case "2"
                status = "Pending with Appraiser or No Goalsheet"
            Case "3"
                status = "Pending with Reviewer"
            Case "4"
                status = "Signoff Pending"
            Case "5"
                status = "Not Completed"
        End Select
        project = Request.QueryString("p")
        If Request.QueryString("m") <> "" And Request.QueryString("y") <> "" Then
            strSQL = "call KRACompletionReport('','','','','','" & project & "','" & Request.QueryString("m") & "','" & Request.QueryString("y") & "','','" & status & "')"
            Dim myDataset As New DataSet
            Dim myData As New MySqlDataAdapter(strSQL, Connection)
            myData.Fill(myDataset)

            grdReport.DataSource = myDataset.Tables(0).DefaultView
            grdReport.DataBind()
            lnkExport.Visible = True
            Dim DemoGridItem As DataGridItem
            For Each DemoGridItem In grdReport.Items
                DemoGridItem.Cells(4).Font.Bold = True
                If LCase(DemoGridItem.Cells(4).Text) = "completed" Then
                    DemoGridItem.Cells(4).ForeColor = Color.Green
                End If
            Next
        Else
            lblMsg.Text = "Required parameters missing"
        End If
    End Sub

    Private Sub grdReport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdReport.ItemDataBound
        e.Item.Cells(8).Visible = False
    End Sub

    Private Sub lnkExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkExport.Click
        KRAClass.ExportDataGrid(grdReport, "KRA_Completion_Report.xls")
        'export()
    End Sub
End Class
