Imports MySql.Data.MySqlClient
Imports SSO_NET

Partial Class Header
    Inherits System.Web.UI.UserControl
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim Status As String
    Dim strSQL As String
    Protected WithEvents ddlMonthList As System.Web.UI.WebControls.DropDownList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents listmenu As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents pnlsign As System.Web.UI.WebControls.Panel
    Protected WithEvents pnlstatus As System.Web.UI.WebControls.Panel

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        Response.CacheControl = "no-cache"
        Response.AddHeader("Pragma", "no-cache")
        Response.Expires = -1
        If Session("SSO") = "1" Then
            checkSSOToken()
        Else
            checkAppSession()
        End If

        Try
            'lblUserInfo.Text = KRAClass.CheckRoles(Session("username"), Session("UserID"), Session("UserCurRole"), Session("Month"), Session("Year"))
            lblUserInfo.Text = "Welcome " & Session("UserName")
            'If Session("UserLastLogin") <> "" Then
            '    Dim loginTime As DateTime = CDate(Session("UserLastLogin"))
            'End If
            'If Session("NewPassword") = "1" Then
            '    quicklinks.Visible = False
            'Else
            '    quicklinks.Visible = True
            'End If
            'If Session("DefaultPassword") <> "1" Then
            Session("MenuScript") = "<script type='text/javascript' src='menu/" & LCase(Replace(Session("UserCurRole"), " ", "")) & ".js'></script>"
            'Else
            '    Session("MenuScript") = " "
            'End If
            Connection.Open()
            If Not IsPostBack Then
                If Session("UserCurRole") <> "Administrator" Then
                    userdetails.InnerHtml = "<b>Project: " & Session("UserProjectName") & " | Title: " & Session("UserTitleName") & " | Appraiser: " & Session("UserAppraiserName") & "</b>"
                Else
                    userdetails.Visible = False
                End If
                PopulateRole()
                FillMonth(Connection, Session("UserID"), Session("UserCurRole"), ddlMonthList, Session("Month"), Session("Year"))
                ddlMonthList.SelectedValue = 100 * CInt(Session("Year")) + CInt(Session("Month"))
                ddlRole.SelectedValue = Session("UserCurRole")
            End If
            If Session("UserCurRole") <> "Administrator" Then
                If Session("CurMonthKRA") = "" Then
                    Session("CurMonthKRA") = GetKRAStatus(Session("UserID"), Session("Month"), Session("Year"))
                End If
                currentscore.Text = Session("CurMonthKRA")
                If Session("LastMonthKRA") Is Nothing OrElse Session("LastMonthKRA") = "" Then
                    Session("LastMonthKRA") = LastMonthKRA(Session("UserID"), Session("Month"), Session("Year"))
                End If
                lastscore.Text = Session("LastMonthKRA")
            End If
            Connection.Close()
        Catch ex As Exception
            If Session("UserCurRole") = "Administrator" Then
                lblerr.Visible = True
                lblerr.Text = ex.Message
            End If
            If Connection.State = ConnectionState.Open Then Connection.Close()
        End Try
    End Sub

    Private Function GetKRAStatus(ByVal EmpID As String, ByVal Month As String, ByVal Year As String) As String
        strSQL = "call IndividualKRAStatus(" & EmpID & "," & Month & "," & Year & ")"
        Command = New MySqlCommand(strSQL, Connection)
        Reader = Command.ExecuteReader()
        Reader.Read()
        Status = Reader(0)
        Reader.Close()
        Dim CurMonth As String = MonthName(Month, True) & " - " & Year
        Dim KRAStatus As String = ""
        Select Case Status
            Case "Completed"
                strSQL = "select ROUND(SUM(tran_revscore),1) from tb_tran_storerating where tran_empid='" & EmpID & "' and tran_month='" & Month & "' and tran_year='" & Year & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Reader.Read()
                KRAStatus = "Your KRA Score for " & CurMonth & " is " & Reader(0)
                Reader.Close()
            Case "KRA not Eligible"
                KRAStatus = "KRA not Eligible for " & CurMonth
            Case "Goalsheet not available"
                KRAStatus = "Goalsheet not available for " & CurMonth
            Case "Pending with Appraiser"
                KRAStatus = "Your KRA for " & CurMonth & " is Pending with Appraiser"
            Case "Pending with Reviewer"
                KRAStatus = "Your KRA for " & CurMonth & " is Pending with Reviewer"
            Case "Sign off Pending"
                KRAStatus = "Your KRA for " & CurMonth & " is Pending Signoff<br><a href='kraempsign.aspx'>click here</a> for details"
        End Select
        Return KRAStatus
    End Function

    Private Function LastMonthKRA(ByVal EmpID As String, ByVal Month As String, ByVal Year As String) As String
        Month = CInt(Month) - 1
        Year = CInt(Year)
        If Month = "0" Then
            Month = "12"
            Year = CInt(Year) - 1
        End If
        Return GetKRAStatus(EmpID, Month, Year)
    End Function
    Private Sub PopulateRole()
        Dim rolelist As String()
        Dim i As Integer
        If Session("UserRoles") <> "Administrator" And Session("UserRoles") <> "" Then
            rolelist = CStr(Session("UserRoles")).Split(",")
            For i = 0 To UBound(rolelist) - 1
                'If rolelist(i) <> "User" Then
                ddlRole.Items.Add(rolelist(i))
                'End If
            Next
            'If rolelist.Length = 1 Then
            '    ddlRole.Items.Add("User")
            'End If
        Else
            ddlRole.Enabled = False
        End If
    End Sub

    Protected Sub ddlRole_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlRole.SelectedIndexChanged
        If InStr(Session("UserRoles"), ddlRole.SelectedValue) > 0 Then
            Session("UserCurRole") = ddlRole.SelectedValue
        End If
        Response.Redirect("krahome.aspx")
    End Sub

    Protected Sub ddlMonthList_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlMonthList.SelectedIndexChanged
        Dim monthyear As Integer
        Dim curRole As String = Session("UserCurRole")
        Try
            monthyear = CInt(ddlMonthList.SelectedValue)
            Dim objSupport As New Support.Common
            Session("Month") = objSupport.GetMonth(monthyear)
            Session("Year") = objSupport.GetYear(monthyear)
            objSupport = Nothing
            Session("CurMonthKRA") = ""
            Session("LastMonthKRA") = ""
            If Session("UserCurRole") <> "Administrator" Then
                Connection.Open()
                strSQL = "select ProjectID, Project, TitleID, Title, AppraiserID, Appraiser from userInfo where EmpID='" & Session("UserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'"
                Command.CommandText = strSQL
                Command.Connection = Connection
                Reader = Command.ExecuteReader()
                Reader.Read()
                If Reader.HasRows Then
                    If Not IsDBNull(Reader("ProjectID")) Then Session("UserProjectID") = Reader("ProjectID")
                    If Not IsDBNull(Reader("TitleID")) Then Session("UserTitleID") = Reader("TitleID")
                    If Not IsDBNull(Reader("AppraiserID")) Then Session("UserAppraiserID") = Reader("AppraiserID")
                    If Not IsDBNull(Reader("Project")) Then Session("UserProjectName") = Reader("Project")
                    If Not IsDBNull(Reader("Title")) Then Session("UserTitleName") = Reader("Title")
                    If Not IsDBNull(Reader("Appraiser")) Then Session("UserAppraiserName") = Reader("Appraiser")
                End If
                Reader.Close()

                strSQL = "call isAppraiser('" & Session("UserID") & "','" & Session("Month") & "','" & Session("Year") & "')"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Reader.Read()
                Session("UserRoles") = Replace(Session("UserRoles"), "Appraiser,", "")
                Session("UserRoles") = Replace(Session("UserRoles"), "Reviewer,", "")
                If Reader(0) <> "0" Then
                    Session("UserRoles") = Session("UserRoles") & "Appraiser,"
                    Session("UserCurRole") = "Appraiser"
                Else
                    Session("UserCurRole") = "User"
                End If
                Reader.Close()
                strSQL = "call isReviewer('" & Session("UserID") & "','" & Session("Month") & "','" & Session("Year") & "')"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()
                Reader.Read()
                If Reader(0) <> "0" Then
                    Session("UserRoles") = Session("UserRoles") & "Reviewer,"
                End If
                Reader.Close()
                Connection.Close()
                Session("UserCurRole") = curRole
            End If
            'If Request.QueryString("page") = "" Then
            Response.Redirect("krahome.aspx")
            'Else
            '    Response.Redirect(Request.QueryString("page"))
            'End If
        Catch ex As Exception
            'Error message
        End Try
    End Sub

    Sub checkSSOToken()
        'Dim userDetails As Hashtable
        Dim SSOObject As SSO = SSO.Instance
        Dim propertiesFilePath As String = HttpContext.Current.Server.MapPath("URLDetails.xml")
        Dim propertyReaderObject As New PropertyReader(propertiesFilePath)
        SSOObject.LoginURL = propertyReaderObject.GetPropertyValue("loginurl")
        SSOObject.LogoutURL = propertyReaderObject.GetPropertyValue("logouturl")
        SSOObject.RedirectPageURL = propertyReaderObject.GetPropertyValue("redirectpageurl")
        SSOObject.LoginValidate = propertyReaderObject.GetPropertyValue("loginvalidate")
        SSOObject.SessionRefresh = propertyReaderObject.GetPropertyValue("sessionrefresh")
        SSOObject.SubDomain = propertyReaderObject.GetPropertyValue("subdomain")
        SSOObject.VersionID = propertyReaderObject.GetPropertyValue("versionid")
        SSOObject.ApplicationID = propertyReaderObject.GetPropertyValue("applicationid")
        SSOObject.DominoLogout = propertyReaderObject.GetPropertyValue("dominologout")

        Dim linkForLogin As String = ((((SSOObject.LoginURL & "?redirectpage=") + SSOObject.RedirectPageURL & "&appid=") + SSOObject.ApplicationID & "&logouturl=") + SSOObject.LogoutURL & "&versionid=") + SSOObject.VersionID
        If Session("Token") IsNot Nothing Then
            'Response.Write("Time: " & Now() & "<br>Token: " & Session("Token"))
            Dim SSOTest As Boolean = SSOObject.IsTokenPresent()
            'Response.Write("<br>SSOTest: " & SSOTest & "<br>EmpID: " & Session("UserID"))
            If Not SSOTest Then
                Session.Abandon()
                Response.Redirect(linkForLogin)
            End If
        Else
            'If Request.Cookies("LtpaToken") IsNot Nothing Then
            '    Response.Write("Time: " & Now() & " -- Cookie: " & Request.Cookies("LtpaToken").Value)
            '    userDetails = SSOObject.CheckForToken()
            '    Response.Write("Time: " & Now() & " -- UserStatus: " & userDetails("status").ToString())
            '    If userDetails("status").ToString() = "PASS" Then
            '        Session("emailaddress") = userDetails("emailaddress")
            '    Else
            '        Response.Redirect(linkForLogin)
            '    End If
            'Else
            Response.Redirect(linkForLogin)
            'End If
        End If
        'checkAppSession()
    End Sub

    Sub checkAppSession()
        If Session("UserID") = "" Then
            Response.Redirect("logout.aspx")
        End If
    End Sub
End Class
