Imports MySql.Data.MySqlClient

Partial Class kraadminedit
    Inherits System.Web.UI.Page
    Dim conString As String = ConfigurationManager.ConnectionStrings("connection_string").ConnectionString.ToString()
    Dim Connection As New MySqlConnection(conString)
    Dim Reader As MySqlDataReader
    Dim Command As MySqlCommand
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Session("ReportUserID") = "" Or Session("ReportMonth") = "" Or Session("ReportYear") = "" Then
            Response.Redirect("krareportdisplay.aspx")
        End If
        If Session("UserCurRole") <> "Super Admin" And Session("UserCurRole") <> "Administrator" Then
            Response.Redirect("krareportdisplay.aspx")
        End If
        'Dim Parameters() As String
        Dim i As Integer
        Dim objQuery As New Support.QuerySet
        Try
            If Not IsPostBack Then
                Connection.Open()
                strSQL = "select Name, Project, Title, ProjectID, TitleID from userinfo where Month='" & Session("ReportMonth") & "' and Year='" & Session("ReportYear") & "' and EmpID='" & Session("ReportUserID") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Reader = Command.ExecuteReader()

                Reader.Read()
                Session("kratitle") = Reader("TitleID")
                Session("kraproject") = Reader("ProjectID")
                lblHeader.Text = "Emp No: " & Session("ReportUserID") & "  |  Emp Name: " & Reader(0) & "  |  Project: " & Reader(1) & "  |  Title: " & Reader(2)
                Reader.Close()
                Dim status As String
                status = objQuery.SelectAValue(Connection, "count(tran_empid)", "tb_tran_storerating", "tran_empid  = " & Session("ReportUserID") & " and tran_month=" & Session("ReportMonth") & " and tran_year =" & Session("ReportYear") & " and tran_revtime<>''")
                If status <> "0" Then
                    grdEmployee.Visible = True
                    BindGrid()
                    txt_params.Text = FeedbackParam(pnlParam, Session("ReportUserID"), Session("ReportMonth"), Session("ReportYear"))
                    strSQL = "select * from tb_tran_paramfeedback where M_PFEEDBACK_MONTH='" & Session("ReportMonth") & "' and M_PFEEDBACK_YEAR='" & Session("ReportYear") & "' and M_PFEEDBACK_EMPID='" & Session("ReportUserID") & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    Dim ParamList() As String
                    Dim Parameter() As String

                    ParamList = Split(txt_params.Text, ";")
                    While Reader.Read()
                        For i = 0 To ParamList.Length - 1
                            Parameter = Split(ParamList(i), ",")
                            If Parameter(1) = Reader("M_PFEEDBACK_PARAM") Then
                                CType(pnlParam.FindControl(Parameter(0)), TextBox).Text = Reader("M_PFEEDBACK_COMMENT")
                            End If
                        Next
                    End While
                    Reader.Close()
                    strSQL = "select * from tb_tran_empfeedback where M_FEEDBACK_MONTH='" & Session("ReportMonth") & "' and M_FEEDBACK_YEAR='" & Session("ReportYear") & "' and M_FEEDBACK_EMPID='" & Session("ReportUserID") & "'"
                    Command = New MySqlCommand(strSQL, Connection)
                    Reader = Command.ExecuteReader()
                    While Reader.Read()
                        If Not IsDBNull(Reader("M_FEEDBACK_APPCOMM")) Then txt_appcomm.Text = Reader("M_FEEDBACK_APPCOMM")
                        If Not IsDBNull(Reader("M_FEEDBACK_REVCOMM")) Then txt_revcomm.Text = Reader("M_FEEDBACK_REVCOMM")
                        If Not IsDBNull(Reader("M_FEEDBACK_IDENT_TECH")) Then txtidtec.Text = Reader("M_FEEDBACK_IDENT_TECH")
                        If Not IsDBNull(Reader("M_FEEDBACK_IDENT_CERT")) Then txtidcer.Text = Reader("M_FEEDBACK_IDENT_CERT")
                        If Not IsDBNull(Reader("M_FEEDBACK_IDENT_SKILL")) Then txtidskill.Text = Reader("M_FEEDBACK_IDENT_SKILL")
                        If Reader("M_FEEDBACK_REL_EMP") = "Good" Then
                            radiogood.Checked = True
                        ElseIf Reader("M_FEEDBACK_REL_EMP") = "Un - Satisfactory" Then
                            radioun.Checked = True
                        Else
                            radioexcellent.Checked = True
                        End If
                        If Reader("M_FEEDBACK_REL_SUP") = "Good" Then
                            radiogood1.Checked = True
                        ElseIf Reader("M_FEEDBACK_REL_SUP") = "Un - Satisfactory" Then
                            radioun1.Checked = True
                        Else
                            radioexcellent1.Checked = True
                        End If
                        If Reader("M_FEEDBACK_COMP") = "Improved" Then
                            radioexcellent2.Checked = True
                        ElseIf Reader("M_FEEDBACK_COMP") = "No change" Then
                            radiogood2.Checked = True
                        Else
                            radioun2.Checked = True
                        End If
                    End While
                    Reader.Close()
                Else
                    errLabel.Text = "Related entries not found"
                    errLabel.Visible = True
                End If
                Connection.Close()
            End If
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try

    End Sub
    Private Sub BindGrid()
        Dim objQuery As New Support.QuerySet
        Dim ds1 As DataSet
        Dim weightsum As Double = 0.0
        Dim empsum As Double = 0.0
        Dim appsum As Double = 0.0
        Dim revsum As Double = 0.0
        Dim hrsum As Double = 0.0
        Try
            'Connection.Open()
            'Dim intHrrating As String

            Dim status As String
            status = objQuery.SelectAValue(Connection, "count(tran_empid)", "tb_tran_storerating", "tran_empid  = " & Session("ReportUserID") & " and tran_month=" & Session("ReportMonth") & " and tran_year =" & Session("ReportYear") & " and tran_revtime<>''")
            If status = "0" Then
                errLabel.Text = "Related entries not found"
                errLabel.Visible = True
            Else
                GridPanel.Visible = True
                errLabel.Visible = False
                ds1 = objQuery.SelectDataset(Connection, "*", "tb_tran_storerating", "tran_empid  = " & Session("ReportUserID") & " and tran_month=" & Session("ReportMonth") & " and tran_year =" & Session("ReportYear") & "")
                grdEmployee.DataSource = ds1.Tables("tb_tran_storerating").DefaultView
                grdEmployee.DataBind()
                Dim DemoGridItem As DataGridItem
                Dim Param As String = ""
                For Each DemoGridItem In grdEmployee.Items
                    If Param = DemoGridItem.Cells(0).Text Then
                        DemoGridItem.Cells(0).Text = ""
                    Else
                        Param = DemoGridItem.Cells(0).Text
                        strSQL = "select round((sum(tran_revscore)/(tran_weightage/100))) from tb_tran_storerating where tran_param='" & Param & "' and tran_empid='" & Session("ReportUserID") & "' and tran_month='" & Session("ReportMonth") & "' and tran_year='" & Session("ReportYear") & "'"
                        Command = New MySqlCommand(strSQL, Connection)
                        Reader = Command.ExecuteReader()
                        Reader.Read()
                        If Reader.HasRows Then
                            DemoGridItem.Cells(14).Text = Reader(0)
                            'hrsum = hrsum + rs(0)
                        End If
                        Reader.Close()
                    End If
                    weightsum = weightsum + CDbl(DemoGridItem.Cells(3).Text.Substring(0, Len(DemoGridItem.Cells(3).Text) - 1)) / 100
                    'empsum = empsum + DemoGridItem.Cells(6).Text
                    revsum = revsum + CDbl(DemoGridItem.Cells(8).Text)
                    lblRating.Text = "Review Rating: " & revsum & "     |    Final Rating: " & Math.Round((revsum / (weightsum * 100)) * 100, 1)
                    lblRating.Visible = True
                Next
            End If
            objQuery = Nothing
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_EditCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.EditCommand
        grdEmployee.EditItemIndex = CInt(e.Item.ItemIndex)
        lblStatus.Text = "'" & e.Item.Cells(17).Text & ": " & e.Item.Cells(1).Text & "' selected for editing"
        lblStatus.Visible = True
        Connection.Open()
        BindGrid()
        Connection.Close()
    End Sub

    Private Sub grdEmployee_UpdateCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.UpdateCommand
        Try
            Dim Actual As TextBox = e.Item.Cells(4).Controls(0)
            If Actual.Text = "" Then
                errLabel.Text = "Rating cannot be blank"
                errLabel.Visible = True
                Exit Sub
            End If
            Actual.Text = Replace(Actual.Text, "$", "")
            Actual.Text = Replace(Actual.Text, ",", "")
            Dim Goal As String = e.Item.Cells(2).Text
            If Actual.Text.EndsWith("%") Then
                If Not Goal.EndsWith("%") Then
                    Actual.Text = Actual.Text.Replace("%", "")
                End If
            Else
                If Goal.EndsWith("%") Then
                    Actual.Text = Actual.Text & "%"
                End If
            End If

            'Dim xxx As RegularExpressionValidator = e.Item.Cells(7).Controls(0)
            'xxx.ControlToValidate = "actual1"
            'xxx.ValidationExpression = "[0-9,:,.]+"
            'xxx.Text = "Invalid Entry"
            Dim Remark As TextBox = e.Item.Cells(7).Controls(0)
            Dim strSQL As String = ""
            'remark = remark1.Text
            'Dim actual As Double
            Dim weight As Double = CDbl(e.Item.Cells(3).Text.Substring(0, Len(e.Item.Cells(3).Text) - 1))
            Dim intID As String = e.Item.Cells(0).Text
            'Dim doesnotmeet As Double
            'Dim meetexp As Double
            'Dim exceed As Double
            'Dim role As Double
            Dim PL As String = e.Item.Cells(9).Text & "|" & e.Item.Cells(10).Text & "|" & e.Item.Cells(11).Text & "|" & e.Item.Cells(12).Text
            If e.Item.Cells(16).Text <> "" Then
                PL &= "|" & e.Item.Cells(16).Text
            End If
            Dim Opr As String = e.Item.Cells(13).Text
            Dim id As Integer = CInt(e.Item.Cells(14).Text)
            Dim Score As Double
            Dim Rating As Double
            Dim objSupport As New Support.Common
            'Dim arr As String()
            errLabel.Visible = False
            'If (actual1.Text.IndexOf("%") > -1) Then
            '    actual = CDbl(actual1.Text.Substring(0, Len(actual1.Text) - 1)) / 100
            '    doesnotmeet = CDbl(e.Item.Cells(8).Text)
            '    meetexp = CDbl(e.Item.Cells(9).Text)
            '    exceed = CDbl(e.Item.Cells(10).Text)
            '    role = CDbl(e.Item.Cells(11).Text)
            'ElseIf (actual1.Text.IndexOf(":") > -1) Then
            '    actual = objSupport.ToSeconds(actual1.Text)
            '    doesnotmeet = objSupport.ToSeconds(e.Item.Cells(8).Text)
            '    meetexp = objSupport.ToSeconds(e.Item.Cells(9).Text)
            '    exceed = objSupport.ToSeconds(e.Item.Cells(10).Text)
            '    role = objSupport.ToSeconds(e.Item.Cells(11).Text)
            '    'arr = actual1.Text.Split(":", 3)
            '    'actual = (CInt(arr(0)) * 120) + (CInt(arr(1)) * 60) + (CInt(arr(2)))
            '    'arr = e.Item.Cells(8).Text.Split(":", 3)
            '    'doesnotmeet = (CInt(arr(0)) * 120) + (CInt(arr(1)) * 60) + (CInt(arr(2)))
            '    'arr = e.Item.Cells(9).Text.Split(":", 3)
            '    'meetexp = (CInt(arr(0)) * 120) + (CInt(arr(1)) * 60) + (CInt(arr(2)))
            '    'arr = e.Item.Cells(10).Text.Split(":", 3)
            '    'exceed = (CInt(arr(0)) * 120) + (CInt(arr(1)) * 60) + (CInt(arr(2)))
            '    'arr = e.Item.Cells(11).Text.Split(":", 3)
            '    'role = (CInt(arr(0)) * 120) + (CInt(arr(1)) * 60) + (CInt(arr(2)))
            'Else
            '    actual = CDbl(actual1.Text)
            '    doesnotmeet = CDbl(e.Item.Cells(8).Text)
            '    meetexp = CDbl(e.Item.Cells(9).Text)
            '    exceed = CDbl(e.Item.Cells(10).Text)
            '    role = CDbl(e.Item.Cells(11).Text)
            'End If
            'objSupport = Nothing
            'Calculation of Rating
            'rate = KRAClass.Rating(opt, actual, meetexp, doesnotmeet, exceed, role)
            Connection.Open()
            Dim objQuery As New Support.QuerySet
            Dim NestingCheck As String = objQuery.SelectAValue(Connection, "NestingCheck", "userinfo", "EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'")
            Dim Tenurity As String = objQuery.SelectAValue(Connection, "TenurityDays", "userinfo", "EmpID='" & Session("KRAUserID") & "' and Month='" & Session("Month") & "' and Year='" & Session("Year") & "'")
            objQuery = Nothing
            'Connection.Close()
            If Tenurity = "" Then
                Tenurity = "92"
            End If
            Dim GoalThreshold As Integer
            If Val(Tenurity) > 90 Or NestingCheck = "0" Then
                GoalThreshold = 0
            Else
                GoalThreshold = 10
            End If

            Rating = KeyRating(Actual.Text, Goal, Opr, PL, GoalThreshold)
            Score = Rating * (weight / 100)

            'Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
            'Dim objSupport As New Support.Common
            strSQL = " Update tb_tran_storerating set tran_actual='" & Actual.Text & "',tran_revrating = " & Rating & " ,tran_revscore= " & Score & ",tran_remark='" & objSupport.FormatData(Remark.Text, "-") & "' where tran_id = " & id & " and tran_month=" & Session("Month") & " and tran_year =" & Session("Year") & ""
            'If (actual1.Text.IndexOf("%") > -1) Then
            '    strSQL = " Update tb_tran_storerating set tran_actual='" & actual * 100 & "%',tran_revrating = " & rate & " ,tran_revscore= " & rating & ",tran_remark='" & objSupport.FormatData(remark.Text, "-") & "' where tran_id = '" & id & "'"
            'ElseIf (actual1.Text.IndexOf(":") > -1) Then
            '    strSQL = " Update tb_tran_storerating set tran_actual='" & actual1.Text & "',tran_revrating = " & rate & " ,tran_revscore= " & rating & ",tran_remark='" & objSupport.FormatData(remark.Text, "-") & "' where tran_id = '" & id & "'"
            'Else
            '    strSQL = " Update tb_tran_storerating set tran_actual='" & actual & "',tran_revrating = " & rate & " ,tran_revscore= " & rating & ",tran_remark='" & objSupport.FormatData(remark.Text, "-") & "' where tran_id = '" & id & "'"
            'End If
            objSupport = Nothing
            'Connection.Open()
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()
            lblStatus.Text = "Score successfully updated for '" & e.Item.Cells(16).Text & ": " & e.Item.Cells(1).Text & "'"
            lblStatus.Visible = True
            grdEmployee.EditItemIndex = -1
            BindGrid()
            Connection.Close()

        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_CancelCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEmployee.CancelCommand
        grdEmployee.EditItemIndex = -1
        lblStatus.Text = "Edit operation cancelled for '" & e.Item.Cells(16).Text & ": " & e.Item.Cells(1).Text & "'"
        lblStatus.Visible = True
        Connection.Open()
        BindGrid()
        Connection.Close()
    End Sub
    Private Sub printlink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printlink.Click
        Response.Redirect("krareportdisplay.aspx")
    End Sub

    Private Sub bttupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttupdate.Click
        Dim relation As String = ""
        Dim relationsup As String = ""
        Dim comparison As String = ""
        Dim objSupport As New Support.Common
        Try
            If radioexcellent.Checked Then
                relation = "Excellent"
            ElseIf radiogood.Checked Then
                relation = "Good"
            ElseIf radioun.Checked Then
                relation = "Un - Satisfactory"
            End If

            If radioexcellent1.Checked Then
                relationsup = "Excellent"
            ElseIf radiogood1.Checked Then
                relationsup = "Good"
            ElseIf radioun1.Checked Then
                relationsup = "Un - Satisfactory"
            End If
            If radioexcellent2.Checked Then
                comparison = "Improved"
            ElseIf radiogood2.Checked Then
                comparison = "No change"
            ElseIf radioun2.Checked Then
                comparison = "Decline"
            End If
            Connection.Open()
            Dim i As Integer
            strSQL = "update tb_tran_empfeedback set " & _
                        "M_FEEDBACK_REL_EMP='" & relation.ToString() & "', " & _
                        "M_FEEDBACK_REL_SUP='" & relationsup.ToString() & "', " & _
                        "M_FEEDBACK_COMP='" & comparison.ToString() & "', " & _
                        "M_FEEDBACK_IDENT_TECH='" & objSupport.FormatData(txtidtec.Text.ToString(), "-") & "', " & _
                        "M_FEEDBACK_IDENT_CERT='" & objSupport.FormatData(txtidcer.Text.ToString(), "-") & "', " & _
                        "M_FEEDBACK_IDENT_SKILL='" & objSupport.FormatData(txtidskill.Text.ToString(), "-") & "', " & _
                        "M_FEEDBACK_APPCOMM='" & objSupport.FormatData(txt_appcomm.Text.ToString, "-") & "', " & _
                        "M_FEEDBACK_REVCOMM='" & objSupport.FormatData(txt_revcomm.Text.ToString, "-") & "' " & _
                        " where " & _
                        "M_FEEDBACK_MONTH='" & Session("ReportMonth") & "' and " & _
                        "M_FEEDBACK_YEAR='" & Session("ReportYear") & "' and " & _
                        "M_FEEDBACK_EMPID='" & Session("ReportUserID") & "' "
            Command = New MySqlCommand(strSQL, Connection)
            Command.ExecuteNonQuery()
            Dim ParamList() As String
            Dim Parameter() As String
            ParamList = Split(txt_params.Text, ";")
            For i = 0 To ParamList.Length - 1
                Parameter = Split(ParamList(i), ",")
                strSQL = "update tb_tran_paramfeedback set " & _
                        "M_PFEEDBACK_COMMENT=' " & objSupport.FormatData(Request(Parameter(0)), "-") & "'" & _
                        " where " & _
                        "M_PFEEDBACK_PARAM='" & Parameter(1) & "'," & _
                        "M_PFEEDBACK_EMPID='" & Session("ReportUserID") & "' and " & _
                        "M_PFEEDBACK_MONTH='" & Session("ReportMonth") & "' and " & _
                        "M_PFEEDBACK_YEAR='" & Session("ReportYear") & "'"
                Command = New MySqlCommand(strSQL, Connection)
                Command.ExecuteNonQuery()
            Next
            Session("ReportMonth") = Session("ReportMonth")
            Session("ReportYear") = Session("ReportYear")
            Session("ReportUserID") = Session("ReportUserID")
            Response.Redirect("krareportdisplay.aspx")
            lblresult.Visible = True
            lblresult.Text = "Updated Successfully"
            bttupdate.Enabled = False
            objSupport = Nothing
            Connection.Close()
        Catch ex As Exception
            errLabel.Text = ex.Message
        End Try
    End Sub

    Private Sub grdEmployee_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdEmployee.ItemDataBound
        Dim length As Integer = Len(e.Item.Cells(4).Text)
        If e.Item.Cells(4).Text.EndsWith("%") Then
            e.Item.Cells(4).Text = e.Item.Cells(4).Text.Substring(0, length - 1)
        End If
        grdEmployee.Visible = True
    End Sub
    
End Class
