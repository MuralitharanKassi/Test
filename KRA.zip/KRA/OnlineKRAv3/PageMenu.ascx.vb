Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Xml
Imports System.Xml.Xsl
Imports System.Xml.XPath
Imports System.IO
Imports System.Text

Partial Class PageMenu
    Inherits System.Web.UI.UserControl
    Private xmlFile As String = String.Empty
    Private xslFile As String = String.Empty
    Public Property XmlFileName() As String
        Get
            Return (xmlFile)
        End Get
        Set(ByVal value As String)
            xmlFile = "menu\" & Session("CurRole") & ".xml"
        End Set
    End Property
    Public Property XslFileName() As String
        Get
            Return (xslFile)
        End Get
        Set(ByVal value As String)
            xslFile = value
        End Set
    End Property
    Private Sub GetXMLFile()
        Dim userType As String
        Dim ApprDetails As String
        Dim clsAppraiser As New clsGeneral
        userType = Session("CurRole")
        If userType = "" Then userType = "Employee"

        If userType = "Super Admin" Or userType = "Director" Or userType = "Ecd" Then
            xmlFile = "menu\" & LCase(userType) & ".xml"
        Else
            ApprDetails = clsAppraiser.SelectAvalue("count(M_EMPL_ID_PK)", "tb_mast_employee", "M_APPRAISER_ID ='" & LCase(Session.Item("userempno")) & "'")
            If (ApprDetails <> "0") Then
                xmlFile = "menu\" & LCase(userType) & "_appr.xml"
            Else
                xmlFile = "menu\" & LCase(userType) & ".xml"
            End If
        End If
    End Sub
    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        GetXMLFile()
        Dim XmlSystemFileName As String = Server.MapPath(xmlFile)
        Dim XslSystemFileName As String = Server.MapPath(xslFile)
        Dim xslt As XslTransform = New XslTransform
        xslt.Load(XslSystemFileName)
        Dim xpathdocument As XPathDocument = New XPathDocument(XmlSystemFileName)
        Dim sb As StringBuilder = New StringBuilder
        Dim sw As StringWriter = New StringWriter(sb)
        xslt.Transform(xpathdocument, Nothing, sw, Nothing)
        MenuPlaceHolder.Text = sb.ToString()
    End Sub
#Region "Web Form Designer generated code"
    Protected Overrides Sub OnInit(ByVal e As EventArgs)
        InitializeComponent()
        MyBase.OnInit(e)
    End Sub

    Private Sub InitializeComponent()

    End Sub
#End Region
End Class
