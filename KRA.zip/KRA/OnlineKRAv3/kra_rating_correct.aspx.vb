Imports System.Data.Odbc
Public Class kra_rating_correct
    Inherits System.Web.UI.Page
    Dim kraConnection As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    Dim kraConnection2 As New OdbcConnection(System.Configuration.ConfigurationSettings.AppSettings("ConnectionString"))
    Dim kraCommand As New OdbcCommand
    Dim kraReader As OdbcDataReader
    Dim kraCommand2 As New OdbcCommand
    Dim kraReader2 As OdbcDataReader
    Dim strSQL As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents bttpass As System.Web.UI.WebControls.Button
    Protected WithEvents lblerr As System.Web.UI.WebControls.Label
    Protected WithEvents ddlMonth As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlYear As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dgList As System.Web.UI.WebControls.DataGrid

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Session("userempno") <> "csdc" Then
            Response.Redirect("krahome.aspx")
        End If

        Label2.Text = ""
        lblerr.Text = ""
    End Sub

    Private Sub bttpass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttpass.Click
        Try
            kraConnection.Open()
            strSQL = "select distinct tran_proj,tran_title,tran_month,tran_year from tb_tran_storerating where tran_month='" & ddlMonth.SelectedValue & "' and tran_year='" & ddlYear.SelectedValue & "' order by tran_proj, tran_title"
            Dim myDataset As New DataSet
            Dim myData As New OdbcDataAdapter(strSQL, kraConnection)
            myData.Fill(myDataset)
            dgList.DataSource = myDataset.Tables(0).DefaultView
            dgList.DataBind()
            kraConnection.Close()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Private Sub dgList_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgList.ItemCommand
        kraConnection.Open()
        kraConnection2.Open()
        strSQL = "select project,Title,Key_Deter,weight,Parameter,Weightage,role_month,role_year from tb_mast_service where project='" & e.Item.Cells(1).Text & "' and Title='" & e.Item.Cells(2).Text & "' and role_month='" & e.Item.Cells(3).Text & "' and role_year='" & e.Item.Cells(4).Text & "'"
        'Response.Write(strSQL & "<br><br>")
        kraCommand.Connection = kraConnection
        kraCommand.CommandText = strSQL
        kraReader = kraCommand.ExecuteReader
        kraReader.Read()
        While kraReader.Read
            strSQL = "update tb_tran_storerating set tran_weightage='" & kraReader("weight") & "%',tran_weight='" & kraReader("Weightage") & "%' where tran_proj='" & kraReader("project") & "' and tran_title='" & kraReader("Title") & "' and tran_keydeter='" & Replace(kraReader("Key_Deter"), "'", "\'") & "' and tran_param='" & kraReader("Parameter") & "' and tran_month='" & kraReader("role_month") & "' and tran_year='" & kraReader("role_year") & "'"
            'Response.Write(strSQL & "<br>")
            kraCommand2.Connection = kraConnection2
            kraCommand2.CommandText = strSQL
            kraReader2 = kraCommand2.ExecuteReader
            kraReader2.Close()
        End While
        kraConnection.Close()
        kraConnection2.Close()
        Label2.Text = "Weightage Updated"
    End Sub
End Class
